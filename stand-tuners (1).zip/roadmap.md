# Database performance and running usage

- [x] Measure project running usage, database load, query plans, indexes and scheduled work (external schedule history unavailable).
- [x] Optimize the largest measured query drivers without changing access, data or freshness.
- [x] Verify representative authenticated reads and record results and remaining cost limitations in database-optimization.md.