CREATE OR REPLACE FUNCTION public.can_write_pack_settings(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT public.has_role(_user_id, 'owner'::app_role)
     OR (
       EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = _user_id AND p.approved = true)
       AND NOT EXISTS (
         SELECT 1 FROM public.user_tab_denies d
         WHERE d.user_id = _user_id
           AND d.tab IN ('stock', 'stock:write', 'stock:pack')
       )
     )
$$;

DROP POLICY IF EXISTS "settings owner write" ON public.app_settings;
DROP POLICY IF EXISTS "settings owner update" ON public.app_settings;

CREATE POLICY "settings pack writers insert"
ON public.app_settings FOR INSERT TO authenticated
WITH CHECK (public.can_write_pack_settings(auth.uid()));

CREATE POLICY "settings pack writers update"
ON public.app_settings FOR UPDATE TO authenticated
USING (public.can_write_pack_settings(auth.uid()))
WITH CHECK (public.can_write_pack_settings(auth.uid()));