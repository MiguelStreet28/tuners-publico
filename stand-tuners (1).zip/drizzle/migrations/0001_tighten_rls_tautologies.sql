-- app_settings: leitura só para aprovados e owners
DROP POLICY IF EXISTS "settings read all auth" ON public.app_settings;
CREATE POLICY "settings read approved" ON public.app_settings
FOR SELECT TO authenticated
USING (
  public.has_role(auth.uid(), 'owner')
  OR EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.approved)
);

-- profiles: cada utilizador vê o próprio perfil; aprovados e owners veem a equipa
DROP POLICY IF EXISTS "profiles read team safe columns" ON public.profiles;
CREATE POLICY "profiles read self or team" ON public.profiles
FOR SELECT TO authenticated
USING (
  id = auth.uid()
  OR public.has_role(auth.uid(), 'owner')
  OR EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.approved)
);

-- sheet_writes: cada utilizador só acede às suas linhas; owners leem tudo
DROP POLICY IF EXISTS "sheet writes read auth" ON public.sheet_writes;
DROP POLICY IF EXISTS "sheet writes insert auth" ON public.sheet_writes;
DROP POLICY IF EXISTS "sheet writes update auth" ON public.sheet_writes;

CREATE POLICY "sheet writes read own" ON public.sheet_writes
FOR SELECT TO authenticated
USING (created_by = auth.uid() OR public.has_role(auth.uid(), 'owner'));

CREATE POLICY "sheet writes insert own" ON public.sheet_writes
FOR INSERT TO authenticated
WITH CHECK (created_by = auth.uid());

CREATE POLICY "sheet writes update own" ON public.sheet_writes
FOR UPDATE TO authenticated
USING (created_by = auth.uid())
WITH CHECK (created_by = auth.uid());