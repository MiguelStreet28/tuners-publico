-- Evaluate viewer-only role checks once per statement, not once per row.
-- Preserve the existing SELECT roles and ownership/approval predicates.
ALTER POLICY "owners read all audit" ON public.audit_logs
  USING ((SELECT public.has_role(auth.uid(), 'owner'::public.app_role)));
ALTER POLICY "approved team read record" ON public.vehicle_records
  USING (((SELECT auth.uid()) = seller_id)
    OR (SELECT public.has_role(auth.uid(), 'owner'::public.app_role))
    OR EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = (SELECT auth.uid()) AND p.approved = true));
ALTER POLICY "approved team read contract" ON public.contracts
  USING (((SELECT auth.uid()) = seller_id)
    OR (SELECT public.has_role(auth.uid(), 'owner'::public.app_role))
    OR EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = (SELECT auth.uid()) AND p.approved = true));
ALTER POLICY "approved team read stock" ON public.card_stock_movements
  USING ((SELECT public.has_role(auth.uid(), 'owner'::public.app_role))
    OR EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = (SELECT auth.uid()) AND p.approved = true));
CREATE INDEX IF NOT EXISTS audit_logs_created_at_desc_idx ON public.audit_logs (created_at DESC);
CREATE INDEX IF NOT EXISTS vehicle_records_created_at_desc_idx ON public.vehicle_records (created_at DESC);
CREATE INDEX IF NOT EXISTS contracts_created_at_desc_idx ON public.contracts (created_at DESC);
CREATE INDEX IF NOT EXISTS card_stock_movements_created_at_desc_idx ON public.card_stock_movements (created_at DESC);