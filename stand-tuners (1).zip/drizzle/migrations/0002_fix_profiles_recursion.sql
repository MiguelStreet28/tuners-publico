CREATE OR REPLACE FUNCTION public.is_approved(_user_id uuid)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.profiles WHERE id = _user_id AND approved = true)
$$;
ALTER FUNCTION public.has_role(uuid, app_role) SECURITY DEFINER;
DROP POLICY IF EXISTS "profiles read self or team" ON public.profiles;
CREATE POLICY "profiles read self or team" ON public.profiles FOR SELECT TO authenticated
USING (id = auth.uid() OR public.has_role(auth.uid(), 'owner'::app_role) OR public.is_approved(auth.uid()));