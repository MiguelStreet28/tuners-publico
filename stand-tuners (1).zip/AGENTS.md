<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.
<!-- LOVABLE:END -->

- Dashboard refreshes use a single-flight coordinator with a trailing read so overlapping updates never fan out into concurrent full-table loads or lose changes.
- Keep viewer-only role checks in dashboard SELECT policies in scalar subqueries so PostgreSQL evaluates them once per statement; preserve the existing access predicates.
