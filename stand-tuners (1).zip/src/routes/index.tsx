import { createFileRoute, redirect } from "@tanstack/react-router";

export const Route = createFileRoute("/")({
  head: () => ({ meta: [
    { title: "Stand Tuners — Plataforma da equipa" },
    { name: "description", content: "Acesso à plataforma de gestão interna da equipa Stand Tuners." },
    { property: "og:title", content: "Stand Tuners — Plataforma da equipa" },
    { property: "og:description", content: "Acesso à plataforma de gestão interna da equipa Stand Tuners." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  ssr: false,
  beforeLoad: async () => {
    const { supabase } = await import("@/integrations/supabase/client");
    const { data } = await supabase.auth.getSession();
    if (data.session) throw redirect({ to: "/app" });
    throw redirect({ to: "/auth" });
  },
});
