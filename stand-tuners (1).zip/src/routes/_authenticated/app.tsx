import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter, DialogDescription } from "@/components/ui/dialog";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { toast } from "sonner";
import { fmt, OWNERS } from "@/lib/format";
import { appendVehicleRecordsToSheet, updateVehicleRecordInSheet, clearVehicleRecordInSheet, getDiscordWebhookUrl, markDiscordSentInSheet, getSheetPackUsage, type VehicleOpKind } from "@/lib/sheets.functions";
import { deleteUserAccount, getMyCc, getUserCc, listTeamDirectory, sendCardDebtReminder } from "@/lib/admin.functions";
import { createSerialRefresh } from "@/lib/serial-refresh";
import {
  Wrench, LogOut, FilePlus2, Car, CreditCard, Trophy,
  TrendingUp, Users, Check, X, Trash2, KeyRound, User as UserIcon, Pencil,
  ShieldCheck, Package, ClipboardList, Lock, Home, Percent, Bell, Eye,
} from "lucide-react";


export const Route = createFileRoute("/_authenticated/app")({
  head: () => ({ meta: [
    { title: "Gestão do stand — Stand Tuners" },
    { name: "description", content: "Registos, contratos, stock, lucros e taxas da equipa Stand Tuners." },
    { property: "og:title", content: "Gestão do stand — Stand Tuners" },
    { property: "og:description", content: "Registos, contratos, stock, lucros e taxas da equipa Stand Tuners." },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ] }),
  component: AppPage,
});

type Profile = { id: string; full_name: string; cc: string | null; discord_id: string | null; approved: boolean; active: boolean; left_at: string | null; fee_mode: boolean };
/** Quem paga taxa (10% do lucro) não paga cartão. */
type FeePayment = { id: string; seller_id: string; matricula: string; cycle: number; record_id: string | null; profit: number; fee: number; created_at: string };
const FEE_PERCENT = 10;
type Contract = { id: string; seller_id: string; card_paid: boolean; card_value?: number | null; quantity?: number | null; notes: string | null; created_at: string };
/** Movimentos criados automaticamente pelo site — já vêm dos registos/contratos, não somam ao stock. */
const AUTO_REASONS = new Set(["auto_contract", "auto_card_paid", "record_delete_revert"]);

export type TradeCar = { matricula: string; modelo: string; casa?: boolean };
type VehicleRecord = {
  id: string; matricula: string; op: VehicleOpKind; valor: number; seller_id: string;
  contraparte: string | null; contraparte_id: string | null; contraparte_nome: string | null;
  modelo: string | null; comprador: string | null; notes: string | null; created_at: string;
  sheet_row: number | null;
  sheet_extra_rows: number[];
  matricula_entrada: string | null; modelo_entrada: string | null;
  extra_out: TradeCar[]; extra_in: TradeCar[];
  is_mota: boolean | null; casa_out: boolean | null; casa_in: boolean | null;
  /** Negócio interno: o outro lado do negócio é este membro do stand. */
  partner_id: string | null;
};


/**
 * Troca/casas: `casa_out = true` significa "sou EU que dou a casa" — logo os
 * carros do negócio ENTRAM (eu recebo carros). Caso contrário recebo a casa e
 * os carros SAEM.
 */
function houseGiven(r: { op: string; casa_out?: boolean | null }) {
  return r.op === "troca_casas" && r.casa_out === true;
}

/** Texto que vai para a coluna N do Sheets quando o item é uma casa. */

function casaText(tipo: string, cp: string) {
  const t = (tipo || "Casa").trim() || "Casa";
  const c = (cp || "").trim().toUpperCase();
  return c ? `${t} CP ${c}` : t;
}

function normalizeTradeCars(v: unknown): TradeCar[] {
  if (!Array.isArray(v)) return [];
  return v
    .map((x): TradeCar | null => {
      if (!x || typeof x !== "object") return null;
      const o = x as Record<string, unknown>;
      const matricula = String(o.matricula ?? "").trim().toUpperCase();
      const modelo = String(o.modelo ?? "").trim();
      const casa = o.casa === true;
      if (!matricula) return null;
      return { matricula, modelo, casa };
    })
    .filter((x): x is TradeCar => !!x);
}
type StockMovement = { id: string; delta: number; reason: string; notes: string | null; created_by: string; created_at: string; kind: "card" | "contract" };
type AuditLog = { id: string; actor_id: string; actor_name: string | null; action: string; entity: string; entity_id: string | null; details: unknown; created_at: string };
type AppNotification = { id: string; user_id: string; message: string; read: boolean; created_at: string };

const MASTER_APPROVER = "Pedro Lourenço";
const DEFAULT_CARDS_PER_CONTRACT = 50;
const DEFAULT_SHEET_NEXT_ROW = 6498;
const DEFAULT_SHEET_PACK_SIZE = 125;

type AppSettings = { cardsPerContract: number; sheetNextRow: number; sheetPackSize: number };
type TabDeny = { id: string; user_id: string; tab: string };

const TAB_KEYS = ["dashboard", "contratos", "stock", "registos", "lucros", "imobiliaria", "ranking"] as const;
type TabKey = typeof TAB_KEYS[number];
const TAB_LABELS: Record<TabKey, string> = {
  dashboard: "Dashboard", contratos: "Contratos", stock: "Stock",
  registos: "Registos", lucros: "Lucros", imobiliaria: "Imobiliária", ranking: "Ranking",
};



const OP_LABEL: Record<VehicleOpKind, string> = {
  compra: "Compra",
  venda: "Venda",
  troca_carros: "Troca/carros",
  troca_casas: "Troca/casas",
};

function extractParty(input: string): { name: string; id: string } {
  if (!input) return { name: "", id: "" };
  const line = input.split(/\r?\n/)[0] ?? "";
  const idMatch = line.match(/\bID\s+([A-Z0-9]{4,})/i);
  const id = idMatch ? idMatch[1].toUpperCase() : "";
  let s = line.replace(/^\s*(?:Comprador|Vendedor|Nome)\s*[:\-]\s*/i, "");
  s = s.split(/\s*[·•|]\s*/)[0];
  s = s.replace(/\s+ID\b.*$/i, "");
  return { name: s.trim(), id };
}

/** Extrai modelo e matrícula de texto colado do contrato ("modelo X," / "matrícula Y,"). */
function extractVehicle(input: string): { modelo: string; matricula: string } {
  const modMatch = input.match(/\bmodelo\s+(.+?)\s*,/i);
  const matMatch = input.match(/\bmatr[ií]cula\s+([A-Z0-9]+)\s*,/i);
  return {
    modelo: modMatch ? modMatch[1].trim() : "",
    matricula: matMatch ? matMatch[1].toUpperCase() : "",
  };
}

/** Formata dígitos com espaços de milhar para o input de valor (25 000 000). */
function groupDigits(digits: string): string {
  return digits.replace(/\B(?=(\d{3})+(?!\d))/g, " ");
}
const onlyDigits = (v: string) => v.replace(/[^\d]/g, "");

async function logAudit(actor: Profile | null, action: string, entity: string, entity_id: string | null, details?: Record<string, unknown>) {
  if (!actor) return;
  try {
    await supabase.from("audit_logs").insert({
      actor_id: actor.id,
      actor_name: actor.full_name,
      action, entity, entity_id,
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      details: (details ?? null) as any,
    });
  } catch { /* silent */ }
}

// Diferenças legíveis entre o registo antes/depois de uma edição.
const AUDIT_FIELD_LABEL: Record<string, string> = {
  matricula: "Matrícula", op: "Operação", valor: "Valor", modelo: "Modelo",
  contraparte_nome: "Nome contraparte", contraparte_id: "CC contraparte",
  matricula_entrada: "Matrícula/CP entrada", modelo_entrada: "Modelo entrada",
  notes: "Notas", extra_out: "Carros/casas que saem", extra_in: "Carros/casas que entram",
  is_mota: "Mota", casa_out: "Eu dou a casa", casa_in: "Eu recebo a casa",
};

function auditValue(v: unknown): string {
  if (v === null || v === undefined || v === "") return "—";
  if (typeof v === "boolean") return v ? "sim" : "não";
  if (Array.isArray(v)) {
    if (v.length === 0) return "—";
    return v.map((c) => {
      const x = c as { matricula?: string; modelo?: string; casa?: boolean };
      return `${x.casa ? "🏠 " : ""}${x.modelo || ""}${x.modelo && x.matricula ? " " : ""}${x.matricula || ""}`.trim();
    }).join(" + ");
  }
  return String(v);
}

function diffRecordFields(before: Record<string, unknown>, after: Record<string, unknown>) {
  const out: Array<{ campo: string; antes: string; depois: string }> = [];
  for (const k of Object.keys(AUDIT_FIELD_LABEL)) {
    const a = before[k] ?? null;
    const b = after[k] ?? null;
    const sa = auditValue(a);
    const sb = auditValue(b);
    if (sa !== sb) out.push({ campo: AUDIT_FIELD_LABEL[k], antes: sa, depois: sb });
  }
  return out;
}




function NotificationsBell({ notifications, onReadAll }: { notifications: AppNotification[]; onReadAll: () => void }) {
  const unread = notifications.filter((n) => !n.read).length;
  const fmtHora = (iso: string) => {
    const d = new Date(iso);
    const p = (n: number) => String(n).padStart(2, "0");
    return `${p(d.getDate())}/${p(d.getMonth() + 1)} ${p(d.getHours())}:${p(d.getMinutes())}`;
  };
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm" className="relative" aria-label="Notificações">
          <Bell className="h-4 w-4" />
          {unread > 0 && (
            <span className="absolute -top-1 -right-1 h-4 min-w-4 rounded-full bg-destructive text-destructive-foreground text-[10px] font-bold flex items-center justify-center px-1">
              {unread}
            </span>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent align="end" className="w-80 p-0">
        <div className="flex items-center justify-between px-3 py-2 border-b border-border/60">
          <p className="text-sm font-semibold">Notificações</p>
          {unread > 0 && (
            <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={onReadAll}>
              Marcar todas como lidas
            </Button>
          )}
        </div>
        <div className="max-h-80 overflow-y-auto">
          {notifications.length === 0 ? (
            <p className="text-sm text-muted-foreground p-4 text-center">Sem notificações.</p>
          ) : (
            notifications.map((n) => (
              <div key={n.id} className={`px-3 py-2 border-b border-border/40 last:border-0 ${n.read ? "opacity-60" : "bg-primary/5"}`}>
                <p className="text-sm leading-snug">{n.message}</p>
                <p className="text-[11px] text-muted-foreground mt-1">{fmtHora(n.created_at)}</p>
              </div>
            ))
          )}
        </div>
      </PopoverContent>
    </Popover>
  );
}

function AppPage() {
  const navigate = useNavigate();
  const [me, setMe] = useState<Profile | null>(null);
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [contracts, setContracts] = useState<Contract[]>([]);
  const [records, setRecords] = useState<VehicleRecord[]>([]);
  const [stock, setStock] = useState<StockMovement[]>([]);
  // (o stock é calculado a partir dos dados reais — ver cardStockTotal/contractStockTotal)
  const [audits, setAudits] = useState<AuditLog[]>([]);
  const [emails, setEmails] = useState<Record<string, string>>({});
  const [settings, setSettings] = useState<AppSettings>({ cardsPerContract: DEFAULT_CARDS_PER_CONTRACT, sheetNextRow: DEFAULT_SHEET_NEXT_ROW, sheetPackSize: DEFAULT_SHEET_PACK_SIZE });
  const [packUsage, setPackUsage] = useState<{ used: number; packSize: number } | null>(null);
  const [loading, setLoading] = useState(true);
  const [contractFilter, setContractFilter] = useState<string>("all");
  const [onlyUnpaid, setOnlyUnpaid] = useState(false);
  const [profitUserId, setProfitUserId] = useState<string>("");
  const [profitPeriod, setProfitPeriod] = useState<"all" | "7d" | "30d" | "month">("all");
  const [profitMonth, setProfitMonth] = useState<string>(() => new Date().toISOString().slice(0, 7));
  const [tabDenies, setTabDenies] = useState<TabDeny[]>([]);
  const [directory, setDirectory] = useState<Array<{ id: string; cc: string | null; email: string | null }>>([]);
  const [recordSearch, setRecordSearch] = useState("");
  const [rankFrom, setRankFrom] = useState<string>("");
  const [rankTo, setRankTo] = useState<string>("");
  const [feePayments, setFeePayments] = useState<FeePayment[]>([]);
  const [notifications, setNotifications] = useState<AppNotification[]>([]);

  const contractFilterInit = useRef(false);
  const cardsPerContract = settings.cardsPerContract;



  // O Supabase devolve no máximo 1000 linhas por pedido — sem isto os totais
  // deixavam de bater certo assim que se passava esse número de movimentos.
  const fetchAllRows = async <T,>(table: string, select = "*"): Promise<T[]> => {
    const out: T[] = [];
    const size = 1000;
    for (let from = 0; from < 50000; from += size) {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const { data, error } = await (supabase.from as any)(table)
        .select(select)
        .order("created_at", { ascending: false })
        .order("id", { ascending: false })
        .range(from, from + size - 1);
      if (error || !data) break;
      out.push(...(data as T[]));
      if ((data as T[]).length < size) break;
    }
    return out;
  };

  const loadSnapshot = async () => {
    const { data: userData } = await supabase.auth.getUser();
    const user = userData.user;
    if (!user) return;
    const [{ data: ps }, cs, rs, ms, myCcRes, { data: al }, settingsRes, feeRes] = await Promise.all([
      supabase.from("profiles").select("id, full_name, approved, active, left_at, discord_id, fee_mode").order("full_name"),
      fetchAllRows<Contract>("contracts", "id, seller_id, card_paid, card_value, quantity, notes, created_at"),
      fetchAllRows<Record<string, unknown>>("vehicle_records"),
      fetchAllRows<StockMovement>("card_stock_movements"),
      getMyCc().catch(() => ({ cc: null as string | null })),
      supabase.from("audit_logs").select("*").order("created_at", { ascending: false }).limit(500),
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (supabase.from as any)("app_settings").select("key, value_int"),
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      (supabase.from as any)("fee_payments").select("*"),
    ]);
    setFeePayments((((feeRes as { data?: FeePayment[] })?.data) || []).map((f) => ({ ...f, profit: Number(f.profit), fee: Number(f.fee) })));
    const rows = ((settingsRes as { data?: Array<{ key: string; value_int: number | null }> })?.data) || [];
    const kv = new Map(rows.map((r) => [r.key, r.value_int ?? 0]));
    const nextSettings = {
      cardsPerContract: kv.get("cards_per_contract") || DEFAULT_CARDS_PER_CONTRACT,
      sheetNextRow: kv.get("sheet_next_row") || DEFAULT_SHEET_NEXT_ROW,
      sheetPackSize: kv.get("sheet_pack_size") || DEFAULT_SHEET_PACK_SIZE,
    };
    setSettings(nextSettings);
    // O pack mostrado no dashboard vem do Sheets (fonte de verdade).
    getSheetPackUsage({ data: { startRow: nextSettings.sheetNextRow, packSize: nextSettings.sheetPackSize } })
      .then((r) => { if (r && r.ok) setPackUsage({ used: r.used, packSize: r.packSize }); })
      .catch(() => {});


    const profilesList: Profile[] = ((ps as Array<{ id: string; full_name: string; approved: boolean; active?: boolean | null; left_at?: string | null; discord_id?: string | null; fee_mode?: boolean | null }>) || []).map((p) => ({
      id: p.id,
      full_name: p.full_name,
      approved: p.approved,
      active: p.active !== false,
      left_at: p.left_at ?? null,
      discord_id: p.discord_id ?? null,
      fee_mode: p.fee_mode === true,
      cc: null,
    }));
    const meProfile = profilesList.find((p) => p.id === user.id) || null;
    if (meProfile) meProfile.cc = myCcRes?.cc ?? null;
    setProfiles(profilesList);
    setContracts(cs || []);
    setRecords((rs || []).map((r) => ({
      ...(r as unknown as VehicleRecord),
      extra_out: normalizeTradeCars(r.extra_out),
      extra_in: normalizeTradeCars(r.extra_in),
      sheet_extra_rows: Array.isArray(r.sheet_extra_rows) ? (r.sheet_extra_rows as number[]) : [],
    })));
    setStock(ms || []);
    setAudits((al as AuditLog[]) || []);

    setMe(meProfile);
    setLoading(false);

    // Notificações do próprio utilizador (RLS limita às dele)
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data: notifs } = await (supabase.from as any)("notifications").select("*").order("created_at", { ascending: false }).limit(50);
    setNotifications((notifs as AppNotification[]) || []);

    // Filtro de contratos: por defeito o próprio vendedor
    if (meProfile && !contractFilterInit.current) {
      contractFilterInit.current = true;
      setContractFilter(meProfile.id);
    }

    // Tab denies (RLS: próprio ou owner)
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data: tds } = await (supabase.from as any)("user_tab_denies").select("id, user_id, tab");
    setTabDenies((tds as TabDeny[]) || []);

    // Owner: diretório da equipa (CC + email)
    if (meProfile && OWNERS.has(meProfile.full_name)) {
      try {
        const dir = await listTeamDirectory();
        setDirectory((dir as Array<{ id: string; cc: string | null; email: string | null }>) || []);
        if (meProfile.full_name === MASTER_APPROVER) {
          setEmails(Object.fromEntries(dir.flatMap((person) => person.email ? [[person.id, person.email]] : [])));
        }
      } catch { /* silent */ }
    }

  };

  // No artificial delay: changes during a read are picked up by one trailing read.
  const refreshRef = useRef<(() => Promise<void>) | undefined>(undefined);
  if (!refreshRef.current) refreshRef.current = createSerialRefresh(loadSnapshot);
  const load = () => refreshRef.current?.() ?? Promise.resolve();

  useEffect(() => { void load(); }, []);

  // Realtime: refresh when qualquer tabela relevante muda
  useEffect(() => {
    const channel = supabase
      .channel("app-realtime")
      .on("postgres_changes", { event: "*", schema: "public", table: "vehicle_records" }, () => void load())
      .on("postgres_changes", { event: "*", schema: "public", table: "contracts" }, () => void load())
      .on("postgres_changes", { event: "*", schema: "public", table: "card_stock_movements" }, () => void load())
      .on("postgres_changes", { event: "*", schema: "public", table: "profiles" }, () => void load())
      .on("postgres_changes", { event: "*", schema: "public", table: "audit_logs" }, () => void load())
      .on("postgres_changes", { event: "*", schema: "public", table: "app_settings" }, () => void load())
      .on("postgres_changes", { event: "*", schema: "public", table: "user_tab_denies" }, () => void load())
      .on("postgres_changes", { event: "*", schema: "public", table: "fee_payments" }, () => void load())
      .on("postgres_changes", { event: "*", schema: "public", table: "notifications" }, () => void load())
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, []);

  const nameOf = (id: string) => profiles.find((p) => p.id === id)?.full_name || "—";

  // Cada carro de um registo é 1 contrato (trocas podem ter vários carros).
  // As casas (troca/casas) não gastam contrato.
  const carsOf = (r: VehicleRecord) =>
    isTroca(r.op)
      ? (r.op === "troca_casas" ? 1 : 2)
        + (r.extra_out ?? []).filter((c) => !c.casa).length
        + (r.extra_in ?? []).filter((c) => !c.casa).length
      : 1;

  const totalCars = records.reduce((s, r) => s + carsOf(r), 0);
  const myCars = records.filter((r) => r.seller_id === me?.id).reduce((s, r) => s + carsOf(r), 0);
  // Data do primeiro registo (desde quando contamos os contratos gastos).
  const firstRecordDate = records.reduce<string>((min, r) => (!min || r.created_at < min ? r.created_at : min), "");
  const fmtDate = (iso: string) => {
    if (!iso) return "—";
    const d = new Date(iso);
    const p = (n: number) => String(n).padStart(2, "0");
    return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()}`;
  };

  // Pesquisa na aba Registos (matrícula, modelo, nomes, CC e notas).
  const filteredRecords: VehicleRecord[] = (() => {
    const q = recordSearch.trim().toLowerCase();
    if (!q) return records;
    return records.filter((r) => {
      const parts: string[] = [
        r.matricula, r.modelo || "", r.matricula_entrada || "", r.modelo_entrada || "",
        r.contraparte_nome || "", r.contraparte_id || "", r.comprador || "", r.notes || "",
        nameOf(r.seller_id), String(r.valor), r.partner_id ? nameOf(r.partner_id) : "",
        ...(r.extra_out || []).flatMap((c) => [c.matricula, c.modelo]),
        ...(r.extra_in || []).flatMap((c) => [c.matricula, c.modelo]),
      ];
      return parts.some((p) => (p || "").toLowerCase().includes(q));
    });
  })();

  // ---- Packs do Sheets ----
  // Cada pack ocupa `sheetPackSize` linhas + 1 linha em branco de separação.
  // O pack atual começa em settings.sheetNextRow; os anteriores têm índice negativo.
  const packBase = settings.sheetNextRow;
  const packStride = settings.sheetPackSize + 1;
  const packOf = (row: number | null | undefined) => {
    if (!row) return null;
    const idx = Math.floor((row - packBase) / packStride);
    const start = packBase + idx * packStride;
    return { idx, start, end: start + settings.sheetPackSize - 1, pos: row - start + 1 };
  };
  const PACK_BORDERS = ["border-l-primary", "border-l-success", "border-l-warning", "border-l-accent"];
  const packBorder = (idx: number | null) =>
    idx === null ? "border-l-muted" : PACK_BORDERS[((idx % PACK_BORDERS.length) + PACK_BORDERS.length) % PACK_BORDERS.length];
  const packLabel = (idx: number | null) =>
    idx === null ? "Sem linha no Sheets" : idx === 0 ? "Pack atual" : idx < 0 ? `Pack ${idx}` : `Pack +${idx}`;





  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate({ to: "/auth" });
  };

  // ---- Cartão devidos por vendedor (1 contrato = 50 cartão) ----
  // Quem paga taxa (10% do lucro) está isento de cartão, tal como o owner.
  const feeUsers = useMemo(() => new Set(profiles.filter((p) => p.fee_mode).map((p) => p.id)), [profiles]);
  const cardDebtByUser = useMemo(() => {
    const map = new Map<string, { name: string; owedContracts: number; paidContracts: number; totalContracts: number; active: boolean; fee: boolean }>();
    for (const p of profiles) {
      map.set(p.id, { name: p.full_name, owedContracts: 0, paidContracts: 0, totalContracts: 0, active: p.active, fee: p.fee_mode });
    }
    for (const c of contracts) {
      const entry = map.get(c.seller_id);
      if (!entry) continue;
      entry.totalContracts += 1;
      if (OWNERS.has(entry.name) || entry.fee) continue;
      if (c.card_paid) entry.paidContracts += 1; else entry.owedContracts += 1;
    }
    return Array.from(map.entries())
      // Ex-vendedores não aparecem na dashboard (os registos deles mantêm-se na aba Registos).
      .filter(([, v]) => v.active)
      .map(([id, v]) => {
        const isento = OWNERS.has(v.name) || v.fee;
        return {
          id, ...v,
          owedCards: isento ? 0 : v.owedContracts * cardsPerContract,
          paidCards: isento ? 0 : v.paidContracts * cardsPerContract,
          owner: OWNERS.has(v.name),
        };
      }).sort((a, b) => b.owedCards - a.owedCards);
  }, [contracts, profiles, cardsPerContract]);

  const totalOwedCards = cardDebtByUser.reduce((s, x) => s + x.owedCards, 0);

  const profitByMatricula = useMemo(() => {
    // Um carro pode ser comprado e vendido várias vezes. Cada "ciclo"
    // (entrada -> saída) é calculado à parte: se o carro voltar a ser
    // comprado, começa um novo lucro (não soma ao anterior).
    type Ev = {
      mat: string; at: string; rec: VehicleRecord;
      kind: "in" | "out";
      // entrada: custo directo (compra) ou troca (custo herdado)
      cost?: number;              // compra / troca-casas em que compro
      tradeOuts?: string[];       // matrículas que saem nessa troca
      topUp?: number; share?: number;
      revenue?: number;           // saída: venda / troca-casas em que vendo
      tradeAway?: boolean;        // saída por troca de carros
      houseDeal?: boolean;        // saiu numa troca por casa (fica pendente)
      houseIn?: boolean;          // entrou numa troca por casa (custo não é fiável)
      /** Dono do evento (por defeito o autor do registo). Nos negócios internos
       *  o outro lado é o membro do stand indicado em partner_id. */
      ownerId?: string;
      internal?: boolean;         // evento espelhado de um negócio interno
    };



    const evs: Ev[] = [];
    for (const r of records) {
      const mat = r.matricula.trim().toUpperCase();
      const partner = r.partner_id || null;
      if (r.op === "compra") {
        // Negócio interno: quem me vendeu foi um colega — fecha o ciclo dele.
        if (partner) evs.push({ mat, at: r.created_at, rec: r, kind: "out", revenue: Math.abs(Number(r.valor) || 0), ownerId: partner, internal: true });
        evs.push({ mat, at: r.created_at, rec: r, kind: "in", cost: Math.abs(Number(r.valor) || 0) });
      } else if (r.op === "venda") {
        evs.push({ mat, at: r.created_at, rec: r, kind: "out", revenue: Math.abs(Number(r.valor) || 0) });
        // Negócio interno: quem comprou foi um colega — o carro entra para ele.
        if (partner) evs.push({ mat, at: r.created_at, rec: r, kind: "in", cost: Math.abs(Number(r.valor) || 0), ownerId: partner, internal: true });

      } else if (r.op === "troca_casas") {
        // Se eu dou a casa (casa_out) => os carros ENTRAM; se recebo a casa => os carros SAEM.
        const mainIn = houseGiven(r);
        const outs = [
          ...(mainIn ? [] : [mat]),
          ...(r.extra_out ?? []).filter((c) => !c.casa).map((c) => c.matricula.trim().toUpperCase()),
        ].filter(Boolean);
        const ins = [
          ...(mainIn ? [mat] : []),
          ...(r.extra_in ?? []).filter((c) => !c.casa).map((c) => c.matricula.trim().toUpperCase()),
        ].filter(Boolean);
        // Carros que saem por casa ficam pendentes ("negócio casa").
        for (const o of outs) evs.push({ mat: o, at: r.created_at, rec: r, kind: "out", revenue: 0, houseDeal: true });
        // Carros que entram: custo = dinheiro que dei, dividido por eles.
        for (const i of ins) evs.push({ mat: i, at: r.created_at, rec: r, kind: "in", houseIn: true, cost: Math.max(0, Number(r.valor) || 0) / Math.max(1, ins.length) });
      } else {

        // troca_carros: saem uns carros, entram outros
        const outs = [mat, ...(r.extra_out ?? []).filter((c) => !c.casa).map((c) => c.matricula.trim().toUpperCase())].filter(Boolean);
        const ins = [
          ...(r.matricula_entrada ? [r.matricula_entrada.trim().toUpperCase()] : []),
          ...(r.extra_in ?? []).filter((c) => !c.casa).map((c) => c.matricula.trim().toUpperCase()),
        ].filter(Boolean);
        for (const o of outs) evs.push({ mat: o, at: r.created_at, rec: r, kind: "out", tradeAway: true });
        for (const i of ins) evs.push({ mat: i, at: r.created_at, rec: r, kind: "in", tradeOuts: outs, topUp: Number(r.valor) || 0, share: Math.max(1, ins.length) });
      }
    }

    evs.sort((a, b) => a.at.localeCompare(b.at));

    type Cycle = { mat: string; inEv: Ev | null; outEv: Ev | null };
    const byMat = new Map<string, Cycle[]>();
    for (const e of evs) {
      const arr = byMat.get(e.mat) || [];
      const open = arr.length ? arr[arr.length - 1] : null;
      if (e.kind === "in") {
        if (open && !open.outEv && open.inEv) arr.push({ mat: e.mat, inEv: e, outEv: null });
        else if (open && !open.inEv && !open.outEv) open.inEv = e;
        else arr.push({ mat: e.mat, inEv: e, outEv: null });
      } else {
        if (open && !open.outEv) open.outEv = e;
        else arr.push({ mat: e.mat, inEv: null, outEv: e });
      }
      byMat.set(e.mat, arr);
    }

    // Custo de um ciclo (recursivo para trocas, com guarda de ciclos).
    const cache = new Map<Cycle, number | null>();
    const seen = new Set<Cycle>();
    const cycleClosedBy = (mat: string, rec: VehicleRecord): Cycle | null =>
      (byMat.get(mat) || []).find((c) => c.outEv?.rec.id === rec.id) || null;
    const costOf = (c: Cycle): number | null => {
      if (cache.has(c)) return cache.get(c)!;
      if (seen.has(c)) return null;
      seen.add(c);
      let cost: number | null = null;
      const ev = c.inEv;
      if (ev) {
        if (ev.cost != null) cost = ev.cost;
        else if (ev.tradeOuts) {
          let sum = 0; let ok = true;
          for (const o of ev.tradeOuts) {
            const oc = cycleClosedBy(o, ev.rec);
            const v = oc ? costOf(oc) : null;
            if (v == null) { ok = false; break; }
            sum += v;
          }
          if (ok) cost = (sum + (ev.topUp ?? 0)) / Math.max(1, ev.share ?? 1);
        }
      }
      cache.set(c, cost);
      seen.delete(c);
      return cost;
    };

    // Um carro vindo de negócio de casas não tem custo fiável — e essa
    // incerteza passa para os carros que entram nas trocas seguintes.
    const unreliableCache = new Map<Cycle, boolean>();
    const unreliableSeen = new Set<Cycle>();
    const isHouseSourced = (c: Cycle): boolean => {
      if (unreliableCache.has(c)) return unreliableCache.get(c)!;
      if (unreliableSeen.has(c)) return false;
      unreliableSeen.add(c);
      let res = false;
      const ev = c.inEv;
      if (ev) {
        if (ev.houseIn) res = true;
        else if (ev.tradeOuts) {
          for (const o of ev.tradeOuts) {
            const oc = cycleClosedBy(o, ev.rec);
            if (oc && isHouseSourced(oc)) { res = true; break; }
          }
        }
      }
      unreliableCache.set(c, res);
      unreliableSeen.delete(c);
      return res;
    };

    const rows: Array<{ matricula: string; modelo: string; compra: number; receitas: number; lucro: number; hasCompra: boolean; pending: boolean; houseDeal: boolean; houseSourced: boolean; buyerSellerId: string | null; lastSellerId: string | null; outSellerId: string | null; internal: boolean; outRecordId: string | null; entries: VehicleRecord[]; tradedAway: boolean; inherited: boolean; refDate: string; cycle: number }> = [];
    for (const [mat, cycles] of byMat) {
      cycles.forEach((c, idx) => {
        const cost = costOf(c);
        const hasCost = cost != null;
        const houseDeal = !!c.outEv?.houseDeal;
        const receitas = houseDeal ? 0 : (c.outEv?.revenue ?? 0);
        const soldOut = !!c.outEv && !c.outEv.tradeAway && !houseDeal;
        const tradedAway = !!c.outEv?.tradeAway;
        const houseSourced = isHouseSourced(c);
        // Carros que vieram de um negócio de casas não têm custo fiável:
        // a venda não pode contar como lucro total.
        const lucro = soldOut && hasCost && !houseSourced ? receitas - (cost as number) : 0;
        const entries = [c.inEv?.rec, c.outEv?.rec].filter(Boolean) as VehicleRecord[];
        // Modelo do próprio carro (nunca o tipo da casa do negócio).
        const modelOf = (r: VehicleRecord): string | null => {
          const U = (s?: string | null) => (s || "").trim().toUpperCase();
          if (U(r.matricula) === mat) return r.modelo || null;
          if (r.op === "troca_carros" && U(r.matricula_entrada) === mat) return r.modelo_entrada || null;
          const ex = [...(r.extra_out || []), ...(r.extra_in || [])].find((x) => !x.casa && U(x.matricula) === mat);
          return ex?.modelo || null;
        };
        const notCasa = (m: string | null | undefined) => !!m && m.trim() !== "" && m.trim().toLowerCase() !== "casa";
        const modelo = entries.map(modelOf).find(notCasa)
          || records.map(modelOf).find(notCasa) || "";
        rows.push({
          matricula: mat, modelo,
          compra: cost ?? 0,
          receitas, lucro,
          hasCompra: hasCost,
          pending: hasCost && (!c.outEv || houseDeal),
          houseDeal,
          houseSourced,
          buyerSellerId: c.inEv ? (c.inEv.ownerId ?? c.inEv.rec.seller_id) : null,
          lastSellerId: soldOut && c.outEv ? (c.outEv.ownerId ?? c.outEv.rec.seller_id) : null,
          internal: !!(c.inEv?.internal || c.outEv?.internal),
          outRecordId: c.outEv?.rec.id ?? null,
          outSellerId: c.outEv ? (c.outEv.ownerId ?? c.outEv.rec.seller_id) : null,

          entries,
          tradedAway,
          inherited: !!c.inEv?.tradeOuts,
          refDate: c.outEv?.at || c.inEv?.at || "",
          cycle: idx + 1,
        });
      });
    }

    return rows.sort((a, b) => Number(b.pending) - Number(a.pending) || b.lucro - a.lucro);
  }, [records]);

  // Lucros filtrados por período (data da última venda / último movimento).
  const profitRows = useMemo(() => {
    if (profitPeriod === "all") return profitByMatricula;
    return profitByMatricula.filter((r) => {
      if (!r.refDate) return false;
      if (profitPeriod === "month") return r.refDate.slice(0, 7) === profitMonth;
      const days = profitPeriod === "7d" ? 7 : 30;
      return new Date(r.refDate).getTime() >= Date.now() - days * 86400000;
    });
  }, [profitByMatricula, profitPeriod, profitMonth]);


  const ranking = useMemo(() => {
    // Filtro de datas do ranking (vazio = desde sempre / até hoje).
    const fromTs = rankFrom ? new Date(`${rankFrom}T00:00:00`).getTime() : null;
    const toTs = rankTo ? new Date(`${rankTo}T23:59:59`).getTime() : null;
    const inRange = (iso: string) => {
      if (!iso) return fromTs === null && toTs === null ? true : false;
      const t = new Date(iso).getTime();
      if (fromTs !== null && t < fromTs) return false;
      if (toTs !== null && t > toTs) return false;
      return true;
    };
    const map = new Map<string, { name: string; contracts: number; sales: number; trades: number; profitAttrib: number; salesValue: number; purchases: number; purchasesValue: number; pendingCount: number; pendingValue: number }>();
    for (const p of profiles) map.set(p.id, { name: p.full_name, contracts: 0, sales: 0, trades: 0, profitAttrib: 0, salesValue: 0, purchases: 0, purchasesValue: 0, pendingCount: 0, pendingValue: 0 });
    for (const c of contracts) {
      if (!inRange(c.created_at)) continue;
      const e = map.get(c.seller_id); if (e) e.contracts += 1;
    }
    for (const r of records) {
      if (!inRange(r.created_at)) continue;
      const e = map.get(r.seller_id); if (!e) continue;
      if (r.op === "compra") {
        e.purchases += 1;
        e.purchasesValue += Math.abs(Number(r.valor));
      } else if (r.op === "venda") {
        e.sales += 1;
        e.salesValue += Math.abs(Number(r.valor));
      } else {
        // Trocas: o valor é só a diferença dada/recebida — não conta como
        // volume de compras nem de vendas (senão dava totais negativos).
        e.trades += 1;
      }
      // Negócio interno: o outro lado do negócio também conta para o colega
      // (volume de compras/vendas), mas nunca gasta contrato nem cartão.
      if (r.partner_id) {
        const pe = map.get(r.partner_id);
        if (pe) {
          if (r.op === "compra") { pe.sales += 1; pe.salesValue += Math.abs(Number(r.valor)); }
          else if (r.op === "venda") { pe.purchases += 1; pe.purchasesValue += Math.abs(Number(r.valor)); }
        }
      }
    }


    for (const row of profitByMatricula) {
      if (!inRange(row.refDate)) continue;
      if (row.pending && row.buyerSellerId) {
        const e = map.get(row.buyerSellerId); if (e) { e.pendingCount += 1; e.pendingValue += row.compra; }
        continue;
      }
      if (!row.lastSellerId) continue;
      const e = map.get(row.lastSellerId); if (!e) continue;
      e.profitAttrib += row.lucro;
    }

    const inactive = new Set(profiles.filter((p) => !p.active).map((p) => p.id));
    return Array.from(map.entries())
      .map(([id, v]) => ({ id, ...v }))
      // Ex-vendedores saem do ranking/dashboard; os registos deles permanecem na aba Registos.
      .filter((v) => !inactive.has(v.id))
      .sort((a, b) => b.profitAttrib - a.profitAttrib);
  }, [contracts, records, profitByMatricula, profiles, rankFrom, rankTo]);

  // ---- Imobiliária: cada troca/casas é um negócio de casa à parte ----
  // Custo = custo dos carros que dei + dinheiro que dei.
  // Retorno = venda dos carros que recebi + dinheiro que recebi.
  // Enquanto os carros recebidos não forem vendidos, o negócio fica pendente.
  const houseDeals = useMemo(() => {
    const up = (s: string) => s.trim().toUpperCase();
    return records
      .filter((r) => r.op === "troca_casas")
      .map((r) => {
        const iGaveHouse = houseGiven(r);
        const casas = [
          ...(r.matricula_entrada ? [casaText(r.modelo_entrada || "Casa", r.matricula_entrada)] : []),
          ...[...(r.extra_out || []), ...(r.extra_in || [])].filter((c) => c.casa).map((c) => casaText(c.modelo || "Casa", c.matricula)),
        ];
        const carsOut = [
          ...(iGaveHouse ? [] : [{ matricula: up(r.matricula), modelo: r.modelo || "" }]),
          ...(r.extra_out || []).filter((c) => !c.casa).map((c) => ({ matricula: up(c.matricula), modelo: c.modelo })),
        ];
        const carsIn = [
          ...(iGaveHouse ? [{ matricula: up(r.matricula), modelo: r.modelo || "" }] : []),
          ...(r.extra_in || []).filter((c) => !c.casa).map((c) => ({ matricula: up(c.matricula), modelo: c.modelo })),
        ];
        const money = Number(r.valor) || 0; // > 0 = fui eu que dei dinheiro

        let custoCarros = 0; let custoIncompleto = false;
        for (const c of carsOut) {
          const row = profitByMatricula.find((x) => x.matricula === c.matricula && x.houseDeal && x.entries.some((e) => e.id === r.id));
          if (row?.hasCompra) custoCarros += row.compra; else custoIncompleto = true;
        }
        let retornoCarros = 0;
        const pendentes: string[] = [];
        for (const c of carsIn) {
          const row = profitByMatricula.find((x) => x.matricula === c.matricula && x.houseSourced && x.entries.some((e) => e.id === r.id));
          if (row && !row.pending && row.receitas > 0) retornoCarros += row.receitas;
          else pendentes.push(c.modelo?.trim() || c.matricula);
        }
        const custo = custoCarros + Math.max(0, money);
        const retorno = retornoCarros + Math.max(0, -money);
        return {
          rec: r, iGaveHouse, casas, carsOut, carsIn, money,
          custo, retorno, lucro: retorno - custo,
          pendentes, custoIncompleto,
          fechado: pendentes.length === 0 && !custoIncompleto,
        };
      })
      .sort((a, b) => b.rec.created_at.localeCompare(a.rec.created_at));
  }, [records, profitByMatricula]);


  const myContracts = contracts.filter((c) => c.seller_id === me?.id);
  const myOwedCards = myContracts.filter((c) => !c.card_paid).length * cardsPerContract;

  if (loading) {
    return <div className="min-h-screen flex items-center justify-center text-muted-foreground">A carregar…</div>;
  }

  const isOwner = me ? OWNERS.has(me.full_name) : false;
  const isMaster = me?.full_name === MASTER_APPROVER;
  // Stock calculado a partir dos dados reais (registos + contratos), para não
  // haver desvios quando se apaga ou edita um registo. Os movimentos
  // automáticos antigos ficam no histórico mas não entram na conta.
  const manualStock = (k: "card" | "contract") =>
    stock.filter((m) => m.kind === k && !AUTO_REASONS.has(m.reason)).reduce((s, m) => s + Number(m.delta || 0), 0);
  const cardsDelivered = contracts.reduce((s, c) => s + (c.card_paid ? Number(c.card_value || 0) : 0), 0);
  // Contratos realmente levantados (tabela de contratos) — mesma fonte no Dashboard e no Stock.
  const contractsIssued = contracts.reduce((s, c) => s + Number(c.quantity || 1), 0);
  const cardStockTotal = manualStock("card") + cardsDelivered;
  const contractStockTotal = manualStock("contract") - contractsIssued;


  // Linhas gastas no pack atual — valor lido diretamente do Sheets.
  const packStart = settings.sheetNextRow;
  const packEnd = settings.sheetNextRow + settings.sheetPackSize - 1;
  const contractsUsedInPack = packUsage
    ? packUsage.used
    : records.reduce((s, r) => {
        const row = (r as { sheet_row?: number | null }).sheet_row;
        return row && row >= packStart && row <= packEnd ? s + carsOf(r) : s;
      }, 0);
  const packSizeShown = packUsage?.packSize ?? settings.sheetPackSize;
  // O stock real (contratos por usar) é a fonte de verdade; as linhas do pack
  // servem só para mostrar quanto já foi escrito no Sheets.
  const contractsLeftInPack = Math.max(0, contractStockTotal);

  const myDenied = new Set(tabDenies.filter((d) => d.user_id === me?.id).map((d) => d.tab));
  // Quem paga taxa não deve cartão nem levanta contratos → a aba Contratos não faz sentido.
  const paysFee = !isOwner && me?.fee_mode === true;
  const canSee = (tab: TabKey) => {
    if (tab === "contratos" && paysFee) return false;
    return isOwner || !myDenied.has(tab);
  };
  const canWrite = (tab: TabKey) => {
    if (tab === "contratos" && paysFee) return false;
    return isOwner || (!myDenied.has(tab) && !myDenied.has(`${tab}:write`));
  };
  // Sub-permissões (ex: stock:adjust, stock:pack) — só válidas se já pode editar a aba.
  const canWriteSub = (tab: TabKey, sub: string) =>
    canWrite(tab) && (isOwner || !myDenied.has(`${tab}:${sub}`));

  


  if (me && !me.active && !isMaster) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4">
        <Card className="max-w-md w-full">
          <CardHeader>
            <CardTitle>Conta arquivada</CardTitle>
            <CardDescription>A conta de {me.full_name} já não faz parte da equipa ativa. Os registos continuam guardados; fala com o {MASTER_APPROVER} se precisares de voltar.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="outline" onClick={handleLogout} className="w-full">
              <LogOut className="h-4 w-4 mr-2" /> Sair
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (me && !me.approved && !isMaster) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4">
        <Card className="max-w-md w-full">
          <CardHeader>
            <CardTitle>À espera de aprovação</CardTitle>
            <CardDescription>A tua conta ({me.full_name}) tem de ser aprovada pelo {MASTER_APPROVER} antes de poderes entrar.</CardDescription>
          </CardHeader>
          <CardContent>
            <Button variant="outline" onClick={handleLogout} className="w-full">
              <LogOut className="h-4 w-4 mr-2" /> Sair
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  const pendingCount = profiles.filter((p) => !p.approved && p.active && p.full_name !== MASTER_APPROVER).length;

  return (
    <div className="min-h-screen">
      <header className="border-b border-border/60 bg-card/50 backdrop-blur sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-primary flex items-center justify-center shadow-lg shadow-primary/30">
              <Wrench className="h-5 w-5 text-primary-foreground" />
            </div>
            <div>
              <h1 className="text-lg font-bold leading-tight">Stand Tuners</h1>
              <p className="text-xs text-muted-foreground">Olá, {me?.full_name} {isOwner && <Badge variant="outline" className="ml-1 border-primary text-primary">OWNER</Badge>}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {isOwner && <NotificationsBell notifications={notifications} onReadAll={async () => {
              const unread = notifications.filter((n) => !n.read).map((n) => n.id);
              if (unread.length === 0) return;
              // eslint-disable-next-line @typescript-eslint/no-explicit-any
              await (supabase.from as any)("notifications").update({ read: true }).in("id", unread);
              setNotifications((ns) => ns.map((n) => ({ ...n, read: true })));
            }} />}
            <ChangePasswordDialog />
            <Button variant="ghost" size="sm" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" /> Sair
            </Button>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-6">
        <Tabs defaultValue="dashboard">
          <TabsList className="flex flex-wrap justify-start w-full mb-6 h-auto gap-2 p-2">
            {canSee("dashboard") && <TabsTrigger value="dashboard" className="py-3 px-5 text-base font-semibold"><TrendingUp className="h-5 w-5 mr-2" />Dashboard</TabsTrigger>}
            {canSee("contratos") && <TabsTrigger value="contratos" className="py-3 px-5 text-base font-semibold"><FilePlus2 className="h-5 w-5 mr-2" />Contratos</TabsTrigger>}
            
            {canSee("stock") && <TabsTrigger value="stock" className="py-3 px-5 text-base font-semibold"><Package className="h-5 w-5 mr-2" />Stock</TabsTrigger>}
            {canSee("registos") && (
              <TabsTrigger
                value="registos"
                className="py-3 px-6 text-base font-bold border border-primary/60 text-primary data-[state=active]:bg-primary data-[state=active]:text-primary-foreground"
              >
                <Car className="h-5 w-5 mr-2" />Registos
              </TabsTrigger>
            )}
            {canSee("lucros") && <TabsTrigger value="lucros" className="py-3 px-5 text-base font-semibold"><TrendingUp className="h-5 w-5 mr-2" />Lucros</TabsTrigger>}
            {/* Imobiliária oculta para já — o conteúdo continua no código */}

            {(isOwner || me?.fee_mode) && <TabsTrigger value="taxas" className="py-3 px-5 text-base font-semibold"><Percent className="h-5 w-5 mr-2" />Taxas</TabsTrigger>}
            {canSee("ranking") && <TabsTrigger value="ranking" className="py-3 px-5 text-base font-semibold"><Trophy className="h-5 w-5 mr-2" />Ranking</TabsTrigger>}
            <TabsTrigger value="perfil" className="py-3 px-5 text-base font-semibold"><UserIcon className="h-5 w-5 mr-2" />Perfil</TabsTrigger>
            <TabsTrigger value="equipa" className="py-3 px-5 text-base font-semibold"><Users className="h-5 w-5 mr-2" />Equipa</TabsTrigger>
            {isOwner && <TabsTrigger value="gestao" className="py-3 px-5 text-base font-semibold"><Wrench className="h-5 w-5 mr-2" />Gestão</TabsTrigger>}

            {(isMaster || isOwner) && (
              <TabsTrigger value="admin" className="py-3 px-5 text-base font-semibold">
                <ShieldCheck className="h-5 w-5 mr-2" />Admin
                {isMaster && pendingCount > 0 && <Badge className="ml-1.5 bg-warning text-warning-foreground">{pendingCount}</Badge>}
              </TabsTrigger>
            )}
          </TabsList>



          <TabsContent value="dashboard" className="space-y-6">
            <section className="space-y-4">
              <h2 className="text-lg font-bold flex items-center gap-2"><Users className="h-5 w-5 text-primary" /> Geral do Stand</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <StatCard icon={<Users className="h-5 w-5" />} label="Contratos gastos (equipa)" value={String(contractsIssued)} description={firstRecordDate ? `Desde ${fmtDate(firstRecordDate)} · 1 viatura = 1 contrato` : "1 viatura registada = 1 contrato"} />
                <StatCard icon={<CreditCard className="h-5 w-5" />} label="Total cartão em dívida" value={String(totalOwedCards)} accent={totalOwedCards > 0 ? "warning" : undefined} />
                <StatCard icon={<Car className="h-5 w-5" />} label="Contratos restantes (pack atual)" value={String(contractsLeftInPack)} description={`${contractsUsedInPack}/${packSizeShown} nas linhas`} accent={contractsLeftInPack <= 10 ? "warning" : undefined} />
                <StatCard icon={<Package className="h-5 w-5" />} label="Stock de cartão" value={String(cardStockTotal)} />
              </div>
              <div className="grid md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader><CardTitle>Top 3 vendedores (lucro)</CardTitle></CardHeader>
                  <CardContent className="space-y-2">
                    {ranking.slice(0, 3).map((r, i) => (
                      <div key={r.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary/50">
                        <div className="flex items-center gap-3">
                          <div className={`h-8 w-8 rounded-full flex items-center justify-center font-bold ${i === 0 ? "bg-primary text-primary-foreground" : "bg-muted text-foreground"}`}>{i + 1}</div>
                          <span className="font-medium">{r.name}</span>
                        </div>
                        <span className="font-mono font-semibold text-success">{fmt(r.profitAttrib)}</span>
                      </div>
                    ))}
                  </CardContent>
                </Card>
                <Card>
                  <CardHeader><CardTitle>Cartão em dívida por vendedor <span className="text-sm font-normal text-muted-foreground">(1 contrato = {cardsPerContract} cartão)</span></CardTitle></CardHeader>
                  <CardContent className="p-0">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Vendedor</TableHead>
                          <TableHead>Contratos</TableHead>
                          <TableHead>Entregues</TableHead>
                          <TableHead>Em dívida</TableHead>
                          {isOwner && <TableHead className="text-right">Aviso</TableHead>}
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {cardDebtByUser.map((r) => (
                          <TableRow key={r.id}>
                            <TableCell className="font-medium">{r.name}</TableCell>
                            <TableCell>{r.totalContracts}</TableCell>
                            <TableCell className="text-success">{r.owner || r.fee ? "N/A" : r.paidCards}</TableCell>
                            <TableCell className={`font-mono font-semibold ${r.owedCards > 0 ? "text-warning" : "text-muted-foreground"}`}>{r.owner ? <Badge variant="outline">0 (owner)</Badge> : r.fee ? <Badge variant="outline" className="border-primary text-primary">Taxa</Badge> : r.owedCards}</TableCell>
                            {isOwner && (
                              <TableCell className="text-right">
                                {!r.owner && !r.fee && r.owedCards > 0 && (
                                  <DebtReminderButton userId={r.id} name={r.name} missing={r.owedCards} hasDiscord={!!profiles.find((p) => p.id === r.id)?.discord_id} />
                                )}
                              </TableCell>
                            )}
                          </TableRow>
                        ))}
                        {cardDebtByUser.length === 0 && (
                          <TableRow><TableCell colSpan={isOwner ? 5 : 4} className="text-center text-muted-foreground py-6">Sem dados.</TableCell></TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </div>
            </section>

            <section className="space-y-4">
              <h2 className="text-lg font-bold flex items-center gap-2"><UserIcon className="h-5 w-5 text-primary" /> Meu resumo</h2>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <StatCard icon={<FilePlus2 className="h-5 w-5" />} label="Meus contratos" value={String(myCars)} />
                {!isOwner && (
                  <StatCard icon={<CreditCard className="h-5 w-5" />} label="Cartão que devo" value={String(myOwedCards)} accent={myOwedCards > 0 ? "warning" : undefined} />
                )}
                <StatCard icon={<Car className="h-5 w-5" />} label="Os meus registos" value={String(records.filter((r) => r.seller_id === me?.id).length)} description={`${myCars} viatura${myCars === 1 ? "" : "s"}`} />
                <StatCard icon={<TrendingUp className="h-5 w-5" />} label="O meu lucro" value={fmt(ranking.find((r) => r.id === me?.id)?.profitAttrib ?? 0)} />
              </div>
              <Card>
                <CardHeader>
                  <CardTitle>A minha posição no ranking</CardTitle>
                </CardHeader>
                <CardContent>
                  {(() => {
                    const pos = ranking.findIndex((r) => r.id === me?.id);
                    if (pos === -1) return <p className="text-sm text-muted-foreground">Ainda sem dados.</p>;
                    const r = ranking[pos];
                    return (
                      <div className="flex items-center justify-between p-3 rounded-lg bg-secondary/50">
                        <div className="flex items-center gap-3">
                          <div className="h-8 w-8 rounded-full bg-primary text-primary-foreground flex items-center justify-center font-bold">{pos + 1}</div>
                          <span className="font-medium">{r.name}</span>
                        </div>
                        <div className="flex items-center gap-4 text-sm">
                          <span className="text-muted-foreground">{r.sales} vendas</span>
                          <span className="font-mono font-semibold text-success">{fmt(r.profitAttrib)}</span>
                        </div>
                      </div>
                    );
                  })()}
                </CardContent>
              </Card>
            </section>

          </TabsContent>

          <TabsContent value="contratos" className="space-y-4">
            <div>
              <h2 className="text-xl font-bold">Contratos levantados</h2>
              <p className="text-sm text-muted-foreground">Cada venda/troca cria automaticamente 1 contrato = {cardsPerContract} cartão em dívida (exceto owners).</p>
            </div>
            <div className="flex flex-wrap items-center gap-3">
              <select
                className="h-9 rounded-md border border-input bg-input px-3 text-sm"
                value={contractFilter}
                onChange={(e) => setContractFilter(e.target.value)}
              >
                <option value="all">Todos os vendedores</option>
                {profiles.map((p) => (
                  <option key={p.id} value={p.id}>{p.full_name}{p.active ? "" : " (saiu)"}</option>
                ))}
              </select>
              <label className="flex items-center gap-2 text-sm">
                <Switch checked={onlyUnpaid} onCheckedChange={setOnlyUnpaid} />
                Só em dívida
              </label>
            </div>
            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Data</TableHead>
                      <TableHead>Vendedor</TableHead>
                      <TableHead>Cartão</TableHead>
                      <TableHead>Notas</TableHead>
                      <TableHead></TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {contracts
                      .filter((c) => contractFilter === "all" || c.seller_id === contractFilter)
                      .filter((c) => !onlyUnpaid || (!c.card_paid && !OWNERS.has(nameOf(c.seller_id)) && !feeUsers.has(c.seller_id)))
                      .map((c) => {
                      const feeSeller = feeUsers.has(c.seller_id);
                      const ownerSeller = OWNERS.has(nameOf(c.seller_id)) || feeSeller;
                      const isOwnContract = c.seller_id === me?.id;
                      const canPay = (isOwner || isOwnContract);
                      const canDelete = (isOwner || isOwnContract) && canWrite("contratos");
                      return (
                        <TableRow key={c.id}>
                          <TableCell className="text-muted-foreground text-sm">{new Date(c.created_at).toLocaleDateString("pt-PT")}</TableCell>
                          <TableCell className="font-medium">{nameOf(c.seller_id)}</TableCell>
                          <TableCell>
                            {feeSeller ? (
                              <Badge variant="outline" className="border-primary text-primary">Taxa</Badge>
                            ) : ownerSeller ? (
                              <Badge variant="outline">N/A (owner)</Badge>
                            ) : c.card_paid ? (
                              <Badge className="bg-success text-success-foreground"><Check className="h-3 w-3 mr-1" />Entregue ({cardsPerContract})</Badge>
                            ) : (
                              <Badge className="bg-warning text-warning-foreground"><X className="h-3 w-3 mr-1" />Deve {cardsPerContract}</Badge>
                            )}
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground max-w-[240px] truncate">{c.notes || "—"}</TableCell>
                          <TableCell className="text-right">
                            {canPay && !ownerSeller && (
                              <Button
                                size="sm"
                                variant={c.card_paid ? "outline" : "default"}
                                onClick={async () => {
                                  const newPaid = !c.card_paid;
                                  const { error } = await supabase
                                    .from("contracts")
                                    .update({ card_paid: newPaid, card_value: cardsPerContract })
                                    .eq("id", c.id);
                                  if (error) { toast.error(error.message); return; }
                                  // O stock de cartão conta automaticamente os contratos entregues.
                                  await logAudit(me, newPaid ? "contract_paid" : "contract_unpaid", "contract", c.id, { notes: c.notes });
                                  toast.success("Atualizado"); load();
                                }}

                              >
                                {c.card_paid ? "Marcar em dívida" : "Marcar entregue"}
                              </Button>
                            )}
                            {canDelete && (

                              <Button size="icon" variant="ghost" className="ml-1" onClick={async () => {
                                if (!confirm("Apagar contrato?")) return;
                                const { error } = await supabase.from("contracts").delete().eq("id", c.id);
                                if (error) toast.error(error.message);
                                else { await logAudit(me, "contract_delete", "contract", c.id); toast.success("Apagado"); load(); }
                              }}>
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            )}
                          </TableCell>
                        </TableRow>
                      );
                    })}
                    {contracts.length === 0 && (
                      <TableRow><TableCell colSpan={5} className="text-center text-muted-foreground py-8">Ainda não há contratos.</TableCell></TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="registos" className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-xl font-bold">Registos de veículos</h2>
                <p className="text-sm text-muted-foreground">Compras, vendas e trocas por matrícula.</p>
              </div>
              {canWrite("registos") && <NewRecordDialog me={me} isOwner={isOwner} profiles={profiles} onCreated={load} cardsPerContract={cardsPerContract} sheetNextRow={settings.sheetNextRow} sheetPackSize={settings.sheetPackSize} />}
            </div>
            <div className="relative max-w-md">
              <Input
                value={recordSearch}
                onChange={(e) => setRecordSearch(e.target.value)}
                placeholder="Pesquisar por matrícula, modelo, nome, CC ou notas…"
              />
            </div>

            <Card>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Stand</TableHead>
                      <TableHead>Data</TableHead>
                      <TableHead>Matrícula</TableHead>
                      <TableHead>Operação</TableHead>
                      <TableHead>Modelo</TableHead>
                      <TableHead>Valor</TableHead>
                      <TableHead>Vendedor</TableHead>
                      <TableHead>Comprador</TableHead>
                       <TableHead>Linha Sheets</TableHead>
                      <TableHead>Notas</TableHead>
                      <TableHead className="sticky right-0 bg-card text-right">Ações</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {(() => { let lastPackIdx: number | null | undefined = undefined; return filteredRecords.flatMap((r) => {
                      const pack = packOf(r.sheet_row);
                      const packIdx = pack ? pack.idx : null;
                      const borderCls = packBorder(packIdx);
                      const headerRows: React.ReactNode[] = [];
                      if (lastPackIdx === undefined || lastPackIdx !== packIdx) {
                        lastPackIdx = packIdx;
                        headerRows.push(
                          <TableRow key={`pack:${packIdx ?? "none"}`} className={`bg-secondary/40 border-l-4 ${borderCls} hover:bg-secondary/40`}>
                            <TableCell colSpan={11} className="py-2 text-xs font-semibold uppercase tracking-wide">
                              {packLabel(packIdx)}
                              {pack && <span className="ml-2 font-normal normal-case text-muted-foreground">linhas {pack.start}–{pack.end} · {settings.sheetPackSize} contratos</span>}
                            </TableCell>
                          </TableRow>,
                        );
                      }

                      type Row = { key: string; matricula: string; modelo: string; role: "main" | "extra-out" | "main-in" | "extra-in"; isFirst: boolean; sheetRow: number | null };
                      const linkedSheetRows = [r.sheet_row, ...(r.sheet_extra_rows || [])];
                      const mainIsIncoming = houseGiven(r);
                      const rows: Row[] = [{ key: `${r.id}:main`, matricula: r.matricula, modelo: r.modelo || "", role: mainIsIncoming ? "main-in" : "main", isFirst: true, sheetRow: linkedSheetRows[0] ?? null }];

                      // Casas nunca ocupam linha — só aparecem no resumo da troca.
                      const casasOut: string[] = [];
                      const casasIn: string[] = [];
                      if (isTroca(r.op)) {
                        let sheetIdx = 1;
                        for (const [i, c] of (r.extra_out || []).entries()) {
                          if (c.casa) { casasOut.push(casaText(c.modelo || "Casa", c.matricula)); continue; }
                          rows.push({ key: `${r.id}:eo:${i}`, matricula: c.matricula, modelo: c.modelo, role: "extra-out", isFirst: false, sheetRow: linkedSheetRows[sheetIdx++] ?? null });
                        }
                        if (r.matricula_entrada) {
                          if (r.op === "troca_casas" || r.casa_in) {
                            const txt = casaText(r.modelo_entrada || "Casa", r.matricula_entrada);
                            if (mainIsIncoming) casasOut.push(txt); else casasIn.push(txt);
                          }
                          else rows.push({ key: `${r.id}:min`, matricula: r.matricula_entrada, modelo: r.modelo_entrada || "", role: "main-in", isFirst: false, sheetRow: linkedSheetRows[sheetIdx++] ?? null });
                        }


                        for (const [i, c] of (r.extra_in || []).entries()) {
                          if (c.casa) { casasIn.push(casaText(c.modelo || "Casa", c.matricula)); continue; }
                          rows.push({ key: `${r.id}:ei:${i}`, matricula: c.matricula, modelo: c.modelo, role: "extra-in", isFirst: false, sheetRow: linkedSheetRows[sheetIdx++] ?? null });
                        }
                      }
                      const isGroup = rows.length > 1;
                      // Nas trocas o dinheiro só se mostra na linha do carro do
                      // lado de quem recebe: se eu pago (valor >= 0) é o carro
                      // que entra; se é ele a pagar, é o carro que sai.
                      const moneyRowKey = isTroca(r.op)
                        ? (Number(r.valor) >= 0
                            ? rows.find((x) => x.role === "main-in" || x.role === "extra-in")?.key
                            : rows.find((x) => x.role === "main" || x.role === "extra-out")?.key)
                        : rows[0]?.key;
                      const rendered = rows.map((row) => {


                        const canEdit = (isOwner || r.seller_id === me?.id) && canWrite("registos");
                        const creatorName = nameOf(r.seller_id);
                        const creatorIsBuyer = r.op === "compra" || (
                          isTroca(r.op) && !!r.comprador &&
                          r.comprador.trim().toLowerCase() === creatorName.trim().toLowerCase()
                        );
                        const incomingTradeCar = isTroca(r.op) && (row.role === "main-in" || row.role === "extra-in");
                        const rowCreatorIsBuyer = incomingTradeCar || creatorIsBuyer;
                        const vendedorNome = rowCreatorIsBuyer ? (r.contraparte_nome || "—") : creatorName;
                        const vendedorId = rowCreatorIsBuyer ? (r.contraparte_id || "") : "";
                        const compradorNome = rowCreatorIsBuyer ? creatorName : (r.contraparte_nome || "—");
                        const compradorId = rowCreatorIsBuyer ? "" : (r.contraparte_id || "");
                        const dt = new Date(r.created_at);
                        const pad = (n: number) => String(n).padStart(2, "0");
                        const dateTxt = `${pad(dt.getDate())}/${pad(dt.getMonth() + 1)}/${dt.getFullYear()} ${pad(dt.getHours())}:${pad(dt.getMinutes())}`;
                        const roleBadge = row.role === "extra-out" ? "↳ também sai"
                          : row.role === "main-in" ? "↳ entra"
                          : row.role === "extra-in" ? "↳ também entra"
                          : null;
                        return (
                          <TableRow key={row.key} className={`border-l-4 ${borderCls} ${isGroup && !row.isFirst ? "bg-secondary/20" : ""}`}>
                            <TableCell className="text-sm font-medium whitespace-nowrap">
                              {row.isFirst ? creatorName : ""}
                              {row.isFirst && r.partner_id && (
                                <div className="text-[10px] font-normal text-primary mt-0.5">
                                  interno c/ {nameOf(r.partner_id)}
                                </div>
                              )}
                            </TableCell>

                            <TableCell className="text-muted-foreground text-sm whitespace-nowrap">{row.isFirst ? dateTxt : ""}</TableCell>
                            <TableCell className="font-mono font-semibold">
                              {row.matricula}
                              {roleBadge && <div className="text-[10px] font-normal text-muted-foreground mt-0.5">{roleBadge}</div>}
                            </TableCell>
                            <TableCell>
                              {row.isFirst ? (
                                <Badge className={
                                  r.op === "compra" ? "bg-accent text-accent-foreground" :
                                  r.op === "venda" ? "bg-success text-success-foreground" :
                                  "bg-warning text-warning-foreground"
                                }>{OP_LABEL[r.op] ?? String(r.op)}</Badge>
                              ) : (
                                <Badge variant="outline" className="text-xs">troca</Badge>
                              )}
                            </TableCell>
                            <TableCell className="text-sm">{row.modelo || "—"}</TableCell>
                            <TableCell className="font-mono">{row.key === moneyRowKey ? fmt(Math.abs(Number(r.valor))) : "—"}</TableCell>
                            <TableCell className="text-sm">
                              <div>{vendedorNome}</div>
                              {vendedorId && <div className="font-mono text-xs text-muted-foreground">{vendedorId}</div>}
                            </TableCell>
                            <TableCell className="text-sm">
                              <div>{compradorNome}</div>
                              {compradorId && <div className="font-mono text-xs text-muted-foreground">{compradorId}</div>}
                            </TableCell>
                             <TableCell className="whitespace-nowrap">
                               {row.sheetRow ? <Badge variant="outline" className="font-mono">{row.sheetRow}</Badge> : <Badge variant="outline" className="text-destructive border-destructive">Falhou</Badge>}
                               {(() => { const p = packOf(row.sheetRow); return p ? <div className="text-[10px] font-mono text-muted-foreground mt-0.5">{p.pos}/{settings.sheetPackSize}</div> : null; })()}
                             </TableCell>

                            <TableCell className="text-sm text-muted-foreground max-w-[180px] truncate">{row.isFirst ? (r.notes || "—") : ""}</TableCell>
                            <TableCell className="text-right sticky right-0 bg-card">
                              {row.isFirst && canEdit && (
                                <div className="flex items-center justify-end gap-1">
                                  <EditRecordDialog record={r} me={me} sellerName={nameOf(r.seller_id)} isOwner={isOwner} profiles={profiles} onSaved={load} />
                                  <Button size="icon" variant="ghost" onClick={async () => {
                                    if (!confirm("Apagar registo? Os contratos associados são apagados e devolvidos ao stock.")) return;
                                    const carCount = carsOf(r);
                                    // Contratos já ligados a este registo (são apagados em cascata com ele)
                                    const { data: linked } = await supabase
                                      .from("contracts")
                                      .select("id")
                                      .eq("record_id", r.id);
                                    const { error } = await supabase.from("vehicle_records").delete().eq("id", r.id);
                                    if (error) { toast.error(error.message); return; }

                                    // Apaga os contratos gerados por este registo e devolve tudo ao stock
                                    let toDelete: { id: string; card_paid: boolean; card_value: number }[] = [];
                                    const { data: byNotes } = linked && linked.length > 0 ? { data: [] } : await supabase
                                      .from("contracts")
                                      .select("id, card_paid, card_value, created_at")
                                      .eq("seller_id", r.seller_id)
                                      .ilike("notes", `Registo ${r.matricula}%`)
                                      .order("created_at", { ascending: false })
                                      .limit(carCount);
                                    if (byNotes && byNotes.length > 0) {
                                      toDelete = byNotes;
                                    } else if (!linked || linked.length === 0) {
                                      const { data: cs } = await supabase
                                        .from("contracts")
                                        .select("id, card_paid, card_value, created_at")
                                        .eq("seller_id", r.seller_id);
                                      if (cs && cs.length > 0) {
                                        toDelete = [...cs].sort((a, b) =>
                                          Math.abs(new Date(a.created_at).getTime() - new Date(r.created_at).getTime()) -
                                          Math.abs(new Date(b.created_at).getTime() - new Date(r.created_at).getTime())
                                        ).slice(0, carCount);
                                      }
                                    }
                                    if (toDelete.length > 0) {
                                      const { error: dErr } = await supabase.from("contracts").delete().in("id", toDelete.map((c) => c.id));
                                      if (dErr) toast.warning(`Registo apagado, mas contratos falharam: ${dErr.message}`);
                                    }
                                    // O stock volta ao sítio sozinho: é calculado a partir dos registos e contratos.

                                    const rowsToClear = [r.sheet_row, ...(r.sheet_extra_rows || [])].filter((n): n is number => !!n);
                                    for (const sr of rowsToClear) {
                                      try {
                                        const res = await clearVehicleRecordInSheet({ data: { sheetRow: sr } });
                                        if (!res.ok) toast.warning(`Apagado aqui, mas Sheets (linha ${sr}) falhou: ${res.error}`);
                                      } catch (e) {
                                        toast.warning(`Apagado aqui, mas Sheets (linha ${sr}) falhou: ${e instanceof Error ? e.message : String(e)}`);
                                      }
                                    }
                                    await logAudit(me, "record_delete", "vehicle_record", r.id, { matricula: r.matricula, contratos_devolvidos: carCount });
                                    toast.success(`Apagado — ${carCount} contrato${carCount > 1 ? "s devolvidos" : " devolvido"} ao stock`); load();
                                  }}>
                                    <Trash2 className="h-4 w-4" />
                                  </Button>

                                </div>
                              )}
                            </TableCell>
                          </TableRow>
                        );
                      });
                      
                      if (!isTroca(r.op)) return [...headerRows, ...rendered];
                      const creatorName = nameOf(r.seller_id);
                      const euSouComprador = !!r.comprador && r.comprador.trim().toLowerCase() === creatorName.trim().toLowerCase();
                      const carLabel = (x: { modelo: string; matricula: string }) => (x.modelo && x.modelo.trim()) ? x.modelo.trim() : x.matricula;
                      const outLabels = [...rows.filter((x) => x.role === "main" || x.role === "extra-out").map(carLabel), ...casasOut];
                      const inLabels = [...rows.filter((x) => x.role === "main-in" || x.role === "extra-in").map(carLabel), ...casasIn];
                      const valor = Math.abs(Number(r.valor));
                      const dinheiro = valor > 0
                        ? (Number(r.valor) >= 0 ? `eu dei mais ${fmt(valor)}` : `${r.contraparte_nome || "a contraparte"} deu mais ${fmt(valor)}`)
                        : "sem dinheiro à mistura";
                      return [
                        ...headerRows,
                        ...rendered,
                        <TableRow key={`${r.id}:resumo:${outLabels.join("|")}>${inLabels.join("|")}@${r.valor}`} className={`bg-secondary/20 border-l-4 ${borderCls}`}>
                          <TableCell colSpan={11} className="text-xs text-muted-foreground py-2">
                            <span className="font-medium text-foreground">Resumo da troca ({euSouComprador ? "eu recebi os veículos" : "eu entreguei"}):</span>{" "}
                            dei <span className="font-mono text-foreground">{outLabels.join(" + ") || "—"}</span>
                            {" → "}recebi <span className="font-mono text-foreground">{inLabels.join(" + ") || "—"}</span>
                            {" · "}{dinheiro}

                            {(casasOut.length > 0 || casasIn.length > 0) && <span> · casas não gastam contrato nem linha no Sheets</span>}
                          </TableCell>
                        </TableRow>,
                      ];
                    }); })()}


                    {records.length === 0 && (
                      <TableRow><TableCell colSpan={11} className="text-center text-muted-foreground py-8">Ainda não há registos.</TableCell></TableRow>
                    )}
                  </TableBody>

                </Table>

              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="lucros" className="space-y-4">
            <div className="flex flex-wrap items-center gap-2">
              <Label className="text-sm">Período</Label>
              {([["all", "Tudo"], ["7d", "Últimos 7 dias"], ["30d", "Últimos 30 dias"], ["month", "Mês"]] as const).map(([k, lbl]) => (
                <Button key={k} size="sm" variant={profitPeriod === k ? "default" : "outline"} onClick={() => setProfitPeriod(k)}>{lbl}</Button>
              ))}
              {profitPeriod === "month" && (
                <Input type="month" className="h-9 w-[170px]" value={profitMonth} onChange={(e) => setProfitMonth(e.target.value)} />
              )}
            </div>
            <Tabs defaultValue="stand">
              <TabsList className="mb-4">
                <TabsTrigger value="stand"><TrendingUp className="h-4 w-4 mr-1.5" />Lucro stand</TabsTrigger>
                <TabsTrigger value="individual"><UserIcon className="h-4 w-4 mr-1.5" />Lucro individual</TabsTrigger>
              </TabsList>
              <TabsContent value="stand" className="space-y-6">
                {(() => {
                  const visible = profitRows.filter((r) => !r.tradedAway);
                  const closed = visible.filter((r) => r.hasCompra && !r.pending && !r.houseSourced);
                  const totalLucro = closed.reduce((s, r) => s + r.lucro, 0);
                  const totalReceitas = closed.reduce((s, r) => s + r.receitas, 0);
                  const media = closed.length > 0 ? totalLucro / closed.length : 0;

                  // Agrupar por vendedor (quem comprou se pendente, quem vendeu se fechado).
                  const groups = new Map<string, typeof visible>();
                  for (const r of visible) {
                    const sid = r.pending ? r.buyerSellerId : (r.lastSellerId ?? r.buyerSellerId);
                    const name = sid ? nameOf(sid) : "—";
                    const arr = groups.get(name) || [];
                    arr.push(r);
                    groups.set(name, arr);
                  }
                  const sellerStats = [...groups.entries()].map(([name, rows]) => {
                    const closedRows = rows.filter((r) => r.hasCompra && !r.pending && !r.houseSourced);
                    const lucro = closedRows.reduce((s, r) => s + r.lucro, 0);
                    return { name, rows, lucro, media: closedRows.length > 0 ? lucro / closedRows.length : 0, negocios: closedRows.length };
                  }).sort((a, b) => b.lucro - a.lucro);
                  const best = sellerStats.find((s) => s.negocios > 0);

                  const initials = (n: string) => n.split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]!.toUpperCase()).join("");

                  return (
                    <>
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <Card className="p-5">
                          <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Lucro total</p>
                          <p className="text-2xl font-bold mt-1 font-mono">{fmt(totalLucro)}</p>
                        </Card>
                        <Card className="p-5">
                          <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Média por negócio</p>
                          <p className="text-2xl font-bold mt-1 font-mono text-primary">{fmt(media)}</p>
                        </Card>
                        <Card className="p-5">
                          <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Negócios fechados</p>
                          <p className="text-2xl font-bold mt-1 font-mono">{closed.length}</p>
                        </Card>
                        <Card className="p-5">
                          <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground">Melhor vendedor</p>
                          <p className="text-2xl font-bold mt-1 truncate">{best ? best.name : "—"}</p>
                          {best && <p className="text-xs text-muted-foreground mt-1 font-mono">{fmt(best.lucro)} acumulado</p>}
                        </Card>
                      </div>

                      <p className="text-xs text-muted-foreground">
                        Compra = valor da compra registada. Nas trocas, o custo passa para a matrícula que entra (custo acumulado). Lucro = venda − custo acumulado. Matrículas que só foram trocadas não aparecem — o valor foi transferido para a matrícula seguinte. Totais e médias contam só negócios fechados com custo fiável (excluem negócios de casas).
                      </p>

                      <div className="space-y-6">
                        {sellerStats.map((s) => (
                          <Card key={s.name} className="overflow-hidden">
                            <div className="p-5 bg-secondary/60 flex flex-wrap items-center justify-between gap-4 border-b border-border">
                              <div className="flex items-center gap-4">
                                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center border border-primary/20">
                                  <span className="text-primary font-bold text-sm">{initials(s.name)}</span>
                                </div>
                                <div>
                                  <h3 className="font-bold text-lg">{s.name}</h3>
                                  <p className="text-xs text-muted-foreground uppercase font-semibold">{s.negocios} negócio{s.negocios === 1 ? "" : "s"} fechado{s.negocios === 1 ? "" : "s"}{s.rows.length - s.negocios > 0 ? ` · ${s.rows.length - s.negocios} pendente${s.rows.length - s.negocios === 1 ? "" : "s"}` : ""}</p>
                                </div>
                              </div>
                              <div className="flex gap-8">
                                <div className="text-right">
                                  <p className="text-[10px] uppercase font-bold text-muted-foreground">Lucro acumulado</p>
                                  <p className="text-lg font-bold font-mono">{fmt(s.lucro)}</p>
                                </div>
                                <div className="text-right">
                                  <p className="text-[10px] uppercase font-bold text-muted-foreground">Média/venda</p>
                                  <p className="text-lg font-bold font-mono text-primary">{fmt(s.media)}</p>
                                </div>
                              </div>
                            </div>
                            <CardContent className="p-0">
                              <Table>
                                <TableHeader>
                                  <TableRow>
                                    <TableHead>Matrícula</TableHead>
                                    <TableHead>Modelo</TableHead>
                                    <TableHead>Compra</TableHead>
                                    <TableHead className="text-right">Receitas</TableHead>
                                    <TableHead className="text-right">Lucro</TableHead>
                                  </TableRow>
                                </TableHeader>
                                <TableBody>
                                  {s.rows.map((r) => (
                                    <TableRow key={`${r.matricula}#${r.cycle}`}>
                                      <TableCell className="font-mono font-semibold">{r.matricula}{r.cycle > 1 && <Badge variant="outline" className="ml-2 text-xs">{r.cycle}ª vez</Badge>}{r.inherited && <Badge variant="outline" className="ml-2 text-xs">via troca</Badge>}{r.houseSourced && <Badge variant="outline" className="ml-2 text-xs text-warning border-warning">negócio casa</Badge>}</TableCell>
                                      <TableCell className="text-sm">{r.modelo || "—"}</TableCell>
                                      <TableCell className="font-mono">{r.hasCompra ? fmt(r.compra) : <Badge variant="outline" className="text-warning border-warning">sem compra</Badge>}</TableCell>
                                      <TableCell className="font-mono text-right">{r.pending ? <Badge variant="outline" className="text-warning border-warning">{r.houseDeal ? "vendido em troca de casa" : "em stock"}</Badge> : fmt(r.receitas)}</TableCell>
                                      <TableCell className={`font-mono font-bold text-right ${r.pending || r.houseSourced || !r.hasCompra ? "text-muted-foreground" : (r.lucro > 0 ? "text-success" : r.lucro < 0 ? "text-destructive" : "text-muted-foreground")}`}>
                                        {r.pending ? <Badge variant="outline" className="text-warning border-warning">{r.houseDeal ? "negócio casa" : "pendente"}</Badge>
                                          : r.houseSourced ? <Badge variant="outline" className="text-warning border-warning">negócio casa (sem lucro total)</Badge>
                                          : (r.hasCompra ? fmt(r.lucro) : "—")}
                                      </TableCell>
                                    </TableRow>
                                  ))}
                                </TableBody>
                              </Table>
                            </CardContent>
                          </Card>
                        ))}
                        {visible.length === 0 && (
                          <Card className="p-8 text-center text-muted-foreground">Sem dados ainda.</Card>
                        )}
                      </div>
                    </>
                  );
                })()}
              </TabsContent>
              <TabsContent value="individual" className="space-y-4">
                <div className="flex items-center gap-3">
                  <Label htmlFor="profit-user">Vendedor</Label>
                  <select id="profit-user" className="h-10 rounded-md border border-input bg-input px-3 text-sm" value={profitUserId || me?.id || ""} onChange={(e) => setProfitUserId(e.target.value)}>
                    {profiles.map((p) => <option key={p.id} value={p.id}>{p.full_name}</option>)}
                  </select>
                </div>
                <MyProfitPanel profile={profiles.find((p) => p.id === (profitUserId || me?.id)) ?? me} rows={profitRows} />
              </TabsContent>
            </Tabs>
          </TabsContent>

          <TabsContent value="imobiliaria" className="space-y-4">
            <RealEstatePanel deals={houseDeals} nameOf={nameOf} profiles={profiles} />
          </TabsContent>

          {(isOwner || me?.fee_mode) && (
            <TabsContent value="taxas" className="space-y-4">
              <FeesPanel me={me} isOwner={isOwner} profiles={profiles} profitRows={profitByMatricula} feePayments={feePayments} records={records} onSaved={load} />
            </TabsContent>
          )}



          <TabsContent value="ranking" className="space-y-4">
            <Card>
              <CardHeader>
                <CardTitle>Ranking de vendedores</CardTitle>
                <CardDescription>
                  Ordenado por lucro atribuído (soma do lucro das matrículas que cada um vendeu/trocou).
                  {" "}Período: {rankFrom ? `desde ${fmtDate(`${rankFrom}T00:00:00`)}` : firstRecordDate ? `desde ${fmtDate(firstRecordDate)}` : "desde sempre"}
                  {rankTo ? ` até ${fmtDate(`${rankTo}T00:00:00`)}` : ""}.
                </CardDescription>
                <div className="flex flex-wrap items-end gap-3 pt-3">
                  <div className="space-y-1">
                    <Label className="text-xs">De</Label>
                    <Input type="date" value={rankFrom} onChange={(e) => setRankFrom(e.target.value)} className="w-[160px]" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Até</Label>
                    <Input type="date" value={rankTo} onChange={(e) => setRankTo(e.target.value)} className="w-[160px]" />
                  </div>
                  <div className="flex flex-wrap gap-2">
                    <Button variant="outline" size="sm" onClick={() => {
                      const d = new Date(Date.now() - 7 * 86400000).toISOString().slice(0, 10);
                      setRankFrom(d); setRankTo("");
                    }}>7 dias</Button>
                    <Button variant="outline" size="sm" onClick={() => {
                      const d = new Date(Date.now() - 30 * 86400000).toISOString().slice(0, 10);
                      setRankFrom(d); setRankTo("");
                    }}>30 dias</Button>
                    <Button variant="outline" size="sm" onClick={() => {
                      const n = new Date();
                      setRankFrom(`${n.getFullYear()}-${String(n.getMonth() + 1).padStart(2, "0")}-01`); setRankTo("");
                    }}>Este mês</Button>
                    <Button variant="ghost" size="sm" onClick={() => { setRankFrom(""); setRankTo(""); }}>Desde sempre</Button>
                  </div>
                </div>
              </CardHeader>

              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>#</TableHead>
                      <TableHead>Vendedor</TableHead>
                      <TableHead>Contratos</TableHead>
                      <TableHead>Compras</TableHead>
                      <TableHead>Volume compras</TableHead>
                      <TableHead>Vendas</TableHead>
                      <TableHead>Volume vendas</TableHead>
                      <TableHead>Trocas</TableHead>

                      <TableHead>Pendentes</TableHead>
                      <TableHead>Valor pendente</TableHead>
                      <TableHead>Lucro atribuído</TableHead>

                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {ranking.map((r, i) => (
                      <TableRow key={r.id}>
                        <TableCell>
                          <div className={`h-7 w-7 rounded-full flex items-center justify-center text-xs font-bold ${i === 0 ? "bg-primary text-primary-foreground" : i < 3 ? "bg-accent text-accent-foreground" : "bg-muted"}`}>{i + 1}</div>
                        </TableCell>
                        <TableCell className="font-medium">
                          {r.name} {OWNERS.has(r.name) && <Badge variant="outline" className="ml-1 border-primary text-primary text-[10px]">OWNER</Badge>}
                        </TableCell>
                        <TableCell>{r.contracts}</TableCell>
                        <TableCell>{r.purchases}</TableCell>
                        <TableCell className="font-mono">{fmt(r.purchasesValue)}</TableCell>
                        <TableCell>{r.sales}</TableCell>
                        <TableCell className="font-mono">{fmt(r.salesValue)}</TableCell>
                        <TableCell>{r.trades}</TableCell>

                        <TableCell>{r.pendingCount}</TableCell>
                        <TableCell className={`font-mono ${r.pendingValue > 0 ? "text-warning" : ""}`}>{fmt(r.pendingValue)}</TableCell>
                        <TableCell className={`font-mono font-bold ${r.profitAttrib > 0 ? "text-success" : r.profitAttrib < 0 ? "text-destructive" : ""}`}>{fmt(r.profitAttrib)}</TableCell>

                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="perfil" className="space-y-4">
            <ProfilePanel me={me} onSaved={load} />
          </TabsContent>

          <TabsContent value="equipa" className="space-y-4">
            <TeamPanel profiles={profiles} directory={directory} isOwner={isOwner} onSaved={load} />
          </TabsContent>

          {isOwner && (
            <TabsContent value="gestao" className="space-y-4">
              <ManagementPanel stock={stock} contracts={contracts} contractsUsedTotal={contractsIssued} feePayments={feePayments} profiles={profiles} settings={settings} />
            </TabsContent>
          )}





          <TabsContent value="stock" className="space-y-4">
            <StockPanel
              me={me}
              isOwner={isOwner}
              canEdit={canWriteSub("stock", "adjust")}
              canEditPack={canWriteSub("stock", "pack")}
              stock={stock}
              cardTotal={cardStockTotal}
              contractTotal={contractStockTotal}

              profiles={profiles}
              settings={settings}
              onChanged={load}
            />

          </TabsContent>

          {(isMaster || isOwner) && (
            <TabsContent value="admin" className="space-y-4">
              <Tabs defaultValue={isMaster ? "aprovacoes" : "permissoes"}>
                <TabsList className="mb-4">
                  {isMaster && (
                    <TabsTrigger value="aprovacoes"><ShieldCheck className="h-4 w-4 mr-1.5" />Aprovações{pendingCount > 0 && <Badge className="ml-1.5 bg-warning text-warning-foreground">{pendingCount}</Badge>}</TabsTrigger>
                  )}
                  {isOwner && <TabsTrigger value="permissoes"><Lock className="h-4 w-4 mr-1.5" />Permissões</TabsTrigger>}
                  {isOwner && <TabsTrigger value="auditoria"><ClipboardList className="h-4 w-4 mr-1.5" />Auditoria</TabsTrigger>}
                </TabsList>
                {isMaster && (
                  <TabsContent value="aprovacoes" className="space-y-4">
                    <ApprovalsPanel profiles={profiles} emails={emails} me={me} onChanged={load} />
                  </TabsContent>
                )}
                {isOwner && (
                  <TabsContent value="permissoes" className="space-y-4">
                    <PermissionsPanel profiles={profiles} denies={tabDenies} me={me} onChanged={load} />
                  </TabsContent>
                )}
                {isOwner && (
                  <TabsContent value="auditoria" className="space-y-4">
                    <AuditPanel audits={audits} />
                  </TabsContent>
                )}
              </Tabs>
            </TabsContent>
          )}
        </Tabs>
      </main>
    </div>
  );
}

function StatCard({ icon, label, value, accent, description }: { icon: React.ReactNode; label: string; value: string; accent?: "warning" | "success"; description?: string }) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-2 text-muted-foreground text-xs mb-2">{icon}<span>{label}</span></div>
        <div className={`text-2xl font-bold font-mono ${accent === "warning" ? "text-warning" : accent === "success" ? "text-success" : ""}`}>{value}</div>
        {description && <div className="text-xs text-muted-foreground mt-1">{description}</div>}
      </CardContent>
    </Card>
  );
}

function DebtReminderButton({ userId, name, missing, hasDiscord }: { userId: string; name: string; missing: number; hasDiscord: boolean }) {
  const [sending, setSending] = useState(false);
  const [open, setOpen] = useState(false);
  const send = async () => {
    setSending(true);
    try {
      const res = await sendCardDebtReminder({ data: { userId, missing } });
      if (res?.ok) toast.success("Aviso enviado no Discord");
      else toast.error(res?.error || "Falha ao enviar aviso");
    } catch (e) {
      toast.error(e instanceof Error ? e.message : "Falha ao enviar aviso");
    }
    setSending(false);
    setOpen(false);
  };
  return (
    <>
      <Button size="sm" variant="outline" onClick={() => setOpen(true)} disabled={sending || !hasDiscord} title={hasDiscord ? "Avisar no Discord" : "Sem ID de Discord no perfil"}>
        {sending ? "A enviar…" : "Avisar"}
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Enviar aviso de cartão?</DialogTitle>
            <DialogDescription>
              Vai ser enviada uma mensagem no Discord a mencionar <strong>{name}</strong> sobre <strong>{missing}</strong> de cartão em falta.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} disabled={sending}>Cancelar</Button>
            <Button onClick={send} disabled={sending}>{sending ? "A enviar…" : "Confirmar e enviar"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

function ProfilePanel({ me, onSaved }: { me: Profile | null; onSaved: () => void }) {
  const [cc, setCc] = useState(me?.cc || "");
  const [discordId, setDiscordId] = useState(me?.discord_id || "");
  const [loading, setLoading] = useState(false);
  useEffect(() => { setCc(me?.cc || ""); }, [me?.cc]);
  useEffect(() => { setDiscordId(me?.discord_id || ""); }, [me?.discord_id]);

  const cleanDiscord = discordId.replace(/[^0-9]/g, "");

  const save = async () => {
    if (!me) return;
    if (!cleanDiscord) return toast.error("O ID do Discord é obrigatório");
    if (cleanDiscord.length < 15) return toast.error("ID do Discord inválido (deve ter 17-20 números)");
    setLoading(true);
    const { error } = await supabase.from("profiles").update({
      cc: cc.trim().toUpperCase() || null,
      discord_id: cleanDiscord,
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } as any).eq("id", me.id);
    setLoading(false);
    if (error) return toast.error(error.message);
    toast.success("Perfil guardado");
    onSaved();
  };

  return (
    <Card className="max-w-lg">
      <CardHeader>
        <CardTitle>O meu perfil</CardTitle>
        <CardDescription>Guarda aqui o teu CC e o teu ID do Discord uma única vez.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {!me?.discord_id && (
          <div className="rounded-md border border-warning/40 bg-warning/10 p-3 text-sm text-warning">
            Falta o teu ID do Discord — é obrigatório para receberes os avisos de cartão em falta.
          </div>
        )}
        <div className="space-y-2">
          <Label>Nome</Label>
          <Input value={me?.full_name || ""} disabled />
        </div>
        <div className="space-y-2">
          <Label>Meu CC (ID)</Label>
          <Input value={cc} onChange={(e) => setCc(e.target.value.toUpperCase())} placeholder="Ex: YAV38792" />
          <p className="text-xs text-muted-foreground">Podes colar uma linha inteira do contrato (ex: <span className="font-mono">Vendedor: Pedro Lourenço · ID YAV38792</span>) — o CC é extraído automaticamente.</p>
        </div>
        <div className="space-y-2">
          <Label>ID do Discord <span className="text-destructive">*</span></Label>
          <Input value={discordId} onChange={(e) => setDiscordId(e.target.value)} placeholder="Ex: 707573060462706789" inputMode="numeric" />
          <p className="text-xs text-muted-foreground">No Discord: Definições → Avançado → Modo de programador, depois clica no teu nome → Copiar ID do utilizador.</p>
        </div>
        <Button onClick={save} disabled={loading}>{loading ? "A guardar…" : "Guardar"}</Button>
      </CardContent>
    </Card>
  );
}

function buildSheetParties(
  op: VehicleOpKind, meName: string, meCC: string, otherName: string, otherId: string,
  meSouComprador: boolean,
) {
  // Compra: sou sempre o comprador (contraparte = vendedor, E/F).
  if (op === "compra") {
    return { vendedorNome: otherName, vendedorId: otherId, compradorNome: meName, compradorId: meCC };
  }
  // Venda: sou sempre o vendedor (contraparte = comprador, G/H).
  if (op === "venda") {
    return { vendedorNome: meName, vendedorId: meCC, compradorNome: otherName, compradorId: otherId };
  }
  // Trocas: toggle ligado => contraparte cai em G/H (comprador) e eu sou vendedor.
  if (meSouComprador) {
    return { vendedorNome: meName, vendedorId: meCC, compradorNome: otherName, compradorId: otherId };
  }
  return { vendedorNome: otherName, vendedorId: otherId, compradorNome: meName, compradorId: meCC };
}

function isTroca(op: VehicleOpKind) {
  return op === "troca_carros" || op === "troca_casas";
}

function TradeCarsEditor({ title, cars, setCars, matPlaceholder, allowCasa }: { title: string; cars: TradeCar[]; setCars: (c: TradeCar[]) => void; matPlaceholder: string; allowCasa?: boolean }) {
  const update = (i: number, patch: Partial<TradeCar>) => {
    setCars(cars.map((c, idx) => (idx === i ? { ...c, ...patch } : c)));
  };
  const add = () => setCars([...cars, { matricula: "", modelo: "" }]);
  const addCasa = () => setCars([...cars, { matricula: "", modelo: "Casa", casa: true }]);
  const remove = (i: number) => setCars(cars.filter((_, idx) => idx !== i));
  // Colar a linha inteira do contrato também nos carros extra (modelo + matrícula).
  const rowPaste = (i: number) => (e: React.ClipboardEvent<HTMLInputElement>) => {
    const txt = e.clipboardData.getData("text");
    if (!/\bmodelo\b/i.test(txt) && !/\bmatr[ií]cula\b/i.test(txt)) return;
    e.preventDefault();
    const { modelo: mod, matricula: mat } = extractVehicle(txt);
    const patch: Partial<TradeCar> = {};
    if (mod) patch.modelo = mod;
    if (mat) patch.matricula = mat;
    update(i, patch);
  };
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between">
        <Label className="text-xs text-muted-foreground">{title}</Label>
        <div className="flex gap-1">
          <Button type="button" size="sm" variant="ghost" onClick={add}>+ carro</Button>
          {allowCasa && <Button type="button" size="sm" variant="ghost" onClick={addCasa}>+ casa</Button>}
        </div>
      </div>
      {cars.length === 0 && <p className="text-xs text-muted-foreground">— (nenhum extra)</p>}
      {cars.map((c, i) => (
        <div key={i} className="grid grid-cols-[1fr_1fr_auto] gap-2 items-end">
          <Input value={c.modelo} onChange={(e) => update(i, { modelo: e.target.value })} onPaste={rowPaste(i)} placeholder={c.casa ? "Tipo (ex: Casa)" : "Modelo"} />
          <Input value={c.matricula} onChange={(e) => update(i, { matricula: e.target.value.toUpperCase() })} onPaste={rowPaste(i)} placeholder={c.casa ? "CP (ex: 567)" : matPlaceholder} />
          <Button type="button" size="icon" variant="ghost" onClick={() => remove(i)}><X className="h-4 w-4" /></Button>
        </div>
      ))}
      {cars.some((c) => c.casa) && <p className="text-[11px] text-muted-foreground">As casas não gastam contrato nem cartão.</p>}
    </div>
  );
}


function NewRecordDialog({ me, isOwner, profiles, onCreated, cardsPerContract, sheetNextRow, sheetPackSize }: { me: Profile | null; isOwner: boolean; profiles: Profile[]; onCreated: () => void; cardsPerContract: number; sheetNextRow: number; sheetPackSize: number }) {
  const [open, setOpen] = useState(false);
  const [matricula, setMatricula] = useState("");
  const [op, setOp] = useState<VehicleOpKind>("compra");
  const [valor, setValor] = useState("");
  const [contraparteNome, setContraparteNome] = useState("");
  const [contraparteId, setContraparteId] = useState("");
  // Negócio interno: o outro lado é um membro do stand.
  const [partnerId, setPartnerId] = useState("");

  const [modelo, setModelo] = useState("");
  const [matriculaEntrada, setMatriculaEntrada] = useState("");
  const [modeloEntrada, setModeloEntrada] = useState("");
  const [notes, setNotes] = useState("");
  const [cartaoPago, setCartaoPago] = useState(false);
  const [meSouComprador, setMeSouComprador] = useState(false);
  const [euPagoTopUp, setEuPagoTopUp] = useState(true);
  const [isMota, setIsMota] = useState(false);
  // Troca/casas: os dados do veículo ficam normais e a casa vai só para a coluna N.
  const [casaTipo, setCasaTipo] = useState("Casa");
  const [casaCp, setCasaCp] = useState("");
  // true = sou eu que dou a casa (recebo carros); false = recebo a casa (dou carros).
  const [casaEuDou, setCasaEuDou] = useState(true);

  const [actorId, setActorId] = useState<string>(me?.id ?? "");
  const [actorCc, setActorCc] = useState<string>("");

  const [extraOut, setExtraOut] = useState<TradeCar[]>([]);
  const [extraIn, setExtraIn] = useState<TradeCar[]>([]);
  const [loading, setLoading] = useState(false);
  // Marca única deste registo: impede que o mesmo registo caia duas vezes na
  // folha se houver segundo clique, recarregamento ou nova tentativa.
  const submitKeyRef = useRef<string>("");

  const geraContrato = true;
  const criaContrato = geraContrato; // owner também cria contrato (para contar no ranking); só não deve cartão
  const onBehalf = !!me && !!actorId && actorId !== me.id;
  const actorProfile = profiles.find((p) => p.id === actorId) || me;
  const meName = actorProfile?.full_name || "";
  const meCC = onBehalf ? actorCc : (me?.cc || "");
  const actorIsOwner = onBehalf ? false : isOwner;
  /** Vendedor em regime de taxa (10% do lucro) — não paga cartão. */
  const actorPaysFee = actorProfile?.fee_mode === true;
  const actorNoCard = actorIsOwner || actorPaysFee;

  useEffect(() => {
    if (!open || !onBehalf || !isOwner || !actorId) { if (!onBehalf) setActorCc(""); return; }
    getUserCc({ data: { userId: actorId } })
      .then((r) => setActorCc(r?.cc ?? ""))
      .catch(() => setActorCc(""));
  }, [open, onBehalf, isOwner, actorId]);

  const isCasas = op === "troca_casas";
  // Cada CARRO é 1 contrato; casas não contam.
  const carCount = isTroca(op)
    ? (isCasas ? 1 : 2)
      + extraOut.filter((c) => !c.casa && c.matricula.trim()).length
      + extraIn.filter((c) => !c.casa && c.matricula.trim()).length
    : 1;




  const submit = async () => {
    if (!me || loading) return;
    const vRaw = Number(valor);
    if (!matricula.trim() || !Number.isFinite(vRaw)) return toast.error("Matrícula e valor são obrigatórios");
    if (op === "troca_carros" && !matriculaEntrada.trim()) return toast.error("Nas trocas, indica a matrícula que entra");
    if (isCasas && !casaCp.trim()) return toast.error("Indica o CP da casa");
    if (!meCC) return toast.error("Define primeiro o teu CC no separador Perfil");
    setLoading(true);
    if (!submitKeyRef.current) {
      submitKeyRef.current =
        typeof crypto !== "undefined" && "randomUUID" in crypto
          ? crypto.randomUUID()
          : `${Date.now()}-${Math.random().toString(36).slice(2)}`;
    }
    const mat = matricula.trim().toUpperCase();
    const cpNome = contraparteNome.trim();
    const cpId = contraparteId.trim().toUpperCase();
    // Nas trocas: se for a contraparte a dar dinheiro, o top-up é negativo.
    const v = isTroca(op) && !euPagoTopUp ? -Math.abs(vRaw) : vRaw;

    // Troca/casas: o sentido é dado pela casa (se dou a casa, os carros entram).
    const souVendedorFlag = isCasas ? !casaEuDou : meSouComprador;
    const parties = buildSheetParties(op, meName, meCC, cpNome, cpId, souVendedorFlag);
    const meSouVendedor = op === "venda" || (isTroca(op) && souVendedorFlag);

    // Numa troca cada carro tem o seu sentido: os que saem sou eu o vendedor
    // (E/F = eu, G/H = contraparte); os que entram é a contraparte o vendedor.
    const outParties = { vendedorNome: meName, vendedorId: meCC, compradorNome: cpNome, compradorId: cpId };
    const inParties = { vendedorNome: cpNome, vendedorId: cpId, compradorNome: meName, compradorId: meCC };

    const cleanList = (list: TradeCar[]) => list
      .map((c) => ({ matricula: c.matricula.trim().toUpperCase(), modelo: c.modelo.trim(), casa: c.casa === true }))
      .filter((c) => c.matricula);
    const cleanExtraOut = isTroca(op) ? cleanList(extraOut) : [];
    const cleanExtraIn = isTroca(op) ? cleanList(extraIn) : [];

    // Cada CARRO ocupa uma linha no Sheets (1 carro = 1 contrato = 1 linha).
    // As casas nunca ocupam linha: vão só para a coluna N da primeira linha.
    type SheetCar = { matricula: string; modelo: string; incoming: boolean };
    const cars: SheetCar[] = [{ matricula: mat, modelo: modelo || "", incoming: isCasas ? casaEuDou : false }];
    if (isTroca(op)) {
      for (const c of cleanExtraOut) if (!c.casa) cars.push({ matricula: c.matricula, modelo: c.modelo, incoming: false });
      if (op === "troca_carros") cars.push({ matricula: matriculaEntrada.trim().toUpperCase(), modelo: modeloEntrada.trim(), incoming: true });
      for (const c of cleanExtraIn) if (!c.casa) cars.push({ matricula: c.matricula, modelo: c.modelo, incoming: true });
    }
    const totalCars = cars.length;
    const casaTexts = [
      ...(isCasas && casaCp.trim() ? [casaText(casaTipo.trim() || "Casa", casaCp.trim())] : []),
      ...[...cleanExtraOut, ...cleanExtraIn].filter((c) => c.casa).map((c) => casaText(c.modelo || "Casa", c.matricula)),
    ].filter(Boolean);
    const sheetItems: SheetCar[] = cars;

    let sheetRow: number | null = null;
    const sheetExtraRows: number[] = [];
    try {
      const r = await appendVehicleRecordsToSheet({
        data: {
          rows: sheetItems.map((car, idx) => {
            const p = isTroca(op) ? (car.incoming ? inParties : outParties) : parties;
            // Nas trocas o dinheiro só aparece no lado de quem o recebe:
            // se eu pago, o valor fica no carro que entra (ele é o vendedor);
            // se ele paga, fica no carro que sai (eu sou o vendedor).
            // Só numa linha, para o dinheiro não ser contado várias vezes.
            let rowValor = Math.abs(v);
            if (isTroca(op) && sheetItems.length > 1) {
              const side = euPagoTopUp ? true : false; // true = incoming
              const firstIdx = sheetItems.findIndex((c) => c.incoming === side);
              rowValor = idx === (firstIdx >= 0 ? firstIdx : 0) ? Math.abs(v) : 0;
            }
            return {
              nome: meName, tipo: op, valor: rowValor, ...p,
              modelo: car.modelo || "",
              matricula: car.matricula,
              cont: "",
              // As casas caem na coluna N da primeira linha do negócio.
              casa: idx === 0 ? casaTexts.join(" + ") : "",
            };
          }),


          startRow: sheetNextRow,
          packSize: sheetPackSize,
          clientKey: submitKeyRef.current,
        },
      });

      if (!r.ok) {
        setLoading(false);
        return toast.error(`Registo cancelado — NÃO caiu no Google Sheets: ${r.error}`, { duration: 20000 });
      }
      else {
        sheetRow = r.rows[0] ?? null;
        sheetExtraRows.push(...r.rows.slice(1));
        if ("duplicate" in r && r.duplicate) {
          toast.info("Este registo já estava na folha — usei as linhas que já lá estavam (não dupliquei).");
        }
        // O pack atual ficou cheio e o registo caiu no pack seguinte:
        // guarda a nova linha inicial para os próximos registos.
        if (r.packStart && r.packStart !== sheetNextRow) {
          try {
            await supabase.from("app_settings").upsert({ key: "sheet_next_row", value_int: r.packStart, updated_by: me.id }, { onConflict: "key" });
            toast.info(`Pack cheio — passei automaticamente para o pack seguinte (linha ${r.packStart}).`);
          } catch { /* sem permissões: o registo caiu na mesma no sítio certo */ }
        }
      }

    } catch (e: unknown) {
      setLoading(false);
      return toast.error(`Registo cancelado — NÃO caiu no Google Sheets: ${e instanceof Error ? e.message : String(e)}`, { duration: 20000 });
    }


    const { data: inserted, error } = await supabase.from("vehicle_records").insert({
      seller_id: actorId || me.id, matricula: mat, op, valor: v,
      contraparte: null, contraparte_nome: cpNome || null, contraparte_id: cpId || null,
      modelo: modelo || null, comprador: parties.compradorNome, notes: notes || null,
      sheet_row: sheetRow,
      sheet_extra_rows: sheetExtraRows,
      matricula_entrada: op === "troca_carros" ? matriculaEntrada.trim().toUpperCase() : (isCasas ? casaCp.trim().toUpperCase() : null),
      modelo_entrada: op === "troca_carros" ? (modeloEntrada.trim() || null) : (isCasas ? (casaTipo.trim() || "Casa") : null),
      extra_out: cleanExtraOut,
      extra_in: cleanExtraIn,
      is_mota: op === "venda" ? isMota : false,
      partner_id: partnerId || null,
      casa_out: isCasas && casaEuDou,

      casa_in: isCasas && !casaEuDou,

    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    } as any).select("id").single();
    if (error) { setLoading(false); return toast.error(error.message); }

    await logAudit(me, "record_create", "vehicle_record", inserted?.id ?? null, { matricula: mat, op, valor: v, cars: totalCars, por: onBehalf ? meName : undefined });

    // O stock de contratos e de cartão é calculado a partir dos registos e dos
    // contratos, por isso não se criam movimentos automáticos (evita desvios).

    if (criaContrato && totalCars > 0) {
      // Cria N contratos, um por cada carro (cada carro = 1 contrato).
      // Quem paga taxa (ou o owner) gasta contrato na mesma, mas sem custo de cartão.
      const contractPaid = actorNoCard ? true : cartaoPago;
      const contractCardValue = actorNoCard ? 0 : cardsPerContract;

      const contractsToInsert = Array.from({ length: totalCars }, (_, i) => ({
        seller_id: actorId || me.id, card_paid: contractPaid, card_value: contractCardValue,
        quantity: 1, record_id: inserted?.id ?? null,
        notes: `Registo ${mat}${totalCars > 1 ? ` (${i + 1}/${totalCars})` : ""}`,
      }));
      const { data: contract, error: cErr } = await supabase.from("contracts").insert(contractsToInsert).select("id");
      if (cErr) toast.warning(`Registo ok, mas contrato falhou: ${cErr.message}`);
      else {
        await logAudit(me, "contract_create", "contract", (contract?.[0]?.id) ?? null, { matricula: mat, card_paid: contractPaid, count: totalCars });
      }
    }



    // Discord: tudo o que SAI (carros e casas) tem de cair nos registos.
    // Venda: o carro vendido. Trocas: cada carro/casa que sai para a contraparte.
    const discordOut: Array<{ modelo: string; matricula: string }> = op === "venda"
      ? (meSouVendedor ? [{ modelo: modelo || "", matricula: mat }] : [])
      : isTroca(op)
        ? [
            ...cars.filter((c) => !c.incoming).map((c) => ({ modelo: c.modelo || "", matricula: c.matricula })),
            ...(isCasas && casaEuDou && casaCp.trim() ? [{ modelo: casaTipo.trim() || "Casa", matricula: casaCp.trim().toUpperCase() }] : []),
            ...cleanExtraOut.filter((c) => c.casa).map((c) => ({ modelo: c.modelo || "Casa", matricula: c.matricula })),
          ]
        : [];

    if (discordOut.length) {
      try {
        const w = await getDiscordWebhookUrl({ data: { kind: op === "venda" && isMota ? "motas" : "carros" } });
        if (!w.ok) throw new Error(w.error);
        for (const item of discordOut) {
          const content =
            `Vendedor: **${meName}**\n` +
            `Nome: **${cpNome}**\n` +
            `CC: **${cpId}**\n` +
            `Marca: **${item.modelo}**\n` +
            `Matrícula: **${item.matricula}**`;
          const res = await fetch(w.url, {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ content }),
          });
          if (!res.ok) throw new Error(`Discord ${res.status}`);
        }
        if (sheetRow) {
          try { await markDiscordSentInSheet({ data: { sheetRow } }); } catch { /* ignore */ }
        }
      } catch (e) {
        toast.warning(`Discord falhou: ${e instanceof Error ? e.message : String(e)}`);
      }
    }


    toast.success("Registo criado!");
    submitKeyRef.current = ""; // registo fechado: o próximo leva marca nova
    setLoading(false); setOpen(false);
    setMatricula(""); setValor(""); setContraparteNome(""); setContraparteId("");
    setModelo(""); setNotes(""); setOp("compra"); setCartaoPago(false); setMeSouComprador(false); setEuPagoTopUp(true);
    setMatriculaEntrada(""); setModeloEntrada(""); setExtraOut([]); setExtraIn([]);
    setIsMota(false); setCasaTipo("Casa"); setCasaCp(""); setCasaEuDou(true); setActorId(me.id); setPartnerId("");
    onCreated();
  };

  const handlePartyPaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    const txt = e.clipboardData.getData("text");
    if (/(Comprador|Vendedor|Nome)\s*:/i.test(txt) || /·\s*ID\b/i.test(txt) || /\bID\s+[A-Z0-9]{4,}/i.test(txt)) {
      e.preventDefault();
      const { name, id } = extractParty(txt);
      if (name) setContraparteNome(name);
      if (id) setContraparteId(id);
    }
  };

  // Colar texto do contrato nos campos do carro: extrai modelo + matrícula.
  const handleCarPaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    const txt = e.clipboardData.getData("text");
    if (/\bmodelo\b/i.test(txt) || /\bmatr[ií]cula\b/i.test(txt)) {
      e.preventDefault();
      const { modelo: mod, matricula: mat } = extractVehicle(txt);
      if (mod) setModelo(mod);
      if (mat) setMatricula(mat);
    }
  };

  // Mesma coisa para o carro principal que entra nas trocas.
  const handleEntradaPaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    const txt = e.clipboardData.getData("text");
    if (/\bmodelo\b/i.test(txt) || /\bmatr[ií]cula\b/i.test(txt)) {
      e.preventDefault();
      const { modelo: mod, matricula: mat } = extractVehicle(txt);
      if (mod) setModeloEntrada(mod);
      if (mat) setMatriculaEntrada(mat);
    }
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button><FilePlus2 className="h-4 w-4 mr-2" />Novo registo</Button>
      </DialogTrigger>
      <DialogContent className="max-h-[90vh] overflow-y-auto">
        <DialogHeader><DialogTitle>Compra / Venda / Troca</DialogTitle></DialogHeader>
        <div className="space-y-4">
          {!meCC && (
            <div className="p-3 rounded-lg bg-warning/10 border border-warning/40 text-sm">
              Ainda não tens o teu CC guardado. Vai ao separador <span className="font-semibold">Perfil</span> para o definir uma vez.
            </div>
          )}
          {isOwner && (
            <div className="space-y-2">
              <Label>Registo em nome de</Label>
              <select className="w-full h-10 rounded-md border border-input bg-input px-3 text-sm" value={actorId} onChange={(e) => setActorId(e.target.value)}>
                {profiles.filter((p) => p.active && p.approved).map((p) => (
                  <option key={p.id} value={p.id}>{p.full_name}{p.id === me?.id ? " (eu)" : ""}</option>
                ))}
              </select>
              {onBehalf && <p className="text-xs text-warning">Este registo (e o cartão em dívida) fica no nome de {meName}.</p>}
            </div>
          )}
          <div className="space-y-2">
            <Label>Operação</Label>
            <select className="w-full h-10 rounded-md border border-input bg-input px-3 text-sm" value={op} onChange={(e) => setOp(e.target.value as VehicleOpKind)}>
              <option value="compra">Compra</option>
              <option value="venda">Venda</option>
              <option value="troca_carros">Troca/carros</option>
              <option value="troca_casas">Troca/casas</option>
            </select>
          </div>


          {op === "troca_carros" && (
            <div className="p-3 rounded-lg bg-secondary text-xs text-muted-foreground space-y-1">
              <p className="text-foreground text-sm font-medium">Como funciona a troca de carros</p>
              <p>Indicas os carros que <b>saem</b> (teus) e os que <b>entram</b> (dele). Cada carro é 1 contrato e 1 linha no Sheets. Se houver dinheiro a mais, dizes quem o dá.</p>
            </div>
          )}
          {isCasas && (
            <div className="p-3 rounded-lg bg-secondary text-xs text-muted-foreground space-y-1">
              <p className="text-foreground text-sm font-medium">Como funciona a troca por casa</p>
              <p>Escolhe quem dá a casa. Se <b>eu dou a casa</b>, os carros do negócio <b>entram</b> (recebo carros). Se <b>recebo a casa</b>, os carros <b>saem</b>. Cada carro é 1 contrato e 1 linha no Sheets; as casas nunca criam linha nem gastam contrato (vão só para a coluna N).</p>
            </div>
          )}

          {isCasas && (
            <div className="flex items-center justify-between p-3 rounded-lg bg-secondary">
              <div>
                <Label>Quem dá a casa?</Label>
                <p className="text-xs text-muted-foreground">{casaEuDou ? "Eu dou a casa → recebo os carros (eu sou o comprador)." : "Ele dá a casa → eu dou os carros (eu sou o vendedor)."}</p>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <span className={casaEuDou ? "" : "text-muted-foreground"}>Eu</span>
                <Switch checked={!casaEuDou} onCheckedChange={(c) => setCasaEuDou(!c)} />
                <span className={!casaEuDou ? "" : "text-muted-foreground"}>Ele</span>
              </div>
            </div>
          )}

          {op === "troca_carros" && (
            <div className="flex items-center justify-between p-3 rounded-lg bg-secondary">
              <div>
                <Label>Eu sou o vendedor?</Label>
                <p className="text-xs text-muted-foreground">{meSouComprador ? "Eu vendo (E/F = eu, G/H = ele) — dispara o Discord." : "Eu compro (E/F = ele, G/H = eu)."}</p>
              </div>
              <Switch checked={meSouComprador} onCheckedChange={setMeSouComprador} />
            </div>
          )}

          <div className="space-y-2 p-3 rounded-lg border border-border/60">
            <Label className="text-sm">{(op === "venda" || (op === "troca_carros" && meSouComprador) || (isCasas && !casaEuDou)) ? "Comprador" : "Vendedor"} (cola a linha inteira do contrato)</Label>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">Nome</Label>
                <Input value={contraparteNome} onChange={(e) => setContraparteNome(e.target.value)} onPaste={handlePartyPaste} placeholder="Ex: Pedro Lourenço" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">CC (ID)</Label>
                <Input value={contraparteId} onChange={(e) => setContraparteId(e.target.value.toUpperCase())} onPaste={handlePartyPaste} placeholder="Ex: YAV38792" />
              </div>
            </div>
            <div className="space-y-1 pt-1">
              <Label className="text-xs text-muted-foreground">É alguém do stand? (negócio interno)</Label>
              <select
                className="w-full h-10 rounded-md border border-input bg-input px-3 text-sm"
                value={partnerId}
                onChange={(e) => {
                  const id = e.target.value;
                  setPartnerId(id);
                  const p = profiles.find((x) => x.id === id);
                  if (p && !contraparteNome.trim()) setContraparteNome(p.full_name);
                }}
              >
                <option value="">Não — cliente de fora</option>
                {profiles.filter((p) => p.id !== (actorId || me?.id)).map((p) => (
                  <option key={p.id} value={p.id}>{p.full_name}</option>
                ))}
              </select>
              <p className="text-[11px] text-muted-foreground">
                O registo fica também no lado dessa pessoa (lucros e ranking), mas o contrato e o cartão só contam para quem faz o registo.
              </p>
            </div>
          </div>


          <div className="space-y-2 p-3 rounded-lg border border-border/60">
            <Label className="text-sm">{op === "troca_carros" ? "Carros que saem (meus)" : isCasas ? (casaEuDou ? "Carro que entra (dele)" : "Carro que sai (meu)") : "Carro"}</Label>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">Modelo</Label>
                <Input value={modelo} onChange={(e) => setModelo(e.target.value)} onPaste={handleCarPaste} placeholder="Ex: Bison HF" />
              </div>
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">Matrícula</Label>
                <Input value={matricula} onChange={(e) => setMatricula(e.target.value.toUpperCase())} onPaste={handleCarPaste} placeholder="O7VC21WI" />
              </div>
            </div>
            {isTroca(op) && (
              <TradeCarsEditor
                title={isCasas ? (casaEuDou ? "Outros carros que também entram (dele)" : "Outros carros que também saem (meus)") : "Outros carros que também saem"}
                cars={isCasas && casaEuDou ? extraIn : extraOut}
                setCars={isCasas && casaEuDou ? setExtraIn : setExtraOut}
                matPlaceholder="O7XXXXXX"
              />
            )}
          </div>


          {isCasas && (
            <div className="space-y-2 p-3 rounded-lg border border-primary/30 bg-primary/5">
              <Label className="text-sm">Casa {casaEuDou ? "que eu dou" : "que eu recebo"} (vai para a coluna N)</Label>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">Tipo</Label>
                  <Input value={casaTipo} onChange={(e) => setCasaTipo(e.target.value)} placeholder="Casa" />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">CP</Label>
                  <Input value={casaCp} onChange={(e) => setCasaCp(e.target.value.toUpperCase())} placeholder="567" />
                </div>
              </div>
              <p className="text-[11px] text-muted-foreground">Fica assim no Sheets: <span className="font-mono">{casaText(casaTipo.trim() || "Casa", casaCp.trim() || "567")}</span></p>
              <TradeCarsEditor
                title={casaEuDou ? "Outras casas que também dou" : "Outras casas que também recebo"}
                cars={casaEuDou ? extraOut : extraIn}
                setCars={casaEuDou ? setExtraOut : setExtraIn}
                matPlaceholder="CP"
                allowCasa
              />
            </div>
          )}



          {op === "troca_carros" && (
            <div className="space-y-3 p-3 rounded-lg border border-primary/30 bg-primary/5">
              <Label className="text-sm">Carros que entram (dele)</Label>
              <p className="text-xs text-muted-foreground">O custo total (soma do que sai + valor pago) é dividido igualmente pelos carros que entram.</p>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">Modelo (principal)</Label>
                  <Input value={modeloEntrada} onChange={(e) => setModeloEntrada(e.target.value)} onPaste={handleEntradaPaste} placeholder="Ex: DR1" />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">Matrícula (principal)</Label>
                  <Input value={matriculaEntrada} onChange={(e) => setMatriculaEntrada(e.target.value.toUpperCase())} onPaste={handleEntradaPaste} placeholder="O7XXXXXX" />
                </div>
              </div>
              <TradeCarsEditor title="Outros carros que também entram" cars={extraIn} setCars={setExtraIn} matPlaceholder="O7XXXXXX" />
            </div>
          )}


          <div className="space-y-2">
            <Label>{isTroca(op) ? "Valor da diferença na troca (€)" : "Valor (€)"}</Label>
            <Input type="text" inputMode="numeric" value={groupDigits(valor)} onChange={(e) => setValor(onlyDigits(e.target.value))} placeholder="Ex: 2 500 000" />
            {isTroca(op) && (
              <div className="flex items-center justify-between p-3 rounded-lg bg-secondary">
                <div>
                  <Label>Quem dá o dinheiro a mais?</Label>
                  <p className="text-xs text-muted-foreground">{euPagoTopUp ? "Eu dou o dinheiro (soma ao custo)." : "É ele que dá o dinheiro (desconta ao custo)."}</p>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <span className={euPagoTopUp ? "" : "text-muted-foreground"}>Eu</span>
                  <Switch checked={!euPagoTopUp} onCheckedChange={(c) => setEuPagoTopUp(!c)} />
                  <span className={!euPagoTopUp ? "" : "text-muted-foreground"}>Ele</span>
                </div>
              </div>
            )}
          </div>

          {geraContrato && !actorNoCard && carCount > 0 && (
            <div className="space-y-3 p-3 rounded-lg bg-secondary">
              <p className="text-xs text-muted-foreground">
                Esta {OP_LABEL[op].toLowerCase()} cria automaticamente <b>{carCount} contrato{carCount > 1 ? "s" : ""}</b> = <b>{cardsPerContract * carCount} cartão</b> em dívida (cada carro é 1 contrato; casas não contam).
              </p>
              <div className="flex items-center justify-between">
                <div>
                  <Label>Cartão entregue no momento?</Label>
                  <p className="text-xs text-muted-foreground">Se sim, +{cardsPerContract * carCount} ao stock de cartão automaticamente.</p>
                </div>
                <Switch checked={cartaoPago} onCheckedChange={setCartaoPago} />
              </div>
            </div>
          )}

          {carCount === 0 && (
            <p className="text-xs text-muted-foreground p-3 rounded-lg bg-secondary">
              Só casas: não gasta contratos nem cartão.
            </p>
          )}

          {geraContrato && actorNoCard && (
            <p className="text-xs text-muted-foreground p-3 rounded-lg bg-secondary">
              {actorPaysFee
                ? "Regime de taxa: não há cartão. Este negócio paga taxa sobre o lucro (ver aba Taxas)."
                : "Owner: o registo conta no ranking mas não gera dívida de cartão."}
            </p>
          )}

          <div className="space-y-2">
            <Label>Notas (só ficam guardadas aqui)</Label>
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} />
          </div>

          {op === "venda" && (
            <label className="flex items-center gap-2 text-xs text-muted-foreground cursor-pointer">
              <Switch checked={isMota} onCheckedChange={setIsMota} />
              <span>É uma mota (envia para o canal das motas)</span>
            </label>
          )}
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={() => setOpen(false)}>Cancelar</Button>
          <Button onClick={submit} disabled={loading}>{loading ? "A guardar…" : "Guardar"}</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function EditRecordDialog({ record, me, sellerName, isOwner, profiles, onSaved }: { record: VehicleRecord; me: Profile | null; sellerName: string; isOwner: boolean; profiles: Profile[]; onSaved: () => void }) {
  const [partnerId, setPartnerId] = useState<string>(record.partner_id || "");

  const [open, setOpen] = useState(false);
  const [matricula, setMatricula] = useState(record.matricula);
  const [op, setOp] = useState<VehicleOpKind>(record.op);
  const [valor, setValor] = useState(String(Math.abs(Number(record.valor))));
  const [euPagoTopUp, setEuPagoTopUp] = useState(Number(record.valor) >= 0);

  const [contraparteNome, setContraparteNome] = useState(record.contraparte_nome || "");
  const [contraparteId, setContraparteId] = useState(record.contraparte_id || "");
  const [modelo, setModelo] = useState(record.modelo || "");
  const [matriculaEntrada, setMatriculaEntrada] = useState(record.matricula_entrada || "");
  const [modeloEntrada, setModeloEntrada] = useState(record.modelo_entrada || "");
  const [notes, setNotes] = useState(record.notes || "");
  const [extraOut, setExtraOut] = useState<TradeCar[]>(record.extra_out || []);
  const [extraIn, setExtraIn] = useState<TradeCar[]>(record.extra_in || []);
  const [isMota, setIsMota] = useState<boolean>(!!record.is_mota);
  // Troca/casas: sou eu que dou a casa? (então os carros entram)
  const [casaEuDou, setCasaEuDou] = useState<boolean>(houseGiven(record));

  // Toggle "Eu sou o vendedor?" — verdadeiro se a contraparte foi colocada como comprador (G/H)
  const [meSouComprador, setMeSouComprador] = useState<boolean>(
    !!record.contraparte_nome && !!record.comprador &&
    record.contraparte_nome.trim().toLowerCase() === record.comprador.trim().toLowerCase()
  );
  // Já tinha disparado Discord na criação? (venda, ou troca em que era vendedor)
  const wasSellerOriginally = record.op === "venda" || (isTroca(record.op) &&
    !!record.contraparte_nome && !!record.comprador &&
    record.contraparte_nome.trim().toLowerCase() === record.comprador.trim().toLowerCase());
  const [sellerCc, setSellerCc] = useState<string>("");

  const [loading, setLoading] = useState(false);

  const isOwnRecord = record.seller_id === me?.id;
  // Se sou owner a editar registo de outra pessoa, uso os dados dela (não os meus).
  const ownerName = isOwnRecord ? (me?.full_name || "") : sellerName;
  const ownerCc = isOwnRecord ? (me?.cc || "") : sellerCc;

  useEffect(() => {
    if (!open || isOwnRecord || !isOwner) return;
    getUserCc({ data: { userId: record.seller_id } })
      .then((r) => setSellerCc(r?.cc ?? ""))
      .catch(() => setSellerCc(""));
  }, [open, isOwnRecord, isOwner, record.seller_id]);

  const meName = ownerName;
  const meCC = ownerCc;


  const handlePartyPaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    const txt = e.clipboardData.getData("text");
    if (/(Comprador|Vendedor|Nome)\s*:/i.test(txt) || /·\s*ID\b/i.test(txt) || /\bID\s+[A-Z0-9]{4,}/i.test(txt)) {
      e.preventDefault();
      const { name, id } = extractParty(txt);
      if (name) setContraparteNome(name);
      if (id) setContraparteId(id);
    }
  };

  // Colar texto do contrato nos campos do carro: extrai modelo + matrícula.
  const handleCarPaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    const txt = e.clipboardData.getData("text");
    if (/\bmodelo\b/i.test(txt) || /\bmatr[ií]cula\b/i.test(txt)) {
      e.preventDefault();
      const { modelo: mod, matricula: mat } = extractVehicle(txt);
      if (mod) setModelo(mod);
      if (mat) setMatricula(mat);
    }
  };

  // Mesma coisa para o carro principal que entra nas trocas.
  const handleEntradaPaste = (e: React.ClipboardEvent<HTMLInputElement>) => {
    const txt = e.clipboardData.getData("text");
    if (/\bmodelo\b/i.test(txt) || /\bmatr[ií]cula\b/i.test(txt)) {
      e.preventDefault();
      const { modelo: mod, matricula: mat } = extractVehicle(txt);
      if (mod) setModeloEntrada(mod);
      if (mat) setMatriculaEntrada(mat);
    }
  };

  const submit = async () => {
    const vAbs = Math.abs(Number(valor));
    if (!matricula.trim() || !Number.isFinite(vAbs)) return toast.error("Matrícula e valor são obrigatórios");
    if (op === "troca_carros" && !matriculaEntrada.trim()) return toast.error("Nas trocas, indica a matrícula que entra");
    if (op === "troca_casas" && !matriculaEntrada.trim()) return toast.error("Indica o CP da casa");
    setLoading(true);
    const mat = matricula.trim().toUpperCase();
    const cpNome = contraparteNome.trim();
    const cpId = contraparteId.trim().toUpperCase();
    // Só aqui no site é que o valor pode ser negativo (quando é ele a dar o
    // dinheiro na troca). No Sheets vai sempre positivo.
    const v = isTroca(op) && !euPagoTopUp ? -vAbs : vAbs;



    const isCasas = op === "troca_casas";
    // Troca/casas: o sentido dos carros vem da casa (dou a casa => carros entram).
    const souVendedorFlag = isCasas ? !casaEuDou : meSouComprador;
    const parties = buildSheetParties(op, meName, meCC, cpNome, cpId, souVendedorFlag);

    const cleanList = (list: TradeCar[]) => list
      .map((c) => ({ matricula: c.matricula.trim().toUpperCase(), modelo: c.modelo.trim(), casa: c.casa === true }))
      .filter((c) => c.matricula);
    const cleanExtraOut = isTroca(op) ? cleanList(extraOut) : [];
    const cleanExtraIn = isTroca(op) ? cleanList(extraIn) : [];
    const updatePayload = {
      matricula: mat, op, valor: v,
      contraparte_nome: cpNome || null, contraparte_id: cpId || null,
      modelo: modelo || null, comprador: parties.compradorNome, notes: notes || null,
      matricula_entrada: isTroca(op) ? matriculaEntrada.trim().toUpperCase() : null,
      modelo_entrada: isTroca(op) ? (modeloEntrada.trim() || (isCasas ? "Casa" : null)) : null,
      extra_out: cleanExtraOut,
      extra_in: cleanExtraIn,
      is_mota: op === "venda" ? isMota : false,
      casa_out: isCasas && casaEuDou,
      casa_in: isCasas && !casaEuDou,
      partner_id: partnerId || null,

    };
    const { error } = await supabase.from("vehicle_records").update(
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      updatePayload as any,
    ).eq("id", record.id);
    if (error) { setLoading(false); return toast.error(error.message); }

    const alteracoes = diffRecordFields(record as unknown as Record<string, unknown>, updatePayload as unknown as Record<string, unknown>);
    await logAudit(me, "record_edit", "vehicle_record", record.id, {
      matricula: mat, op, valor: v,
      vendedor_stand: sellerName,
      linhas_sheets: [record.sheet_row, ...(record.sheet_extra_rows || [])].filter(Boolean),
      alteracoes,
    });


    if (record.sheet_row) {
      try {
        const dateStr = (() => {
          const d = new Date(record.created_at);
          const pad = (n: number) => String(n).padStart(2, "0");
          return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;

        })();

        // Reconstrói todas as linhas do negócio (1 carro = 1 linha), na mesma
        // ordem com que foram criadas, para atualizar cada linha do Sheets.
        type SheetCar = { matricula: string; modelo: string; incoming: boolean };
        const cars: SheetCar[] = [{ matricula: mat, modelo: modelo || "", incoming: isCasas ? casaEuDou : false }];
        if (isTroca(op)) {
          for (const c of cleanExtraOut) if (!c.casa) cars.push({ matricula: c.matricula, modelo: c.modelo, incoming: false });
          if (op === "troca_carros") cars.push({ matricula: matriculaEntrada.trim().toUpperCase(), modelo: modeloEntrada.trim(), incoming: true });
          for (const c of cleanExtraIn) if (!c.casa) cars.push({ matricula: c.matricula, modelo: c.modelo, incoming: true });
        }
        const casaTexts = [
          ...(isCasas && matriculaEntrada.trim() ? [casaText(modeloEntrada.trim() || "Casa", matriculaEntrada.trim().toUpperCase())] : []),
          ...[...cleanExtraOut, ...cleanExtraIn].filter((c) => c.casa).map((c) => casaText(c.modelo || "Casa", c.matricula)),
        ].filter(Boolean);

        const outParties = { vendedorNome: meName, vendedorId: meCC, compradorNome: cpNome, compradorId: cpId };
        const inParties = { vendedorNome: cpNome, vendedorId: cpId, compradorNome: meName, compradorId: meCC };
        const sheetRows = [record.sheet_row, ...(record.sheet_extra_rows || [])];
        const moneySide = euPagoTopUp; // true => o dinheiro fica no carro que entra
        const moneyIdx = isTroca(op) && cars.length > 1
          ? (cars.findIndex((c) => c.incoming === moneySide) >= 0 ? cars.findIndex((c) => c.incoming === moneySide) : 0)
          : 0;

        let failed = "";
        for (let i = 0; i < cars.length && i < sheetRows.length; i++) {
          const car = cars[i];
          const p = isTroca(op) ? (car.incoming ? inParties : outParties) : parties;
          const rowValor = isTroca(op) && cars.length > 1 ? (i === moneyIdx ? vAbs : 0) : vAbs;
          const r = await updateVehicleRecordInSheet({
            data: {
              nome: meName, tipo: op, valor: rowValor, ...p,
              modelo: car.modelo || "", matricula: car.matricula, cont: "",
              casa: i === 0 ? casaTexts.join(" + ") : "",
              sheetRow: sheetRows[i], dateStr,
            },
          });
          if (!r.ok) failed = r.error;
        }
        if (cars.length > sheetRows.length) {
          toast.warning(`Adicionaste carros a mais: só ${sheetRows.length} linha(s) do Sheets estão ligadas a este registo. Os carros extra não foram escritos no Sheets.`);
        }
        if (failed) toast.warning(`Guardado, mas Sheets falhou: ${failed}`);
      } catch (e: unknown) {
        toast.warning(`Guardado, mas Sheets falhou: ${e instanceof Error ? e.message : String(e)}`);
      }
    } else {
      toast.info("Este registo não tem linha do Sheets associada — só foi atualizado aqui.");
    }


    // Se o registo passou a ser uma venda (ou troca em que sou vendedor) e
    // antes não era, dispara agora a notificação para o Discord.
    const nowSeller = op === "venda" || (isTroca(op) && souVendedorFlag);
    if (nowSeller && !wasSellerOriginally) await sendToDiscord();

    toast.success("Registo atualizado");
    setLoading(false); setOpen(false); onSaved();
  };

  // Envio (ou reenvio) manual para o Discord com os dados atuais do formulário.
  // Envia TUDO o que sai (carros e casas), uma mensagem por item.
  const sendToDiscord = async () => {
    const mat = matricula.trim().toUpperCase();
    const cpNome = contraparteNome.trim();
    const cpId = contraparteId.trim().toUpperCase();
    const isCasas = op === "troca_casas";
    const cleanOut = (isTroca(op) ? extraOut : [])
      .map((c) => ({ matricula: c.matricula.trim().toUpperCase(), modelo: c.modelo.trim(), casa: c.casa === true }))
      .filter((c) => c.matricula);
    const items: Array<{ modelo: string; matricula: string }> = op === "venda"
      ? [{ modelo: modelo || "", matricula: mat }]
      : [
          ...(isCasas && casaEuDou ? [] : [{ modelo: modelo || "", matricula: mat }]),
          ...cleanOut.filter((c) => !c.casa).map((c) => ({ modelo: c.modelo, matricula: c.matricula })),
          ...(isCasas && casaEuDou && matriculaEntrada.trim()
            ? [{ modelo: modeloEntrada.trim() || "Casa", matricula: matriculaEntrada.trim().toUpperCase() }]
            : []),
          ...cleanOut.filter((c) => c.casa).map((c) => ({ modelo: c.modelo || "Casa", matricula: c.matricula })),
        ];
    if (!items.length) return toast.info("Este registo não tem nada que saia para enviar ao Discord");
    try {
      const w = await getDiscordWebhookUrl({ data: { kind: op === "venda" && isMota ? "motas" : "carros" } });
      if (!w.ok) throw new Error(w.error);
      for (const item of items) {
        const content =
          `Vendedor: **${meName}**\n` +
          `Nome: **${cpNome}**\n` +
          `CC: **${cpId}**\n` +
          `Marca: **${item.modelo}**\n` +
          `Matrícula: **${item.matricula}**`;
        const res = await fetch(w.url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ content }),
        });
        if (!res.ok) throw new Error(`Discord ${res.status}`);
      }

      if (record.sheet_row) {
        try { await markDiscordSentInSheet({ data: { sheetRow: record.sheet_row } }); } catch { /* ignore */ }
      }
      toast.success("Enviado para o Discord");
    } catch (e) {
      toast.warning(`Discord falhou: ${e instanceof Error ? e.message : String(e)}`);
    }
  };



  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="icon" variant="ghost"><Pencil className="h-4 w-4" /></Button>
      </DialogTrigger>
      <DialogContent className="max-h-[90vh] overflow-y-auto">
        <DialogHeader><DialogTitle>Editar registo</DialogTitle></DialogHeader>
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Matrícula</Label>
              <Input value={matricula} onChange={(e) => setMatricula(e.target.value.toUpperCase())} onPaste={handleCarPaste} />
            </div>
            <div className="space-y-2">
              <Label>Operação</Label>
              <select className="w-full h-10 rounded-md border border-input bg-input px-3 text-sm" value={op} onChange={(e) => setOp(e.target.value as VehicleOpKind)}>
                <option value="compra">Compra</option>
                <option value="venda">Venda</option>
                <option value="troca_carros">Troca/carros</option>
                <option value="troca_casas">Troca/casas</option>
              </select>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Modelo{op === "troca_casas" ? (casaEuDou ? " (carro principal que entra)" : " (carro principal que sai)") : (isTroca(op) ? " (que sai)" : "")}</Label>
              <Input value={modelo} onChange={(e) => setModelo(e.target.value)} onPaste={handleCarPaste} />
            </div>
            <div className="space-y-2">
              <Label>{isTroca(op) ? "Valor pago na troca (€)" : "Valor (€)"}</Label>
              <Input type="text" inputMode="numeric" value={groupDigits(valor)} onChange={(e) => setValor(onlyDigits(e.target.value))} placeholder="Ex: 2 500 000" />
            </div>
          </div>
          {isTroca(op) && (
            <div className="flex items-center justify-between p-3 rounded-lg bg-secondary">
              <div>
                <Label>Quem dá o dinheiro a mais?</Label>
                <p className="text-xs text-muted-foreground">{euPagoTopUp ? "Eu dou o dinheiro (soma ao custo)." : "É ele que dá o dinheiro (desconta ao custo)."}</p>
              </div>
              <div className="flex items-center gap-2 text-xs">
                <span className={euPagoTopUp ? "" : "text-muted-foreground"}>Eu</span>
                <Switch checked={!euPagoTopUp} onCheckedChange={(c) => setEuPagoTopUp(!c)} />
                <span className={!euPagoTopUp ? "" : "text-muted-foreground"}>Ele</span>
              </div>
            </div>
          )}

          {op === "venda" && (
            <label className="flex items-center gap-2 text-xs text-muted-foreground cursor-pointer">
              <Switch checked={isMota} onCheckedChange={setIsMota} />
              <span>É uma mota (envia para o canal das motas)</span>
            </label>
          )}

          {op === "troca_carros" && (
            <div className="space-y-3 p-3 rounded-lg border border-border/60">
              <Label className="text-sm">Carros que saem (meus) — o principal é a matrícula acima</Label>
              <TradeCarsEditor title="Outros carros que também saem" cars={extraOut} setCars={setExtraOut} matPlaceholder="O7XXXXXX" />
            </div>
          )}
          {op === "troca_casas" && (
            <>
              <div className="flex items-center justify-between p-3 rounded-lg bg-secondary">
                <div>
                  <Label>Quem dá a casa?</Label>
                  <p className="text-xs text-muted-foreground">{casaEuDou ? "Eu dou a casa → os carros entram (sou o comprador)." : "Ele dá a casa → os carros saem (sou o vendedor)."}</p>
                </div>
                <div className="flex items-center gap-2 text-xs">
                  <span className={casaEuDou ? "" : "text-muted-foreground"}>Eu</span>
                  <Switch checked={!casaEuDou} onCheckedChange={(c) => setCasaEuDou(!c)} />
                  <span className={!casaEuDou ? "" : "text-muted-foreground"}>Ele</span>
                </div>
              </div>
              <div className="space-y-3 p-3 rounded-lg border border-primary/30 bg-primary/5">
                <Label className="text-sm">Casa (coluna N)</Label>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">Tipo</Label>
                    <Input value={modeloEntrada} onChange={(e) => setModeloEntrada(e.target.value)} placeholder="Casa" />
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs text-muted-foreground">CP</Label>
                    <Input value={matriculaEntrada} onChange={(e) => setMatriculaEntrada(e.target.value.toUpperCase())} placeholder="567" />
                  </div>
                </div>
                <TradeCarsEditor title={casaEuDou ? "Outras casas que também dou" : "Outras casas que também recebo"} cars={casaEuDou ? extraOut : extraIn} setCars={casaEuDou ? setExtraOut : setExtraIn} matPlaceholder="CP" allowCasa />
              </div>
              <div className="space-y-3 p-3 rounded-lg border border-border/60">
                <Label className="text-sm">{casaEuDou ? "Carros que entram (dele)" : "Carros que saem (meus)"} — o principal é a matrícula acima</Label>
                <TradeCarsEditor
                  title={casaEuDou ? "Outros carros que também entram" : "Outros carros que também saem"}
                  cars={casaEuDou ? extraIn : extraOut}
                  setCars={casaEuDou ? setExtraIn : setExtraOut}
                  matPlaceholder="O7XXXXXX"
                />
              </div>
            </>
          )}
          {op === "troca_carros" && (
            <div className="space-y-3 p-3 rounded-lg border border-primary/30 bg-primary/5">
              <Label className="text-sm">Carros que entram (dele)</Label>
              <p className="text-xs text-muted-foreground">Custo total dividido igualmente pelos carros que entram.</p>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">Modelo (principal)</Label>
                  <Input value={modeloEntrada} onChange={(e) => setModeloEntrada(e.target.value)} onPaste={handleEntradaPaste} />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">Matrícula (principal)</Label>
                  <Input value={matriculaEntrada} onChange={(e) => setMatriculaEntrada(e.target.value.toUpperCase())} onPaste={handleEntradaPaste} />
                </div>
              </div>
              <TradeCarsEditor title="Outros carros que também entram" cars={extraIn} setCars={setExtraIn} matPlaceholder="O7XXXXXX" />
            </div>
          )}
          {op === "troca_carros" && (
            <div className="flex items-center justify-between p-3 rounded-lg bg-secondary">
              <div>
                <Label>Eu sou o vendedor?</Label>
                <p className="text-xs text-muted-foreground">Ativa se nesta troca tu és o vendedor.</p>
              </div>
              <Switch checked={meSouComprador} onCheckedChange={setMeSouComprador} />
            </div>
          )}
          <div className="space-y-2 p-3 rounded-lg border border-border/60">
            <Label className="text-sm">{(op === "venda" || (op === "troca_carros" && meSouComprador) || (op === "troca_casas" && !casaEuDou)) ? "Comprador" : "Vendedor"}</Label>

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">Nome</Label>
                <Input value={contraparteNome} onChange={(e) => setContraparteNome(e.target.value)} onPaste={handlePartyPaste} />
              </div>
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">CC (ID)</Label>
                <Input value={contraparteId} onChange={(e) => setContraparteId(e.target.value.toUpperCase())} onPaste={handlePartyPaste} />
              </div>
            </div>
            <div className="space-y-1 pt-1">
              <Label className="text-xs text-muted-foreground">É alguém do stand? (negócio interno)</Label>
              <select
                className="w-full h-10 rounded-md border border-input bg-input px-3 text-sm"
                value={partnerId}
                onChange={(e) => setPartnerId(e.target.value)}
              >
                <option value="">Não — cliente de fora</option>
                {profiles.filter((p) => p.id !== record.seller_id).map((p) => (
                  <option key={p.id} value={p.id}>{p.full_name}</option>
                ))}
              </select>
              <p className="text-[11px] text-muted-foreground">O registo passa a contar também no lado dessa pessoa (sem gastar contrato nem cartão).</p>
            </div>
          </div>

          <div className="space-y-2">
            <Label>Notas (só aqui)</Label>
            <Textarea value={notes} onChange={(e) => setNotes(e.target.value)} />
          </div>
        </div>
        <DialogFooter className="gap-2 sm:justify-between">
          <Button variant="outline" onClick={sendToDiscord} disabled={loading} title="Reenvia esta venda/troca para o Discord">
            Reenviar para o Discord
          </Button>
          <div className="flex gap-2">
            <Button variant="ghost" onClick={() => setOpen(false)}>Cancelar</Button>
            <Button onClick={submit} disabled={loading}>{loading ? "A guardar…" : "Guardar"}</Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

function ChangePasswordDialog() {
  const [open, setOpen] = useState(false);
  const [pw, setPw] = useState("");
  const [pw2, setPw2] = useState("");
  const [loading, setLoading] = useState(false);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (pw.length < 6) return toast.error("Mínimo 6 caracteres");
    if (pw !== pw2) return toast.error("As passwords não coincidem");
    setLoading(true);
    const { error } = await supabase.auth.updateUser({ password: pw });
    setLoading(false);
    if (error) return toast.error(error.message);
    toast.success("Password alterada!");
    setPw(""); setPw2(""); setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="ghost" size="sm">
          <KeyRound className="h-4 w-4 mr-2" /> Password
        </Button>
      </DialogTrigger>
      <DialogContent>
        <DialogHeader><DialogTitle>Alterar password</DialogTitle></DialogHeader>
        <form onSubmit={submit} className="space-y-4">
          <div className="space-y-2">
            <Label>Nova password</Label>
            <Input type="password" value={pw} onChange={(e) => setPw(e.target.value)} minLength={6} required />
          </div>
          <div className="space-y-2">
            <Label>Confirmar nova password</Label>
            <Input type="password" value={pw2} onChange={(e) => setPw2(e.target.value)} minLength={6} required />
          </div>
          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => setOpen(false)}>Cancelar</Button>
            <Button type="submit" disabled={loading}>{loading ? "A guardar…" : "Guardar"}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

function ApprovalsPanel({ profiles, emails, me, onChanged }: { profiles: Profile[]; emails: Record<string, string>; me: Profile | null; onChanged: () => void }) {
  const pending = profiles.filter((p) => p.active && !p.approved && p.full_name !== MASTER_APPROVER);
  const approved = profiles.filter((p) => p.active && (p.approved || p.full_name === MASTER_APPROVER));
  const archived = profiles.filter((p) => !p.active);

  const approve = async (id: string) => {
    const { error } = await supabase.from("profiles").update({ approved: true }).eq("id", id);
    if (error) return toast.error(error.message);
    await logAudit(me, "user_approve", "profile", id);
    toast.success("Aprovado"); onChanged();
  };
  const revoke = async (id: string) => {
    if (!confirm("Revogar acesso?")) return;
    const { error } = await supabase.from("profiles").update({ approved: false }).eq("id", id);
    if (error) return toast.error(error.message);
    await logAudit(me, "user_revoke", "profile", id);
    toast.success("Acesso revogado"); onChanged();
  };
  // Owner deixa de vender/comprar mas continua a gerir: sai das estatísticas
  // e rankings, mantém o acesso total ao site.
  const archiveSelf = async (p: Profile) => {
    if (!confirm(`Arquivar-te a ti (${p.full_name})? Deixas de aparecer na dashboard, cartão e rankings como vendedor ativo, mas continuas com acesso total para gerir o stand.`)) return;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { error } = await (supabase.from("profiles") as any)
      .update({ active: false, left_at: new Date().toISOString() })
      .eq("id", p.id);
    if (error) return toast.error(error.message);
    await logAudit(me, "user_archive", "profile", p.id, { name: p.full_name, self: true });
    toast.success("Arquivado — continuas a gerir o stand"); onChanged();
  };
  // Arquivar = tirar o vendedor da equipa sem perder registos, contratos nem lucros.

  const archive = async (p: Profile) => {
    if (!confirm(`Arquivar ${p.full_name}? Perde o acesso ao site, mas todos os registos, contratos e lucros continuam guardados e visíveis.`)) return;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { error } = await (supabase.from("profiles") as any)
      .update({ active: false, approved: false, left_at: new Date().toISOString() })
      .eq("id", p.id);
    if (error) return toast.error(error.message);
    await logAudit(me, "user_archive", "profile", p.id, { name: p.full_name });
    toast.success(`${p.full_name} arquivado — os registos ficam guardados`); onChanged();
  };
  const restore = async (p: Profile) => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { error } = await (supabase.from("profiles") as any)
      .update({ active: true, approved: true, left_at: null })
      .eq("id", p.id);
    if (error) return toast.error(error.message);
    await logAudit(me, "user_restore", "profile", p.id, { name: p.full_name });
    toast.success(`${p.full_name} reativado`); onChanged();
  };
  const del = async (p: Profile) => {
    if (!confirm(`APAGAR a conta de ${p.full_name}? Isto é irreversível e apaga TAMBÉM os registos, contratos e lucros dele. Se só queres trocar de vendedor, usa "Arquivar".`)) return;
    try {
      await deleteUserAccount({ data: { userId: p.id } });
      await logAudit(me, "user_delete", "profile", p.id, { name: p.full_name });
      toast.success("Conta apagada");
      onChanged();
    } catch (e: unknown) {
      toast.error(e instanceof Error ? e.message : String(e));
    }
  };

  const renderRow = (p: Profile, action: React.ReactNode) => (
    <TableRow key={p.id}>
      <TableCell className="font-medium">{p.full_name}</TableCell>
      <TableCell className="text-sm text-muted-foreground">{emails[p.id] || "—"}</TableCell>
      <TableCell className="text-right">
        <div className="flex items-center justify-end gap-2">
          {action}
          {p.full_name !== MASTER_APPROVER && (
            <Button size="icon" variant="ghost" onClick={() => del(p)} title="Apagar conta (apaga registos)">
              <Trash2 className="h-4 w-4 text-destructive" />
            </Button>
          )}
        </div>
      </TableCell>
    </TableRow>
  );

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Pendentes de aprovação ({pending.length})</CardTitle>
          <CardDescription>Só o {MASTER_APPROVER} vê este separador e aprova quem entra.</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow><TableHead>Nome</TableHead><TableHead>Email</TableHead><TableHead></TableHead></TableRow>
            </TableHeader>
            <TableBody>
              {pending.map((p) => renderRow(p, (
                <Button size="sm" onClick={() => approve(p.id)}><Check className="h-4 w-4 mr-1" /> Aprovar</Button>
              )))}
              {pending.length === 0 && (
                <TableRow><TableCell colSpan={3} className="text-center text-muted-foreground py-6">Sem pedidos pendentes.</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Equipa ativa ({approved.length})</CardTitle>
          <CardDescription>Para trocar de vendedor usa <strong>Arquivar</strong>: ele perde o acesso mas os contratos, registos e lucros mantêm-se.</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow><TableHead>Nome</TableHead><TableHead>Email</TableHead><TableHead></TableHead></TableRow>
            </TableHeader>
            <TableBody>
              {approved.map((p) => renderRow(p, (
                p.full_name !== MASTER_APPROVER ? (
                  <>
                    <Button size="sm" variant="outline" onClick={() => revoke(p.id)}><X className="h-4 w-4 mr-1" /> Revogar</Button>
                    <Button size="sm" variant="secondary" onClick={() => archive(p)}>Arquivar</Button>
                  </>
                ) : (
                  <Button size="sm" variant="secondary" onClick={() => archiveSelf(p)}>Arquivar-me (só giro)</Button>
                )

              )))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Ex-vendedores ({archived.length})</CardTitle>
          <CardDescription>Sem acesso ao site. Os registos, contratos e lucros deles continuam a contar no histórico.</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow><TableHead>Nome</TableHead><TableHead>Email</TableHead><TableHead></TableHead></TableRow>
            </TableHeader>
            <TableBody>
              {archived.map((p) => renderRow(p, (
                <Button size="sm" variant="outline" onClick={() => restore(p)}>Reativar</Button>
              )))}
              {archived.length === 0 && (
                <TableRow><TableCell colSpan={3} className="text-center text-muted-foreground py-6">Nenhum vendedor arquivado.</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

/**
 * Gestão do stand (só owner): o que já entrou de cartão dos vendedores, quanto
 * cartão foi gasto em packs de contratos e o total ganho em taxas.
 */
function ManagementPanel({ stock, contracts, contractsUsedTotal, feePayments, profiles, settings }: {
  stock: StockMovement[]; contracts: Contract[]; contractsUsedTotal: number; feePayments: FeePayment[]; profiles: Profile[]; settings: AppSettings;
}) {
  const isPack = (m: StockMovement) => m.reason === "pack";
  // O cartão antigo não foi todo lucro (parte foi para packs sem registo), por
  // isso o lucro em cartão só conta a partir desta data.
  const [since, setSince] = useState<string>(() => {
    if (typeof window === "undefined") return new Date().toISOString().slice(0, 10);
    return localStorage.getItem("gestao_cartao_since") || new Date().toISOString().slice(0, 10);
  });
  useEffect(() => { try { localStorage.setItem("gestao_cartao_since", since); } catch { /* ignore */ } }, [since]);
  const sinceMs = new Date(`${since}T00:00:00`).getTime();
  const inRange = (iso: string) => new Date(iso).getTime() >= sinceMs;

  let cardIn = 0, cardPackSpent = 0, cardOut = 0, packContracts = 0, contractsManual = 0;
  let cardInBefore = 0, cardPackBefore = 0;
  for (const m of stock) {
    if (AUTO_REASONS.has(m.reason)) continue; // movimentos antigos automáticos: já contam pelos contratos
    if (m.kind === "card") {
      if (!inRange(m.created_at)) {
        if (isPack(m)) cardPackBefore += Math.abs(Math.min(0, m.delta));
        else if (m.delta > 0) cardInBefore += m.delta;
        continue;
      }
      if (isPack(m)) cardPackSpent += Math.abs(Math.min(0, m.delta));
      else if (m.delta > 0) cardIn += m.delta;
      else cardOut += Math.abs(m.delta);
    } else {
      if (m.delta > 0) { if (isPack(m)) packContracts += m.delta; else contractsManual += m.delta; }
    }
  }
  // Cartão entregue pelos vendedores = contratos com cartão dado (dados reais).
  for (const c of contracts) {
    if (!c.card_paid) continue;
    const v = Number(c.card_value || 0);
    if (inRange(c.created_at)) cardIn += v; else cardInBefore += v;
  }
  const contractsUsed = contractsUsedTotal;
  const lucroCartao = cardIn - cardPackSpent;

  const totalTaxas = feePayments.reduce((s, f) => s + Number(f.fee || 0), 0);
  const nameOf = (id: string) => profiles.find((p) => p.id === id)?.full_name || "—";
  const porVendedor = Array.from(
    feePayments.reduce((map, f) => {
      const cur = map.get(f.seller_id) || { fee: 0, lucro: 0, n: 0 };
      map.set(f.seller_id, { fee: cur.fee + Number(f.fee || 0), lucro: cur.lucro + Number(f.profit || 0), n: cur.n + 1 });
      return map;
    }, new Map<string, { fee: number; lucro: number; n: number }>()),
  ).sort((a, b) => b[1].fee - a[1].fee);

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Contar cartão a partir de</CardTitle>
          <CardDescription>O cartão anterior a esta data não conta como lucro (parte foi usada em packs).</CardDescription>
        </CardHeader>
        <CardContent>
          <Input type="date" value={since} onChange={(e) => setSince(e.target.value)} className="w-48" />
        </CardContent>
      </Card>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard icon={<CreditCard className="h-5 w-5" />} label="Cartão recebido (vendedores)" value={String(cardIn)} description={`desde ${since}`} accent="success" />
        <StatCard icon={<Package className="h-5 w-5" />} label="Cartão gasto em packs" value={String(cardPackSpent)} description={`desde ${since}`} accent="warning" />
        <StatCard icon={<TrendingUp className="h-5 w-5" />} label="Cartão que é lucro" value={String(lucroCartao)} description="Recebido − gasto em packs" accent={lucroCartao >= 0 ? "success" : "warning"} />
        <StatCard icon={<Percent className="h-5 w-5" />} label="Total ganho em taxas" value={fmt(totalTaxas)} accent="success" />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Cartão — de onde vem e para onde vai</CardTitle>
          <CardDescription>Só contam movimentos a partir de {since}. Movimentos marcados como <b>pack</b> são cartão gasto para levantar contratos; o resto que entra fica para ti.</CardDescription>
        </CardHeader>
        <CardContent className="text-sm space-y-1">
          <div className="flex justify-between"><span>Cartão entregue pelos vendedores</span><b className="text-success">+{cardIn}</b></div>
          <div className="flex justify-between"><span>Cartão gasto em packs de contratos</span><b className="text-warning">−{cardPackSpent}</b></div>
          <div className="flex justify-between"><span>Cartão retirado (outras saídas)</span><b className="text-warning">−{cardOut}</b></div>
          <div className="flex justify-between border-t pt-2 mt-2"><span className="font-medium">Lucro em cartão</span><b>{lucroCartao}</b></div>
          <div className="flex justify-between text-muted-foreground border-t pt-2 mt-2"><span>Histórico anterior a {since} (não conta)</span><b>+{cardInBefore} / −{cardPackBefore}</b></div>
        </CardContent>
      </Card>


      <Card>
        <CardHeader>
          <CardTitle>Contratos</CardTitle>
          <CardDescription>Pack atual: linhas {settings.sheetNextRow} a {settings.sheetNextRow + settings.sheetPackSize - 1}.</CardDescription>
        </CardHeader>
        <CardContent className="text-sm space-y-1">
          <div className="flex justify-between"><span>Contratos comprados em packs</span><b>{packContracts}</b></div>
          <div className="flex justify-between"><span>Contratos adicionados manualmente</span><b>{contractsManual}</b></div>
          <div className="flex justify-between"><span>Contratos usados/retirados</span><b className="text-warning">−{contractsUsed}</b></div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle>Taxas por vendedor</CardTitle></CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow><TableHead>Vendedor</TableHead><TableHead>Pagamentos</TableHead><TableHead>Lucro declarado</TableHead><TableHead className="text-right">Taxa paga</TableHead></TableRow>
            </TableHeader>
            <TableBody>
              {porVendedor.map(([id, v]) => (
                <TableRow key={id}>
                  <TableCell className="font-medium">{nameOf(id)}</TableCell>
                  <TableCell>{v.n}</TableCell>
                  <TableCell>{fmt(v.lucro)}</TableCell>
                  <TableCell className="text-right font-bold text-success">{fmt(v.fee)}</TableCell>
                </TableRow>
              ))}
              {porVendedor.length === 0 && (
                <TableRow><TableCell colSpan={4} className="text-center text-muted-foreground py-6">Ainda não há taxas pagas.</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}



function StockPanel({ me, isOwner, canEdit, canEditPack, stock, cardTotal, contractTotal, profiles, settings, onChanged }: {
  me: Profile | null; isOwner: boolean; canEdit: boolean; canEditPack: boolean; stock: StockMovement[]; cardTotal: number; contractTotal: number; profiles: Profile[]; settings: AppSettings; onChanged: () => void;

}) {
  const [kind, setKind] = useState<"card" | "contract">("card");
  const [qty, setQty] = useState("1");
  const [notes, setNotes] = useState("");
  const [loading, setLoading] = useState(false);
  const [cardsInput, setCardsInput] = useState(String(settings.cardsPerContract));
  const [rowInput, setRowInput] = useState(String(settings.sheetNextRow));
  const [packInput, setPackInput] = useState(String(settings.sheetPackSize));
  const [savingSettings, setSavingSettings] = useState(false);

  useEffect(() => { setCardsInput(String(settings.cardsPerContract)); }, [settings.cardsPerContract]);
  useEffect(() => { setRowInput(String(settings.sheetNextRow)); }, [settings.sheetNextRow]);
  useEffect(() => { setPackInput(String(settings.sheetPackSize)); }, [settings.sheetPackSize]);

  const endRow = settings.sheetNextRow + settings.sheetPackSize - 1;

  const saveSetting = async (key: "cards_per_contract" | "sheet_next_row" | "sheet_pack_size", value: number) => {
    if (!Number.isFinite(value) || value <= 0) return toast.error("Valor inválido");
    setSavingSettings(true);
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { error } = await (supabase.from as any)("app_settings").upsert({
      key, value_int: Math.floor(value), updated_by: me?.id ?? null, updated_at: new Date().toISOString(),
    }, { onConflict: "key" });
    setSavingSettings(false);
    if (error) return toast.error(error.message);
    await logAudit(me, "settings_update", "app_settings", key, { value });
    toast.success("Definição guardada");
    onChanged();
  };


  const nameOf = (id: string) => profiles.find((p) => p.id === id)?.full_name || "—";

  const [confirmMove, setConfirmMove] = useState<{ sign: 1 | -1; n: number } | null>(null);

  const askMove = (sign: 1 | -1) => {
    const n = Math.abs(parseInt(qty, 10) || 0);
    if (n <= 0) return toast.error("Quantidade inválida");
    setConfirmMove({ sign, n });
  };

  const doMove = async (sign: 1 | -1, n: number) => {
    if (!me) return;
    setLoading(true);
    const { error } = await supabase.from("card_stock_movements").insert({
      delta: sign * n, kind, reason: "manual",
      notes: notes || null, created_by: me.id,
    });
    setLoading(false);
    setConfirmMove(null);
    if (error) return toast.error(error.message);
    await logAudit(me, sign > 0 ? "stock_add" : "stock_remove", "stock", null, { kind, delta: sign * n, notes });
    toast.success(sign > 0 ? `+${n} ao stock (${kind === "card" ? "cartão" : "contratos"})` : `−${n} do stock`);
    setQty("1"); setNotes(""); onChanged();
  };

  const del = async (id: string) => {
    if (!confirm("Apagar movimento?")) return;
    const { error } = await supabase.from("card_stock_movements").delete().eq("id", id);
    if (error) return toast.error(error.message);
    await logAudit(me, "stock_delete", "stock", id);
    toast.success("Apagado"); onChanged();
  };

  // Pack = comprei contratos com cartão. O cartão sai do stash e não é lucro.
  const [packOpen, setPackOpen] = useState(false);
  const [packConfirm, setPackConfirm] = useState(false);
  const [packContracts, setPackContracts] = useState("125");
  const [packCards, setPackCards] = useState("");
  const [packNotes, setPackNotes] = useState("");
  const [packBusy, setPackBusy] = useState(false);
  const packNc = Math.abs(parseInt(packContracts, 10) || 0);
  const packCd = Math.abs(parseInt(packCards, 10) || 0);

  const addPack = async () => {
    if (!me) return;
    const nc = packNc;
    const cards = packCd;
    if (nc <= 0) return toast.error("Nº de contratos inválido");
    setPackBusy(true);
    const rows: Array<{ delta: number; kind: string; reason: string; notes: string | null; created_by: string }> = [
      { delta: nc, kind: "contract", reason: "pack", notes: packNotes || null, created_by: me.id },
    ];
    if (cards > 0) rows.push({ delta: -cards, kind: "card", reason: "pack", notes: packNotes || `Pack de ${nc} contratos`, created_by: me.id });
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { error } = await (supabase.from("card_stock_movements") as any).insert(rows);
    setPackBusy(false);
    if (error) return toast.error(error.message);
    await logAudit(me, "stock_add", "stock", null, { pack: true, contratos: nc, cartao_gasto: cards, notes: packNotes });
    toast.success(`Pack adicionado: +${nc} contratos${cards > 0 ? `, −${cards} cartão` : ""}`);
    setPackCards(""); setPackNotes(""); setPackConfirm(false); setPackOpen(false); onChanged();
  };



  return (
    <div className="space-y-4">
      <div className="grid md:grid-cols-2 gap-4">
        <StatCard icon={<CreditCard className="h-5 w-5" />} label="Stock de cartão" value={String(cardTotal)} accent={cardTotal <= 0 ? "warning" : "success"} />
        <StatCard icon={<FilePlus2 className="h-5 w-5" />} label="Stock de contratos" value={String(contractTotal)} accent={contractTotal <= 0 ? "warning" : "success"} />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Ajustar stock</CardTitle>
          <CardDescription>Só o owner ou vendedores com permissão de <b>Editar</b> em Stock podem alterar.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="grid grid-cols-3 gap-3">
            <div className="space-y-1">
              <Label>Tipo</Label>
              <select className="w-full h-10 rounded-md border border-input bg-input px-3 text-sm disabled:opacity-60" disabled={!canEdit} value={kind} onChange={(e) => setKind(e.target.value as "card" | "contract")}>
                <option value="card">Cartão</option>
                <option value="contract">Contratos</option>
              </select>
            </div>
            <div className="space-y-1">
              <Label>Quantidade</Label>
              <Input type="number" min="1" value={qty} onChange={(e) => setQty(e.target.value)} disabled={!canEdit} />
            </div>
            <div className="space-y-1">
              <Label>Notas (opcional)</Label>
              <Input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Ex: pack novo" disabled={!canEdit} />
            </div>
          </div>
          <div className="flex gap-2">
            <Button onClick={() => askMove(1)} disabled={loading || !canEdit} className="bg-success text-success-foreground hover:bg-success/90">
              + Adicionar ao stock
            </Button>
            <Button onClick={() => askMove(-1)} disabled={loading || !canEdit} variant="outline">
              − Retirar do stock
            </Button>
          </div>
          {!canEdit && (
            <p className="text-xs text-muted-foreground">Sem permissão para alterar o stock. Pede ao owner.</p>
          )}

          <Dialog open={!!confirmMove} onOpenChange={(o) => { if (!o) setConfirmMove(null); }}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Confirmar movimento de stock</DialogTitle>
              </DialogHeader>
              {confirmMove && (
                <div className="space-y-2 text-sm">
                  <p>
                    Vais <b>{confirmMove.sign > 0 ? "adicionar" : "retirar"}</b>{" "}
                    <b>{confirmMove.n}</b> {kind === "card" ? "de cartão" : (confirmMove.n === 1 ? "contrato" : "contratos")}{" "}
                    {confirmMove.sign > 0 ? "ao" : "do"} stock.
                  </p>
                  <p className="text-muted-foreground">
                    Stock atual: {kind === "card" ? cardTotal : contractTotal} → ficará em{" "}
                    <b>{(kind === "card" ? cardTotal : contractTotal) + confirmMove.sign * confirmMove.n}</b>.
                  </p>
                  {notes && <p className="text-muted-foreground">Notas: {notes}</p>}
                </div>
              )}
              <DialogFooter>
                <Button variant="outline" onClick={() => setConfirmMove(null)} disabled={loading}>Cancelar</Button>
                <Button onClick={() => confirmMove && doMove(confirmMove.sign, confirmMove.n)} disabled={loading}>
                  Confirmar
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Adicionar pack de contratos</CardTitle>
          <CardDescription>Usa isto quando compras um pack: entram contratos e sai o cartão que pagaste. Esse cartão <b>não conta como lucro</b>. Ajustes normais em cima = cartão que veio para ti.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <Button onClick={() => { setPackConfirm(false); setPackOpen(true); }} disabled={!canEditPack}>
            <Package className="h-4 w-4 mr-2" /> Adicionar pack
          </Button>
          {!canEditPack && <p className="text-xs text-muted-foreground">Só de leitura. Precisas de permissão de <b>Packs</b> em Stock.</p>}

          <Dialog open={packOpen} onOpenChange={(o) => { if (!packBusy) { setPackOpen(o); if (!o) setPackConfirm(false); } }}>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>{packConfirm ? "Confirmar pack" : "Adicionar pack de contratos"}</DialogTitle>
              </DialogHeader>
              {!packConfirm ? (
                <div className="space-y-3">
                  <div className="space-y-1">
                    <Label>Contratos que entram</Label>
                    <Input type="number" min="1" value={packContracts} onChange={(e) => setPackContracts(e.target.value)} />
                  </div>
                  <div className="space-y-1">
                    <Label>Cartão que sai</Label>
                    <Input type="number" min="0" value={packCards} onChange={(e) => setPackCards(e.target.value)} placeholder="Ex: 6250" />
                  </div>
                  <div className="space-y-1">
                    <Label>Notas (opcional)</Label>
                    <Input value={packNotes} onChange={(e) => setPackNotes(e.target.value)} placeholder="Ex: pack 12/08" />
                  </div>
                </div>
              ) : (
                <div className="space-y-2 text-sm">
                  <p>Vais adicionar <b>+{packNc}</b> contratos e retirar <b>−{packCd}</b> de cartão.</p>
                  <p className="text-muted-foreground">Contratos: {contractTotal} → <b>{contractTotal + packNc}</b></p>
                  <p className="text-muted-foreground">Cartão: {cardTotal} → <b>{cardTotal - packCd}</b></p>
                  {packNotes && <p className="text-muted-foreground">Notas: {packNotes}</p>}
                </div>
              )}
              <DialogFooter>
                {!packConfirm ? (
                  <>
                    <Button variant="outline" onClick={() => setPackOpen(false)}>Cancelar</Button>
                    <Button onClick={() => { if (packNc <= 0) return toast.error("Nº de contratos inválido"); setPackConfirm(true); }}>Continuar</Button>
                  </>
                ) : (
                  <>
                    <Button variant="outline" onClick={() => setPackConfirm(false)} disabled={packBusy}>Voltar</Button>
                    <Button onClick={addPack} disabled={packBusy}>Confirmar</Button>
                  </>
                )}
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </CardContent>
      </Card>






      {isOwner && (
        <Card>
          <CardHeader>
            <CardTitle>Configurações do Google Sheets</CardTitle>
            <CardDescription>Define onde os próximos registos caem no Sheets e o tamanho do pack atual.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid md:grid-cols-3 gap-3">
              <div className="space-y-1">
                <Label>Linha inicial</Label>
                <div className="flex gap-2">
                  <Input type="number" min="1" value={rowInput} onChange={(e) => setRowInput(e.target.value)} />
                  <Button onClick={() => saveSetting("sheet_next_row", parseInt(rowInput, 10))} disabled={savingSettings}>Guardar</Button>
                </div>
                <p className="text-xs text-muted-foreground">Atual: {settings.sheetNextRow}. Primeira linha do pack atual.</p>
              </div>
              <div className="space-y-1">
                <Label>Tamanho do pack (linhas)</Label>
                <div className="flex gap-2">
                  <Input type="number" min="1" value={packInput} onChange={(e) => setPackInput(e.target.value)} />
                  <Button onClick={() => saveSetting("sheet_pack_size", parseInt(packInput, 10))} disabled={savingSettings}>Guardar</Button>
                </div>
                <p className="text-xs text-muted-foreground">Atual: {settings.sheetPackSize}. 125, 150, etc.</p>
              </div>
              <div className="space-y-1">
                <Label>Cartão por contrato</Label>
                <div className="flex gap-2">
                  <Input type="number" min="1" value={cardsInput} onChange={(e) => setCardsInput(e.target.value)} />
                  <Button onClick={() => saveSetting("cards_per_contract", parseInt(cardsInput, 10))} disabled={savingSettings}>Guardar</Button>
                </div>
                <p className="text-xs text-muted-foreground">Atual: {settings.cardsPerContract}. Cada novo contrato vale esta quantidade.</p>
              </div>
            </div>
            <div className="rounded-md border border-border/60 bg-muted/40 p-3 text-sm space-y-3">
              <div>
                <span className="font-medium">Pack atual:</span> linhas {settings.sheetNextRow} a {endRow}.
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-muted-foreground">Próximo pack: linhas {endRow + 2} a {endRow + 1 + settings.sheetPackSize} (deixa a linha {endRow + 1} em branco como separador).</span>
                <Button
                  variant="outline"
                  disabled={savingSettings}
                  onClick={() => saveSetting("sheet_next_row", endRow + 2)}
                >
                  Avançar para o próximo pack
                </Button>
              </div>
              <p className="text-xs text-muted-foreground">Usa isto quando quiseres que os próximos registos caiam já no pack seguinte, mesmo que o atual ainda tenha linhas livres.</p>
            </div>
          </CardContent>
        </Card>
      )}



      <Card>
        <CardHeader><CardTitle>Histórico de movimentos</CardTitle></CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Data</TableHead>
                <TableHead>Tipo</TableHead>
                <TableHead>Quantidade</TableHead>
                <TableHead>Motivo</TableHead>
                <TableHead>Por</TableHead>
                <TableHead>Notas</TableHead>
                <TableHead></TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {stock.map((m) => (
                <TableRow key={m.id}>
                  <TableCell className="text-muted-foreground text-sm">{new Date(m.created_at).toLocaleString("pt-PT")}</TableCell>
                  <TableCell>
                    <Badge variant="outline">{m.kind === "contract" ? "Contrato" : "Cartão"}</Badge>
                  </TableCell>
                  <TableCell className={`font-mono font-bold ${m.delta > 0 ? "text-success" : "text-warning"}`}>
                    {m.delta > 0 ? `+${m.delta}` : m.delta}
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline">
                      {m.reason === "auto_contract" ? "Auto (levantamento)" :
                       m.reason === "auto_card_paid" ? "Auto (cartão entregue)" :
                       m.reason === "pack" ? "Pack (compra)" : "Manual"}

                    </Badge>
                  </TableCell>
                  <TableCell>{nameOf(m.created_by)}</TableCell>
                  <TableCell className="text-sm text-muted-foreground max-w-[220px] truncate">{m.notes || "—"}</TableCell>
                  <TableCell className="text-right">
                    {isOwner && (
                      <Button size="icon" variant="ghost" onClick={() => del(m.id)}><Trash2 className="h-4 w-4" /></Button>
                    )}
                  </TableCell>
                </TableRow>
              ))}
              {stock.length === 0 && (
                <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-6">Sem movimentos ainda.</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

const ACTION_LABEL: Record<string, string> = {
  record_create: "Criou registo",
  record_edit: "Editou registo",
  record_delete: "Apagou registo",
  contract_create: "Criou contrato",
  contract_paid: "Marcou cartão entregue",
  contract_unpaid: "Marcou em dívida",
  contract_delete: "Apagou contrato",
  user_approve: "Aprovou utilizador",
  user_revoke: "Revogou utilizador",
  user_delete: "Apagou conta",
  stock_add: "Adicionou ao stock",
  stock_remove: "Retirou do stock",
  stock_delete: "Apagou movimento de stock",
  permission_grant: "Deu permissão",
  permission_revoke: "Retirou permissão",
};

type AuditCat = "registos" | "contratos" | "stock" | "equipa" | "permissoes" | "outros";
const AUDIT_CAT_LABEL: Record<AuditCat, string> = {
  registos: "Registos", contratos: "Contratos", stock: "Stock",
  equipa: "Equipa", permissoes: "Permissões", outros: "Outros",
};
function auditCat(action: string): AuditCat {
  if (action.startsWith("record_")) return "registos";
  if (action.startsWith("contract_")) return "contratos";
  if (action.startsWith("stock_")) return "stock";
  if (action.startsWith("user_")) return "equipa";
  if (action.startsWith("permission_")) return "permissoes";
  return "outros";
}
function auditTone(action: string): string {
  if (action.endsWith("_delete") || action.endsWith("_revoke") || action.endsWith("_remove") || action === "contract_unpaid")
    return "bg-destructive/15 text-destructive border-destructive/30";
  if (action.endsWith("_create") || action.endsWith("_add") || action.endsWith("_approve") || action.endsWith("_grant") || action === "contract_paid")
    return "bg-success/15 text-success border-success/30";
  return "bg-primary/10 text-primary border-primary/30";
}
function timeAgo(iso: string): string {
  const diff = Date.now() - new Date(iso).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return "agora mesmo";
  if (m < 60) return `há ${m} min`;
  const h = Math.floor(m / 60);
  if (h < 24) return `há ${h}h`;
  const d = Math.floor(h / 24);
  return `há ${d} dia${d === 1 ? "" : "s"}`;
}

/** Detalhes do log em texto legível (sem JSON cru). */
function AuditDetails({ audit }: { audit: AuditLog }) {
  const d = (audit.details || {}) as Record<string, unknown>;
  if (!audit.details || Object.keys(d).length === 0) return <span className="text-muted-foreground">—</span>;

  const alt = Array.isArray(d.alteracoes) ? (d.alteracoes as Array<{ campo: string; antes: string; depois: string }>) : null;
  const linhas = Array.isArray(d.linhas_sheets) ? (d.linhas_sheets as number[]) : [];

  const head: string[] = [];
  if (d.matricula) head.push(String(d.matricula));
  if (d.modelo) head.push(String(d.modelo));
  if (d.vendedor_stand) head.push(`vendedor: ${String(d.vendedor_stand)}`);
  if (d.user) head.push(`utilizador: ${String(d.user)}`);
  if (typeof d.tab === "string") {
    const t = d.tab.replace(":write", "");
    head.push(`${TAB_LABELS[t as TabKey] ?? t}${d.tab.endsWith(":write") ? " (editar)" : " (ver)"}`);
  }
  if (d.quantidade !== undefined) head.push(`quantidade: ${String(d.quantidade)}`);
  if (d.valor !== undefined) head.push(`valor: ${String(d.valor)}`);
  if (linhas.length > 0) head.push(`linhas Sheets: ${linhas.join(", ")}`);

  const known = new Set(["matricula", "modelo", "vendedor_stand", "user", "tab", "quantidade", "valor", "linhas_sheets", "alteracoes"]);
  const rest = Object.entries(d).filter(([k, v]) => !known.has(k) && v !== null && v !== undefined && v !== "");

  return (
    <div className="space-y-1">
      {head.length > 0 && <div className="text-foreground">{head.join(" · ")}</div>}
      {alt && alt.length > 0 && (
        <ul className="space-y-0.5">
          {alt.map((c, i) => (
            <li key={i}>
              <span className="text-foreground font-medium">{c.campo}:</span>{" "}
              <span className="line-through">{c.antes}</span> → <span className="text-foreground">{c.depois}</span>
            </li>
          ))}
        </ul>
      )}
      {alt && alt.length === 0 && <div>Sem alterações de dados.</div>}
      {rest.length > 0 && (
        <div>{rest.map(([k, v]) => `${k}: ${auditValue(v)}`).join(" · ")}</div>
      )}
    </div>
  );
}

function AuditPanel({ audits }: { audits: AuditLog[] }) {
  const [filter, setFilter] = useState("");
  const [cat, setCat] = useState<AuditCat | "all">("all");
  const [who, setWho] = useState<string>("all");

  const actors = useMemo(
    () => Array.from(new Set(audits.map((a) => a.actor_name || "—"))).sort(),
    [audits],
  );

  const filtered = audits.filter((a) => {
    if (cat !== "all" && auditCat(a.action) !== cat) return false;
    if (who !== "all" && (a.actor_name || "—") !== who) return false;
    if (!filter) return true;
    const s = filter.toLowerCase();
    return (a.actor_name || "").toLowerCase().includes(s) ||
      (ACTION_LABEL[a.action] || a.action).toLowerCase().includes(s) ||
      a.entity.toLowerCase().includes(s) ||
      JSON.stringify(a.details || {}).toLowerCase().includes(s);
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle>Auditoria</CardTitle>
        <CardDescription>Tudo o que foi feito no site (últimos 500). Só o owner vê esta aba.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex flex-wrap gap-2">
          {(["all", "registos", "contratos", "stock", "equipa", "permissoes", "outros"] as const).map((c) => (
            <Button
              key={c}
              size="sm"
              variant={cat === c ? "default" : "outline"}
              onClick={() => setCat(c)}
            >
              {c === "all" ? "Tudo" : AUDIT_CAT_LABEL[c]}
            </Button>
          ))}
        </div>
        <div className="grid gap-2 sm:grid-cols-[1fr_220px]">
          <Input placeholder="Procurar por matrícula, nome, ação…" value={filter} onChange={(e) => setFilter(e.target.value)} />
          <select className="h-10 rounded-md border border-input bg-input px-3 text-sm" value={who} onChange={(e) => setWho(e.target.value)}>
            <option value="all">Todas as pessoas</option>
            {actors.map((n) => <option key={n} value={n}>{n}</option>)}
          </select>
        </div>
        <p className="text-xs text-muted-foreground">{filtered.length} evento{filtered.length === 1 ? "" : "s"}</p>

        <div className="space-y-2">
          {filtered.map((a) => (
            <div key={a.id} className="rounded-lg border p-3 flex flex-col sm:flex-row sm:items-start gap-2 sm:gap-4">
              <div className="sm:w-44 shrink-0">
                <div className="text-sm font-medium">{a.actor_name || "—"}</div>
                <div className="text-xs text-muted-foreground">{new Date(a.created_at).toLocaleString("pt-PT")}</div>
                <div className="text-[11px] text-muted-foreground">{timeAgo(a.created_at)}</div>
              </div>
              <div className="flex-1 space-y-1">
                <div className="flex flex-wrap items-center gap-2">
                  <span className={`text-xs px-2 py-0.5 rounded-full border ${auditTone(a.action)}`}>
                    {ACTION_LABEL[a.action] || a.action}
                  </span>
                  <Badge variant="outline" className="text-[10px]">{AUDIT_CAT_LABEL[auditCat(a.action)]}</Badge>
                </div>
                <div className="text-xs text-muted-foreground"><AuditDetails audit={a} /></div>
              </div>
            </div>
          ))}
          {filtered.length === 0 && (
            <div className="text-center text-muted-foreground py-8">Sem eventos com estes filtros.</div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

function PermissionsPanel({ profiles, denies, me, onChanged }: {
  profiles: Profile[]; denies: TabDeny[]; me: Profile | null; onChanged: () => void;
}) {
  const sellers = profiles.filter((p) => p.approved && p.active && !OWNERS.has(p.full_name));
  const [busy, setBusy] = useState<string | null>(null);

  // Colunas da matriz: abas + sub-permissões dentro de uma aba.
  type Level = "hidden" | "view" | "edit";
  type Col = { key: string; tab: TabKey; sub?: string; label: string; group: string; writable: boolean };
  const COLS: Col[] = [
    { key: "dashboard", tab: "dashboard", label: "Dashboard", group: "Geral", writable: false },
    { key: "contratos", tab: "contratos", label: "Contratos", group: "Geral", writable: true },
    { key: "registos", tab: "registos", label: "Registos", group: "Geral", writable: true },
    { key: "lucros", tab: "lucros", label: "Lucros", group: "Geral", writable: false },
    { key: "ranking", tab: "ranking", label: "Ranking", group: "Geral", writable: false },
    { key: "imobiliaria", tab: "imobiliaria", label: "Imobiliária", group: "Geral", writable: false },
    { key: "stock", tab: "stock", label: "Ver aba Stock", group: "Stock", writable: false },
    { key: "stock:adjust", tab: "stock", sub: "adjust", label: "Ajustar stock normal", group: "Stock", writable: true },
    { key: "stock:pack", tab: "stock", sub: "pack", label: "Packs de contratos", group: "Stock", writable: true },
  ];
  const GROUPS = ["Geral", "Stock"] as const;

  const isDenied = (userId: string, tab: string) => denies.some((d) => d.user_id === userId && d.tab === tab);

  const levelOf = (userId: string, col: Col): Level => {
    if (isDenied(userId, col.tab)) return "hidden";
    if (col.sub) {
      // Sub-permissão: precisa de poder editar a aba e não estar negada.
      if (isDenied(userId, `${col.tab}:write`) || isDenied(userId, `${col.tab}:${col.sub}`)) return "view";
      return "edit";
    }
    if (col.writable && isDenied(userId, `${col.tab}:write`)) return "view";
    return col.writable ? "edit" : "view";
  };

  const setDeny = async (userId: string, tab: string, deny: boolean) => {
    if (deny) {
      if (isDenied(userId, tab)) return null;
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const { error } = await (supabase.from as any)("user_tab_denies").insert({ user_id: userId, tab, created_by: me?.id ?? null });
      return error?.message ?? null;
    }
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { error } = await (supabase.from as any)("user_tab_denies").delete().eq("user_id", userId).eq("tab", tab);
    return error?.message ?? null;
  };

  const setLevel = async (p: Profile, col: Col, level: Level) => {
    setBusy(`${p.id}:${col.key}`);
    const errs: Array<string | null> = [];
    if (col.sub) {
      // Ligar sub-permissão implica poder ver e editar a aba.
      if (level === "edit") {
        errs.push(await setDeny(p.id, col.tab, false));
        errs.push(await setDeny(p.id, `${col.tab}:write`, false));
        errs.push(await setDeny(p.id, `${col.tab}:${col.sub}`, false));
      } else {
        errs.push(await setDeny(p.id, `${col.tab}:${col.sub}`, true));
      }
    } else {
      errs.push(await setDeny(p.id, col.tab, level === "hidden"));
      if (col.writable) errs.push(await setDeny(p.id, `${col.tab}:write`, level !== "edit"));
    }
    setBusy(null);
    const bad = errs.filter(Boolean) as string[];
    if (bad.length) return toast.error(bad[0]);
    await logAudit(
      me,
      level === "hidden" ? "permission_revoke" : "permission_grant",
      "user_tab_denies", p.id,
      { tab: col.key, user: p.full_name, nivel: level === "hidden" ? "oculta" : level === "view" ? "ver" : "editar" },
    );
    onChanged();
  };

  const applyPreset = async (p: Profile, preset: "full" | "read" | "none") => {
    setBusy(`${p.id}:preset`);
    for (const t of TAB_KEYS) {
      if (t === "contratos" && p.fee_mode) continue;
      await setDeny(p.id, t, preset === "none");
      await setDeny(p.id, `${t}:write`, preset !== "full");
    }
    for (const c of COLS.filter((c) => c.sub)) {
      await setDeny(p.id, `${c.tab}:${c.sub}`, preset !== "full");
    }
    setBusy(null);
    await logAudit(me, preset === "none" ? "permission_revoke" : "permission_grant", "user_tab_denies", p.id, {
      user: p.full_name, preset: preset === "full" ? "acesso total" : preset === "read" ? "só leitura" : "sem acesso",
    });
    toast.success(`Permissões atualizadas para ${p.full_name}`);
    onChanged();
  };

  const LEVEL_STYLE: Record<Level, string> = {
    hidden: "bg-muted text-muted-foreground",
    view: "bg-primary/15 text-primary",
    edit: "bg-success text-success-foreground",
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle>Permissões</CardTitle>
          <CardDescription>
            Tabela geral: cada linha é um vendedor, cada coluna uma área. Clica na célula para trocar entre{" "}
            <b>Oculta</b>, <b>Ver</b> e <b>Editar</b>. Dentro do Stock podes dar acesso separado a{" "}
            <b>Ajustar stock normal</b> e a <b>Packs de contratos</b>. Owners têm sempre tudo.
          </CardDescription>
        </CardHeader>
      </Card>

      {sellers.length === 0 ? (
        <Card><CardContent className="py-8 text-center text-muted-foreground">Sem vendedores aprovados.</CardContent></Card>
      ) : (
        <Card>
          <CardContent className="p-0 overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b bg-muted/40">
                  <th className="text-left p-3 sticky left-0 bg-muted/40 min-w-[190px]">Vendedor</th>
                  {GROUPS.map((g) => (
                    <th key={g} className="text-center p-2 border-l" colSpan={COLS.filter((c) => c.group === g).length}>
                      {g}
                    </th>
                  ))}
                  <th className="p-2 border-l text-left min-w-[220px]">Atalhos</th>
                </tr>
                <tr className="border-b text-xs text-muted-foreground">
                  <th className="p-2 sticky left-0 bg-card" />
                  {COLS.map((c) => (
                    <th key={c.key} className={`p-2 font-medium whitespace-nowrap ${c.group === "Stock" && c.key === "stock" ? "border-l" : ""}`}>
                      {c.label}
                    </th>
                  ))}
                  <th className="p-2 border-l" />
                </tr>
              </thead>
              <tbody>
                {sellers.map((p) => (
                  <tr key={p.id} className="border-b last:border-0 hover:bg-muted/20">
                    <td className="p-3 sticky left-0 bg-card">
                      <div className="flex items-center gap-2">
                        <span className="font-medium">{p.full_name}</span>
                        {p.fee_mode && <Badge variant="secondary" className="text-[10px]">Taxa</Badge>}
                      </div>
                    </td>
                    {COLS.map((c) => {
                      const disabled = c.tab === "contratos" && p.fee_mode;
                      const level = levelOf(p.id, c);
                      const cycle: Level[] = c.sub ? ["view", "edit"] : c.writable ? ["hidden", "view", "edit"] : ["hidden", "view"];
                      const next = cycle[(cycle.indexOf(level) + 1) % cycle.length]!;
                      const label = disabled ? "—" : level === "hidden" ? "Oculta" : level === "view" ? (c.sub ? "Não" : "Ver") : (c.sub ? "Sim" : "Editar");
                      return (
                        <td key={c.key} className={`p-2 text-center ${c.key === "stock" ? "border-l" : ""}`}>
                          <button
                            type="button"
                            disabled={disabled || busy === `${p.id}:${c.key}` || busy === `${p.id}:preset`}
                            onClick={() => setLevel(p, c, next)}
                            className={`w-full min-w-[74px] rounded-md px-2 py-1.5 text-xs font-medium transition-colors disabled:opacity-50 ${disabled ? "bg-muted text-muted-foreground" : LEVEL_STYLE[level]}`}
                          >
                            {label}
                          </button>
                        </td>
                      );
                    })}
                    <td className="p-2 border-l">
                      <div className="flex flex-wrap gap-1">
                        <Button size="sm" variant="outline" disabled={busy === `${p.id}:preset`} onClick={() => applyPreset(p, "full")}>Tudo</Button>
                        <Button size="sm" variant="outline" disabled={busy === `${p.id}:preset`} onClick={() => applyPreset(p, "read")}>Só ver</Button>
                        <Button size="sm" variant="outline" disabled={busy === `${p.id}:preset`} onClick={() => applyPreset(p, "none")}>Nada</Button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}

      <p className="text-xs text-muted-foreground">
        Quem está em <b>regime de taxa</b> não usa a aba Contratos (marcada com —). A aba Perfil está sempre disponível.
      </p>
    </div>
  );
}



function MyProfitPanel({ profile, rows }: {
  profile: Profile | null;
  rows: Array<{ matricula: string; modelo: string; compra: number; receitas: number; lucro: number; hasCompra: boolean; pending: boolean; houseDeal?: boolean; houseSourced?: boolean; buyerSellerId: string | null; lastSellerId: string | null; tradedAway?: boolean; inherited?: boolean; cycle?: number }>;
}) {
  const mine = useMemo(() => {
    if (!profile) return [];
    return rows.filter((r) => !r.tradedAway && (r.pending ? r.buyerSellerId === profile.id : r.lastSellerId === profile.id));
  }, [rows, profile]);

  const done = mine.filter((r) => !r.pending && r.hasCompra && !r.houseSourced);
  const pending = mine.filter((r) => r.pending);
  const totalCompra = done.reduce((s, r) => s + r.compra, 0);
  const totalReceitas = done.reduce((s, r) => s + r.receitas, 0);
  const totalLucro = done.reduce((s, r) => s + r.lucro, 0);
  const totalPending = pending.reduce((s, r) => s + r.compra, 0);

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard icon={<Car className="h-5 w-5" />} label="Viaturas concluídas" value={String(done.length)} />
        <StatCard icon={<TrendingUp className="h-5 w-5" />} label={`Lucro — ${profile?.full_name || "vendedor"}`} value={fmt(totalLucro)} accent="success" />
        <StatCard icon={<FilePlus2 className="h-5 w-5" />} label="Pendentes" value={String(pending.length)} accent={pending.length > 0 ? "warning" : undefined} />
        <StatCard icon={<CreditCard className="h-5 w-5" />} label="Valor pendente" value={fmt(totalPending)} />
      </div>
      <Card>
        <CardHeader>
          <CardTitle>Detalhe por matrícula</CardTitle>
          <CardDescription>Lucro só é contabilizado quando existe compra e venda/troca.</CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Matrícula</TableHead>
                <TableHead>Modelo</TableHead>
                <TableHead>Compra</TableHead>
                <TableHead>Receitas</TableHead>
                <TableHead>Lucro</TableHead>
                <TableHead>Estado</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {mine.map((r) => (
                <TableRow key={`${r.matricula}#${r.cycle ?? 1}`}>
                  <TableCell className="font-mono">{r.matricula}</TableCell>
                  <TableCell>{r.modelo || "—"}</TableCell>
                  <TableCell className="font-mono">{r.hasCompra ? fmt(r.compra) : "—"}</TableCell>
                  <TableCell className="font-mono">{r.pending ? "—" : fmt(r.receitas)}</TableCell>
                  <TableCell className={`font-mono font-semibold ${r.pending || r.houseSourced ? "text-muted-foreground" : r.lucro >= 0 ? "text-success" : "text-destructive"}`}>{r.pending ? "—" : r.houseSourced ? "negócio casa" : fmt(r.lucro)}</TableCell>
                  <TableCell>{r.pending
                    ? <Badge className="bg-warning text-warning-foreground">{r.houseDeal ? "Vendido (casa)" : "Pendente"}</Badge>
                    : r.houseSourced ? <Badge variant="outline" className="text-warning border-warning">Negócio casa</Badge>
                    : <Badge className="bg-success text-success-foreground">Concluído</Badge>}</TableCell>
                </TableRow>
              ))}
              {mine.length === 0 && (
                <TableRow><TableCell colSpan={6} className="text-center text-muted-foreground py-6">Ainda sem viaturas atribuídas.</TableCell></TableRow>
              )}
            </TableBody>
            {done.length > 0 && (
              <tfoot className="border-t bg-muted/30 font-semibold">
                <tr>
                  <td className="px-4 py-3" colSpan={2}>Totais (concluídas)</td>
                  <td className="px-4 py-3 font-mono">{fmt(totalCompra)}</td>
                  <td className="px-4 py-3 font-mono">{fmt(totalReceitas)}</td>
                  <td className="px-4 py-3 font-mono text-success">{fmt(totalLucro)}</td>
                  <td></td>
                </tr>
              </tfoot>
            )}
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

function TeamPanel({ profiles, directory, isOwner, onSaved }: {
  profiles: Profile[];
  directory: Array<{ id: string; cc: string | null; email: string | null }>;
  isOwner: boolean;
  onSaved: () => void;
}) {
  const dir = new Map(directory.map((d) => [d.id, d]));
  const sorted = [...profiles].sort((a, b) => {
    const am = a.full_name === MASTER_APPROVER ? 0 : OWNERS.has(a.full_name) ? 1 : 2;
    const bm = b.full_name === MASTER_APPROVER ? 0 : OWNERS.has(b.full_name) ? 1 : 2;
    if (am !== bm) return am - bm;
    return a.full_name.localeCompare(b.full_name);
  });

  return (
    <Card>
      <CardHeader>
        <CardTitle>Equipa</CardTitle>
        <CardDescription>
          {isOwner
            ? "Todos os membros com CC, ID do Discord, email e cargo."
            : "Lista de membros da equipa. CC e email só são visíveis ao owner."}
        </CardDescription>
      </CardHeader>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Nome</TableHead>
              <TableHead>CC</TableHead>
              <TableHead>ID Discord</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Cargo</TableHead>
              <TableHead>Regime</TableHead>
              <TableHead>Estado</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {sorted.map((p) => {
              const d = dir.get(p.id);
              const owner = OWNERS.has(p.full_name);
              return (
                <TableRow key={p.id}>
                  <TableCell className="font-medium">{p.full_name}</TableCell>
                  <TableCell className="font-mono text-xs">{isOwner ? (d?.cc || "—") : "—"}</TableCell>
                  <TableCell className="font-mono text-xs">
                    {isOwner
                      ? <DiscordIdEditor userId={p.id} name={p.full_name} value={p.discord_id} onSaved={onSaved} />
                      : (p.discord_id || "—")}
                  </TableCell>
                  <TableCell className="text-xs">{isOwner ? (d?.email || "—") : "—"}</TableCell>
                  <TableCell>
                    {!p.active
                      ? <Badge variant="secondary">Ex-vendedor</Badge>
                      : owner
                        ? <Badge variant="outline" className="border-primary text-primary">Owner</Badge>
                        : <Badge variant="secondary">Vendedor</Badge>}
                  </TableCell>
                  <TableCell>
                    {owner ? (
                      <span className="text-xs text-muted-foreground">—</span>
                    ) : isOwner ? (
                      <div className="flex items-center gap-2">
                        <Switch
                          checked={p.fee_mode}
                          onCheckedChange={async (v) => {
                            // eslint-disable-next-line @typescript-eslint/no-explicit-any
                            const { error } = await (supabase.from as any)("profiles").update({ fee_mode: v }).eq("id", p.id);
                            if (error) { toast.error(error.message); return; }
                            toast.success(v ? `${p.full_name} passa a pagar taxa` : `${p.full_name} volta a pagar cartão`);
                            onSaved();
                          }}
                        />
                        <span className="text-xs text-muted-foreground">{p.fee_mode ? "Taxa" : "Cartão"}</span>
                      </div>
                    ) : (
                      <span className="text-xs text-muted-foreground">{p.fee_mode ? "Taxa" : "Cartão"}</span>
                    )}
                  </TableCell>
                  <TableCell>
                    {!p.active
                      ? <span className="text-xs text-muted-foreground">Saiu{p.left_at ? ` · ${new Date(p.left_at).toLocaleDateString("pt-PT")}` : ""}</span>
                      : p.approved
                        ? <span className="text-xs text-muted-foreground">Aprovado</span>
                        : <Badge className="bg-warning text-warning-foreground">Pendente</Badge>}
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}

function DiscordIdEditor({ userId, name, value, onSaved }: { userId: string; name: string; value: string | null; onSaved: () => void }) {
  const [open, setOpen] = useState(false);
  const [val, setVal] = useState(value || "");
  const [saving, setSaving] = useState(false);

  useEffect(() => { setVal(value || ""); }, [value]);

  const save = async () => {
    const clean = val.replace(/\D/g, "");
    if (clean && (clean.length < 15 || clean.length > 22)) {
      toast.error("ID do Discord inválido (17-19 dígitos)");
      return;
    }
    setSaving(true);
    const { error } = await supabase.from("profiles").update({ discord_id: clean || null }).eq("id", userId);
    setSaving(false);
    if (error) { toast.error(error.message); return; }
    toast.success("ID do Discord guardado");
    setOpen(false);
    onSaved();
  };

  return (
    <>
      <button type="button" className="underline decoration-dotted hover:text-primary" onClick={() => setOpen(true)}>
        {value || "adicionar"}
      </button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>ID do Discord · {name}</DialogTitle>
            <DialogDescription>Apenas números (clica com o botão direito no utilizador do Discord → Copiar ID).</DialogDescription>
          </DialogHeader>
          <Input
            value={val}
            inputMode="numeric"
            placeholder="707573060462706789"
            onChange={(e) => setVal(e.target.value.replace(/\D/g, ""))}
          />
          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)} disabled={saving}>Cancelar</Button>
            <Button onClick={save} disabled={saving}>{saving ? "A guardar…" : "Guardar"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

// ---------------------------------------------------------------------------
// Imobiliária: lucro dos negócios de casas, separado do lucro normal do stand.
// ---------------------------------------------------------------------------
type HouseDeal = {
  rec: VehicleRecord;
  iGaveHouse: boolean;
  casas: string[];
  carsOut: Array<{ matricula: string; modelo: string }>;
  carsIn: Array<{ matricula: string; modelo: string }>;
  money: number;
  custo: number;
  retorno: number;
  lucro: number;
  pendentes: string[];
  custoIncompleto: boolean;
  fechado: boolean;
};

function RealEstatePanel({ deals, nameOf, profiles }: {
  deals: HouseDeal[];
  nameOf: (id: string) => string;
  profiles: Profile[];
}) {
  const [sellerId, setSellerId] = useState<string>("all");
  const list = sellerId === "all" ? deals : deals.filter((d) => d.rec.seller_id === sellerId);

  const fechados = list.filter((d) => d.fechado);
  const lucroTotal = fechados.reduce((s, d) => s + d.lucro, 0);
  const investido = list.filter((d) => !d.fechado).reduce((s, d) => s + d.custo, 0);
  const carLabel = (c: { matricula: string; modelo: string }) => (c.modelo?.trim() ? c.modelo.trim() : c.matricula);
  const fmtDT = (iso: string) => {
    const d = new Date(iso);
    const p = (n: number) => String(n).padStart(2, "0");
    return `${p(d.getDate())}/${p(d.getMonth() + 1)}/${d.getFullYear()} ${p(d.getHours())}:${p(d.getMinutes())}`;
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h2 className="text-xl font-bold flex items-center gap-2"><Home className="h-5 w-5 text-primary" /> Imobiliária</h2>
          <p className="text-sm text-muted-foreground">
            Negócios de casas (troca/casas). O lucro das casas fica aqui e nunca entra no lucro normal do stand.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Label className="text-sm">Vendedor</Label>
          <select className="h-10 rounded-md border border-input bg-input px-3 text-sm" value={sellerId} onChange={(e) => setSellerId(e.target.value)}>
            <option value="all">Todos</option>
            {profiles.map((p) => <option key={p.id} value={p.id}>{p.full_name}</option>)}
          </select>
        </div>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard icon={<Home className="h-5 w-5" />} label="Negócios de casas" value={String(list.length)} />
        <StatCard icon={<Check className="h-5 w-5" />} label="Negócios fechados" value={String(fechados.length)} description="carros recebidos já vendidos" />
        <StatCard icon={<TrendingUp className="h-5 w-5" />} label="Lucro imobiliária" value={fmt(lucroTotal)} accent={lucroTotal >= 0 ? "success" : "warning"} />
        <StatCard icon={<Car className="h-5 w-5" />} label="Ainda por realizar" value={fmt(investido)} description="custo de negócios com carros por vender" accent={investido > 0 ? "warning" : undefined} />
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Negócios</CardTitle>
          <CardDescription>
            Custo = carros que dei + dinheiro que dei. Retorno = venda dos carros que recebi + dinheiro que recebi.
            Enquanto não venderes os carros recebidos, o negócio fica pendente.
          </CardDescription>
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Stand</TableHead>
                <TableHead>Data</TableHead>
                <TableHead>Casa</TableHead>
                <TableHead>Negócio</TableHead>
                <TableHead>Custo</TableHead>
                <TableHead>Retorno</TableHead>
                <TableHead>Lucro</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {list.map((d) => (
                <TableRow key={d.rec.id}>
                  <TableCell className="font-medium whitespace-nowrap">{nameOf(d.rec.seller_id)}</TableCell>
                  <TableCell className="text-sm text-muted-foreground whitespace-nowrap">{fmtDT(d.rec.created_at)}</TableCell>
                  <TableCell className="text-sm">
                    <div className="font-medium">{d.casas.join(" + ") || "—"}</div>
                    <Badge variant="outline" className="mt-1 text-[10px]">{d.iGaveHouse ? "dei a casa" : "recebi a casa"}</Badge>
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    dei <span className="font-mono text-foreground">{[...d.carsOut.map(carLabel), ...(d.iGaveHouse ? d.casas : [])].join(" + ") || "—"}</span>
                    {" → "}recebi <span className="font-mono text-foreground">{[...d.carsIn.map(carLabel), ...(!d.iGaveHouse ? d.casas : [])].join(" + ") || "—"}</span>
                    {d.money !== 0 && <div className="mt-0.5">{d.money > 0 ? `eu dei mais ${fmt(Math.abs(d.money))}` : `recebi mais ${fmt(Math.abs(d.money))}`}</div>}
                  </TableCell>
                  <TableCell className="font-mono">
                    {fmt(d.custo)}
                    {d.custoIncompleto && <div className="text-[10px] text-warning">sem custo de compra de algum carro</div>}
                  </TableCell>
                  <TableCell className="font-mono">
                    {fmt(d.retorno)}
                    {d.pendentes.length > 0 && <div className="text-[10px] text-warning">por vender: {d.pendentes.join(", ")}</div>}
                  </TableCell>
                  <TableCell className="font-mono font-bold">
                    {d.fechado
                      ? <span className={d.lucro > 0 ? "text-success" : d.lucro < 0 ? "text-destructive" : "text-muted-foreground"}>{fmt(d.lucro)}</span>
                      : <Badge variant="outline" className="text-warning border-warning">pendente</Badge>}
                  </TableCell>
                </TableRow>
              ))}
              {list.length === 0 && (
                <TableRow><TableCell colSpan={7} className="text-center text-muted-foreground py-8">Ainda não há negócios de casas.</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}

/**
 * Aba Taxas: para os vendedores em regime de taxa (não pagam cartão, pagam
 * FEE_PERCENT% do lucro de cada carro vendido). Só o owner e o próprio veem.
 */
type ProfitRow = {
  matricula: string; modelo: string; compra: number; receitas: number; lucro: number;
  hasCompra: boolean; pending: boolean; houseDeal: boolean; tradedAway: boolean;
  lastSellerId: string | null; outSellerId: string | null; outRecordId: string | null; cycle: number; refDate: string;
};

type ManualCost = { id: string; seller_id: string; matricula: string; cycle: number; record_id: string | null; cost: number; sale: number | null; cost_override: number | null; sale_override: number | null };

/** Valor fixo vindo dos registos que o owner pode corrigir só para as taxas. */
function OwnerOverride({ value, overridden, onSave }: { value: number; overridden: boolean; onSave: (raw: string) => Promise<void> }) {
  const [editing, setEditing] = useState(false);
  const [v, setV] = useState("");
  if (!editing) {
    return (
      <button type="button" className="inline-flex items-center gap-1 hover:text-primary" title="Editar (owner)" onClick={() => { setV(groupDigits(String(value))); setEditing(true); }}>
        {fmt(value)} <Pencil className="h-3 w-3 opacity-60" />
        {overridden && <Badge variant="outline" className="ml-1 text-[10px] px-1 py-0">editado</Badge>}
      </button>
    );
  }
  return (
    <div className="flex items-center gap-1">
      <Input autoFocus className="h-8 w-32 font-mono" inputMode="numeric" value={v} onChange={(e) => setV(groupDigits(onlyDigits(e.target.value)))} />
      <Button size="sm" variant="outline" onClick={async () => { await onSave(v); setEditing(false); }}><Check className="h-3 w-3" /></Button>
      <Button size="sm" variant="ghost" onClick={() => setEditing(false)}><X className="h-3 w-3" /></Button>
    </div>
  );
}

function FeesPanel({ me, isOwner, profiles, profitRows, feePayments, records, onSaved }: {
  records: VehicleRecord[];
  me: Profile | null;
  isOwner: boolean;
  profiles: Profile[];
  profitRows: ProfitRow[];
  feePayments: FeePayment[];
  onSaved: () => void;
}) {
  const feeProfiles = profiles.filter((p) => p.fee_mode);
  const [sellerId, setSellerId] = useState<string>(() => (me?.fee_mode ? me.id : (feeProfiles[0]?.id ?? "")));
  const [sel, setSel] = useState<Set<string>>(new Set());
  const [saving, setSaving] = useState(false);
  const [confirm, setConfirm] = useState(false);
  const [manual, setManual] = useState<ManualCost[]>([]);
  const [draft, setDraft] = useState<Record<string, string>>({});
  const [preview, setPreview] = useState<{ matricula: string; recordId: string | null } | null>(null);

  // Sem permissões de owner cada um só vê as suas próprias taxas.
  const targetId = isOwner ? sellerId : (me?.id ?? "");
  useEffect(() => { setSel(new Set()); }, [targetId]);

  const loadManual = async () => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { data } = await (supabase.from as any)("fee_manual_costs").select("*");
    setManual(((data as ManualCost[]) || []).map((m) => ({ ...m, cost: Number(m.cost), sale: m.sale == null ? null : Number(m.sale), cost_override: m.cost_override == null ? null : Number(m.cost_override), sale_override: m.sale_override == null ? null : Number(m.sale_override) })));
  };
  useEffect(() => { void loadManual(); }, [targetId]);

  const keyOf = (matricula: string, cycle: number, recordId: string | null) => `${matricula}#${cycle}#${recordId ?? ""}`;
  const paid = new Map(
    feePayments.filter((f) => f.seller_id === targetId).map((f) => [keyOf(f.matricula, f.cycle, f.record_id), f]),
  );
  const manualMap = new Map(
    manual.filter((m) => m.seller_id === targetId).map((m) => [`${m.matricula}#${m.cycle}`, m]),
  );

  /** Tudo o que saiu do vendedor: vendas e carros dados em trocas (carros/casas). */
  const rows = profitRows
    .filter((r) => r.outSellerId === targetId && (r.receitas > 0 || r.tradedAway || r.houseDeal))
    .map((r) => {
      const key = keyOf(r.matricula, r.cycle, r.outRecordId);
      const man = manualMap.get(`${r.matricula}#${r.cycle}`) || null;
      const isTroca = r.tradedAway || r.houseDeal;
      const compraBase = r.hasCompra ? r.compra : (man ? man.cost : null);
      const compra = man?.cost_override != null ? man.cost_override : compraBase;
      // Nas trocas não há valor de venda registado — o vendedor preenche-o.
      const vendaBase = isTroca ? (man && man.sale != null ? man.sale : null) : r.receitas;
      const venda = man?.sale_override != null ? man.sale_override : vendaBase;
      const lucro = compra == null || venda == null ? null : venda - compra;
      const fee = lucro != null && lucro > 0 ? Math.round((lucro * FEE_PERCENT) / 100) : 0;
      return { ...r, key, man, isTroca, compra, venda, lucro, fee, payment: paid.get(key) || null };
    })
    .sort((a, b) => (b.refDate || "").localeCompare(a.refDate || ""));

  const pendentes = rows.filter((r) => !r.payment && r.lucro != null && r.fee > 0);
  const semCompra = rows.filter((r) => r.compra == null || r.venda == null);
  const totalPendente = pendentes.reduce((s, r) => s + r.fee, 0);
  const totalPago = rows.filter((r) => r.payment).reduce((s, r) => s + r.fee, 0);
  const selecionados = pendentes.filter((r) => sel.has(r.key));
  const totalSel = selecionados.reduce((s, r) => s + r.fee, 0);

  const toggle = (key: string) => {
    setSel((prev) => {
      const next = new Set(prev);
      if (next.has(key)) next.delete(key); else next.add(key);
      return next;
    });
  };

  const saveCost = async (row: { matricula: string; cycle: number; outRecordId: string | null; man: ManualCost | null }, raw: string, field: "cost" | "sale" | "cost_override" | "sale_override" = "cost") => {
    if (!me) return;
    const value = Number(onlyDigits(raw));
    if (!raw.trim()) return;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const table = (supabase.from as any)("fee_manual_costs");
    const { error } = row.man
      ? await table.update({ [field]: value }).eq("id", row.man.id)
      : await table.insert({ seller_id: targetId, matricula: row.matricula, cycle: row.cycle, record_id: row.outRecordId, cost: field === "cost" ? value : 0, sale: field === "sale" ? value : null, cost_override: field === "cost_override" ? value : null, sale_override: field === "sale_override" ? value : null, created_by: me.id });
    if (error) { toast.error(error.message); return; }
    toast.success(field.startsWith("cost") ? "Valor de compra guardado" : "Valor de venda guardado");
    setDraft((d) => ({ ...d, [`${row.matricula}#${row.cycle}${field === "sale" ? ":v" : ""}`]: "" }));
    await loadManual();
  };

  const marcarPago = async () => {
    if (!me || selecionados.length === 0) return;
    setSaving(true);
    const payload = selecionados.map((r) => ({
      seller_id: targetId, matricula: r.matricula, cycle: r.cycle, record_id: r.outRecordId,
      profit: r.lucro ?? 0, fee: r.fee, marked_by: me.id,
    }));
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { error } = await (supabase.from as any)("fee_payments").insert(payload);
    setSaving(false);
    setConfirm(false);
    if (error) { toast.error(error.message); return; }
    await logAudit(me, "fee_paid", "fee_payment", null, { vendedor: profiles.find((p) => p.id === targetId)?.full_name, carros: selecionados.length, total: totalSel });
    toast.success(`Taxa marcada como paga: ${fmt(totalSel)}`);
    // Notifica o(s) owner(s) dentro do site (não vai para o Discord)
    const sellerName = profiles.find((p) => p.id === targetId)?.full_name || "Vendedor";
    const ownerIds = profiles.filter((p) => OWNERS.has(p.full_name)).map((p) => p.id);
    if (ownerIds.length > 0) {
      const msg = `💸 ${sellerName} marcou ${selecionados.length} taxa(s) como paga — total ${fmt(totalSel)}`;
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      await (supabase.from as any)("notifications").insert(ownerIds.map((uid) => ({ user_id: uid, message: msg })));
    }
    setSel(new Set());
    onSaved();
  };

  const desmarcar = async (id: string) => {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const { error } = await (supabase.from as any)("fee_payments").delete().eq("id", id);
    if (error) { toast.error(error.message); return; }
    toast.success("Pagamento anulado");
    onSaved();
  };

  if (feeProfiles.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle>Taxas</CardTitle>
          <CardDescription>Nenhum vendedor está em regime de taxa. Ativa na aba Equipa.</CardDescription>
        </CardHeader>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <StatCard icon={<Percent className="h-5 w-5" />} label={`Taxa por saída (${FEE_PERCENT}%)`} value={`${FEE_PERCENT}%`} description="Do lucro de cada carro vendido ou trocado" />
        <StatCard icon={<CreditCard className="h-5 w-5" />} label="Taxa em dívida" value={fmt(totalPendente)} accent={totalPendente > 0 ? "warning" : undefined} description={`${pendentes.length} saída(s) por pagar`} />
        <StatCard icon={<Check className="h-5 w-5" />} label="Taxa já paga" value={fmt(totalPago)} />
      </div>

      {semCompra.length > 0 && (
        <Card className="border-warning/60">
          <CardContent className="py-3 text-sm text-muted-foreground">
            {semCompra.length} saída(s) sem valores completos — escreve o valor de compra (e, nas trocas, o valor de venda) para calcular o lucro e a taxa.
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="flex-row items-center justify-between gap-3 flex-wrap">
          <div>
            <CardTitle>Taxas por saída</CardTitle>
            <CardDescription>Vendas e carros dados em trocas. Seleciona os que vais pagar — o total aparece em baixo.</CardDescription>
          </div>
          {isOwner && (
            <select className="h-9 rounded-md border border-input bg-input px-3 text-sm" value={sellerId} onChange={(e) => setSellerId(e.target.value)}>
              {feeProfiles.map((p) => <option key={p.id} value={p.id}>{p.full_name}</option>)}
            </select>
          )}
        </CardHeader>
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-10"></TableHead>
                <TableHead>Data</TableHead>
                <TableHead>Modelo</TableHead>
                <TableHead>Matrícula</TableHead>
                <TableHead>Valor compra</TableHead>
                <TableHead>Valor venda</TableHead>
                <TableHead>Lucro</TableHead>
                <TableHead>Taxa {FEE_PERCENT}%</TableHead>
                <TableHead>Estado</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {rows.map((r) => {
                const dkey = `${r.matricula}#${r.cycle}`;
                const podeEditar = !r.payment && (isOwner || targetId === me?.id);
                const editable = !r.hasCompra && podeEditar;
                const vendaEditable = r.isTroca && podeEditar;
                return (
                  <TableRow key={r.key} className={r.payment ? "opacity-60" : ""}>
                    <TableCell>
                      {!r.payment && r.lucro != null && r.fee > 0 && (
                        <input type="checkbox" className="h-4 w-4 accent-[hsl(var(--primary))]" checked={sel.has(r.key)} onChange={() => toggle(r.key)} />
                      )}
                    </TableCell>
                    <TableCell className="text-sm text-muted-foreground">{r.refDate ? new Date(r.refDate).toLocaleDateString("pt-PT") : "—"}</TableCell>
                    <TableCell className="font-medium">{r.modelo || "—"}</TableCell>
                    <TableCell className="font-mono text-xs">
                      <button type="button" className="inline-flex items-center gap-1 hover:text-primary" title="Ver negócio" onClick={() => setPreview({ matricula: r.matricula, recordId: r.outRecordId })}>
                        {r.matricula} <Eye className="h-3.5 w-3.5 opacity-70" />
                      </button>
                    </TableCell>
                    <TableCell className="font-mono">
                      {r.hasCompra ? (isOwner && !r.payment ? (
                        <OwnerOverride value={r.compra as number} overridden={r.man?.cost_override != null} onSave={(v) => saveCost(r, v, "cost_override")} />
                      ) : fmt(r.compra as number)) : editable ? (
                        <div className="flex items-center gap-1">
                          <Input
                            className="h-8 w-32 font-mono"
                            inputMode="numeric"
                            placeholder={r.man ? fmt(r.man.cost) : "0"}
                            value={draft[dkey] ?? (r.man ? groupDigits(String(r.man.cost)) : "")}
                            onChange={(e) => setDraft((d) => ({ ...d, [dkey]: groupDigits(onlyDigits(e.target.value)) }))}
                          />
                          <Button size="sm" variant="outline" onClick={() => void saveCost(r, draft[dkey] ?? (r.man ? String(r.man.cost) : ""))}>
                            <Check className="h-3 w-3" />
                          </Button>
                        </div>
                      ) : r.compra != null ? fmt(r.compra) : "—"}
                    </TableCell>
                    <TableCell className="font-mono">
                      {!r.isTroca ? (isOwner && !r.payment ? (
                        <OwnerOverride value={r.venda as number} overridden={r.man?.sale_override != null} onSave={(v) => saveCost(r, v, "sale_override")} />
                      ) : fmt(r.venda as number)) : vendaEditable ? (
                        <div className="flex items-center gap-1">
                          <Input
                            className="h-8 w-32 font-mono"
                            inputMode="numeric"
                            placeholder={r.man?.sale != null ? fmt(r.man.sale) : "0"}
                            value={draft[`${dkey}:v`] ?? (r.man?.sale != null ? groupDigits(String(r.man.sale)) : "")}
                            onChange={(e) => setDraft((d) => ({ ...d, [`${dkey}:v`]: groupDigits(onlyDigits(e.target.value)) }))}
                          />
                          <Button size="sm" variant="outline" onClick={() => void saveCost(r, draft[`${dkey}:v`] ?? (r.man?.sale != null ? String(r.man.sale) : ""), "sale")}>
                            <Check className="h-3 w-3" />
                          </Button>
                        </div>
                      ) : r.venda != null ? fmt(r.venda) : "—"}
                    </TableCell>
                    <TableCell className={`font-mono ${(r.lucro ?? 0) >= 0 ? "text-success" : "text-destructive"}`}>{r.lucro == null ? "—" : fmt(r.lucro)}</TableCell>
                    <TableCell className="font-mono font-semibold">{r.lucro == null ? "—" : fmt(r.fee)}</TableCell>
                    <TableCell>
                      {r.payment ? (
                        <div className="flex items-center gap-2">
                          <Badge className="bg-success text-success-foreground"><Check className="h-3 w-3 mr-1" />Paga</Badge>
                          {isOwner && (
                            <Button size="sm" variant="ghost" onClick={() => desmarcar(r.payment!.id)}><X className="h-3 w-3" /></Button>
                          )}
                        </div>
                      ) : r.compra == null || r.venda == null ? (
                        <Badge variant="outline" className="border-warning text-warning">{r.compra == null ? "Falta valor de compra" : "Falta valor de venda"}</Badge>
                      ) : (
                        <Badge className="bg-warning text-warning-foreground">Por pagar</Badge>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
              {rows.length === 0 && (
                <TableRow><TableCell colSpan={9} className="text-center text-muted-foreground py-6">Ainda não há saídas.</TableCell></TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="py-4 flex items-center justify-between gap-4 flex-wrap">
          <div>
            <p className="text-sm text-muted-foreground">{selecionados.length} saída(s) selecionada(s)</p>
            <p className="text-2xl font-bold font-mono">{fmt(totalSel)}</p>
          </div>
          <Button disabled={selecionados.length === 0 || saving} onClick={() => setConfirm(true)}>
            <Check className="h-4 w-4 mr-2" /> Marcar como pago
          </Button>
        </CardContent>
      </Card>

      <DealPreviewDialog preview={preview} records={records} profiles={profiles} onClose={() => setPreview(null)} />
      <Dialog open={confirm} onOpenChange={setConfirm}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirmar pagamento de taxa</DialogTitle>
            <DialogDescription>
              Vais marcar {selecionados.length} venda(s) como taxa paga, num total de {fmt(totalSel)}.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setConfirm(false)}>Cancelar</Button>
            <Button onClick={marcarPago} disabled={saving}>Confirmar</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function DealPreviewDialog({ preview, records, profiles, onClose }: {
  preview: { matricula: string; recordId: string | null } | null;
  records: VehicleRecord[]; profiles: Profile[]; onClose: () => void;
}) {
  const norm = (m: string | null | undefined) => (m ?? "").replace(/[\s-]/g, "").toUpperCase();
  const key = norm(preview?.matricula);
  const touches = (r: VehicleRecord) =>
    norm(r.matricula) === key || norm(r.matricula_entrada) === key ||
    (r.extra_in ?? []).some((c) => norm(c.matricula) === key) ||
    (r.extra_out ?? []).some((c) => norm(c.matricula) === key);
  const list = preview ? records.filter(touches).sort((a, b) => a.created_at.localeCompare(b.created_at)) : [];
  const nameOf = (id: string | null) => profiles.find((p) => p.id === id)?.full_name ?? "—";
  const cars = (arr: TradeCar[]) => arr.filter((c) => c.matricula || c.modelo).map((c) => `${c.modelo || "?"} (${c.matricula || "—"})`).join(", ");
  return (
    <Dialog open={!!preview} onOpenChange={(o) => { if (!o) onClose(); }}>
      <DialogContent className="max-w-2xl max-h-[85vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Negócios da matrícula {preview?.matricula}</DialogTitle>
          <DialogDescription>Registos feitos no site onde esta matrícula aparece.</DialogDescription>
        </DialogHeader>
        {list.length === 0 && <p className="text-sm text-muted-foreground">Nenhum registo encontrado.</p>}
        <div className="space-y-3">
          {list.map((r) => {
            const extraOut = cars(r.extra_out ?? []);
            const extraIn = cars(r.extra_in ?? []);
            return (
              <div key={r.id} className={`rounded-lg border p-3 text-sm space-y-1 ${r.id === preview?.recordId ? "border-primary bg-primary/5" : ""}`}>
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <Badge variant="outline">{OP_LABEL[r.op] ?? r.op}</Badge>
                    {r.id === preview?.recordId && <Badge>Este negócio</Badge>}
                  </div>
                  <span className="text-xs text-muted-foreground">{new Date(r.created_at).toLocaleString("pt-PT")}</span>
                </div>
                <div><span className="text-muted-foreground">Vendedor:</span> {nameOf(r.seller_id)}</div>
                <div><span className="text-muted-foreground">Carro:</span> {r.modelo || "—"} <span className="font-mono text-xs">({r.matricula})</span></div>
                {r.matricula_entrada && <div><span className="text-muted-foreground">Entrada:</span> {r.modelo_entrada || "—"} <span className="font-mono text-xs">({r.matricula_entrada})</span></div>}
                {extraOut && <div><span className="text-muted-foreground">Também saiu:</span> {extraOut}</div>}
                {extraIn && <div><span className="text-muted-foreground">Também entrou:</span> {extraIn}</div>}
                <div><span className="text-muted-foreground">Valor:</span> <span className="font-mono">{fmt(Number(r.valor))}</span></div>
                {(r.contraparte_nome || r.contraparte || r.partner_id) && (
                  <div><span className="text-muted-foreground">Cliente:</span> {r.partner_id ? nameOf(r.partner_id) : (r.contraparte_nome || r.contraparte)}{r.contraparte_id ? ` · CC ${r.contraparte_id}` : ""}</div>
                )}
                {r.sheet_row != null && <div><span className="text-muted-foreground">Linha Sheets:</span> {r.sheet_row}</div>}
                {r.notes && <div><span className="text-muted-foreground">Notas:</span> {r.notes}</div>}
              </div>
            );
          })}
        </div>
      </DialogContent>
    </Dialog>
  );
}
