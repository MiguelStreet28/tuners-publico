import { describe, it as test } from "node:test";
import assert from "node:assert/strict";
import { createSerialRefresh } from "./serial-refresh";

describe("serial refresh", () => {
  test("a synchronous burst shares one read", async () => {
    let reads = 0;
    const refresh = createSerialRefresh(async () => { reads += 1; });
    await Promise.all(Array.from({ length: 20 }, () => refresh()));
    assert.equal(reads, 1);
  });

  test("changes during a read trigger one trailing read without overlap", async () => {
    let reads = 0;
    let active = 0;
    let peak = 0;
    let release: (() => void) | undefined;
    const gate = new Promise<void>((resolve) => { release = resolve; });
    const refresh = createSerialRefresh(async () => {
      reads += 1;
      active += 1;
      peak = Math.max(peak, active);
      if (reads === 1) await gate;
      active -= 1;
    });
    const first = refresh();
    await Promise.resolve();
    const pending = Array.from({ length: 20 }, () => refresh());
    release?.();
    await Promise.all([first, ...pending]);
    assert.equal(reads, 2);
    assert.equal(peak, 1);
  });

  test("failed reads do not block a subsequent refresh", async () => {
    let reads = 0;
    const refresh = createSerialRefresh(async () => {
      reads += 1;
      if (reads === 1) throw new Error("unavailable");
    });
    await assert.rejects(refresh(), /unavailable/);
    await refresh();
    assert.equal(reads, 2);
  });
});