import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";


export const listUserEmails = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: isOwner } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "owner",
    });
    if (!isOwner) throw new Error("Forbidden");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const emails: Record<string, string> = {};
    let page = 1;
    // simple loop – team is tiny
    while (page < 20) {
      const { data, error } = await supabaseAdmin.auth.admin.listUsers({ page, perPage: 200 });
      if (error) throw new Error(error.message);
      for (const u of data.users) {
        if (u.email) emails[u.id] = u.email;
      }
      if (data.users.length < 200) break;
      page += 1;
    }
    return emails;
  });

export const deleteUserAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { userId: string }) => input)
  .handler(async ({ data, context }) => {
    const { data: isOwner } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "owner",
    });
    if (!isOwner) throw new Error("Forbidden");
    if (data.userId === context.userId) throw new Error("Não podes apagar a tua própria conta");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    // Clean dependent rows first (no FK cascades defined for some)
    await supabaseAdmin.from("contracts").delete().eq("seller_id", data.userId);
    await supabaseAdmin.from("vehicle_records").delete().eq("seller_id", data.userId);
    await supabaseAdmin.from("user_roles").delete().eq("user_id", data.userId);
    await supabaseAdmin.from("profiles").delete().eq("id", data.userId);
    const { error } = await supabaseAdmin.auth.admin.deleteUser(data.userId);
    if (error) throw new Error(error.message);
    return { ok: true as const };
  });

export const getMyCc = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("profiles")
      .select("cc")
      .eq("id", context.userId)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return { cc: (data?.cc as string | null) ?? null };
  });

export const getUserCc = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { userId: string }) => input)
  .handler(async ({ data, context }) => {
    const { data: isOwner } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "owner",
    });
    if (!isOwner) throw new Error("Forbidden");
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row, error } = await supabaseAdmin
      .from("profiles")
      .select("cc")
      .eq("id", data.userId)
      .maybeSingle();
    if (error) throw new Error(error.message);
    return { cc: (row?.cc as string | null) ?? null };
  });

export const getStockTotals = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async () => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("card_stock_movements")
      .select("delta, kind");
    if (error) throw new Error(error.message);
    let card = 0;
    let contract = 0;
    for (const row of (data ?? []) as Array<{ delta: number; kind: string }>) {
      if (row.kind === "card") card += row.delta;
      else if (row.kind === "contract") contract += row.delta;
    }
    return { card_total: card, contract_total: contract };
  });

export const listTeamDirectory = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data: isOwner } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "owner",
    });
    if (!isOwner) throw new Error("Forbidden");

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: rows, error } = await supabaseAdmin.from("profiles").select("id, cc");
    if (error) throw new Error(error.message);

    const emails: Record<string, string> = {};
    let page = 1;
    while (page < 20) {
      const { data, error: e2 } = await supabaseAdmin.auth.admin.listUsers({ page, perPage: 200 });
      if (e2) throw new Error(e2.message);
      for (const u of data.users) if (u.email) emails[u.id] = u.email;
      if (data.users.length < 200) break;
      page += 1;
    }

    return ((rows ?? []) as Array<{ id: string; cc: string | null }>).map((r) => ({
      id: r.id,
      cc: r.cc ?? null,
      email: emails[r.id] ?? null,
    }));
  });

export const sendCardDebtReminder = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { userId: string; missing: number }) => input)
  .handler(async ({ data, context }) => {
    const { data: isOwner } = await context.supabase.rpc("has_role", {
      _user_id: context.userId,
      _role: "owner",
    });
    if (!isOwner) throw new Error("Forbidden");

    const url = process.env["DISCORD_DEBT_WEBHOOK_URL"];
    if (!url) return { ok: false as const, error: "Webhook de avisos não configurado" };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row, error } = await supabaseAdmin
      .from("profiles")
      .select("full_name, discord_id")
      .eq("id", data.userId)
      .maybeSingle();
    if (error) throw new Error(error.message);
    const discordId = (row?.discord_id as string | null)?.trim();
    if (!discordId) return { ok: false as const, error: `${row?.full_name ?? "Vendedor"} ainda não tem ID do Discord no perfil` };

    const content =
      `<@${discordId}> Vais colocar o cartão em falta ou queres que vá comprar por ti ao mercado?\n` +
      `Quantidade em falta: **${data.missing}**`;

    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content, allowed_mentions: { parse: ["users"] } }),
    });
    if (!res.ok) {
      const body = await res.text();
      console.error(`Discord debt webhook failed [${res.status}]: ${body}`);
      return { ok: false as const, error: `Discord ${res.status}` };
    }
    return { ok: true as const };
  });

/**
 * Avisa o(s) owner(s) no Discord quando um vendedor marca taxas como pagas.
 */
export const sendFeePaidNotification = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { sellerId: string; total: number; count: number }) => input)
  .handler(async ({ data }) => {
    const url =
      process.env["DISCORD_DEBT_WEBHOOK_URL"] ||
      process.env["DISCORD_UPDATES_WEBHOOK_URL"] ||
      process.env["DISCORD_WEBHOOK_URL"];
    if (!url) return { ok: false as const, error: "Webhook não configurado" };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: seller } = await supabaseAdmin
      .from("profiles")
      .select("full_name")
      .eq("id", data.sellerId)
      .maybeSingle();

    const { data: owners } = await supabaseAdmin
      .from("user_roles")
      .select("user_id")
      .eq("role", "owner");
    const ownerIds = ((owners ?? []) as Array<{ user_id: string }>).map((o) => o.user_id);
    let mentions = "";
    if (ownerIds.length > 0) {
      const { data: ownerProfiles } = await supabaseAdmin
        .from("profiles")
        .select("discord_id")
        .in("id", ownerIds);
      mentions = ((ownerProfiles ?? []) as Array<{ discord_id: string | null }>)
        .map((p) => p.discord_id?.trim())
        .filter(Boolean)
        .map((id) => `<@${id}>`)
        .join(" ");
    }

    const content =
      `${mentions ? mentions + " " : ""}💸 **Taxa paga**\n` +
      `Vendedor: **${seller?.full_name ?? "Vendedor"}**\n` +
      `Carros: **${data.count}**\n` +
      `Total: **${new Intl.NumberFormat("pt-PT").format(data.total)} €**`;

    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content, allowed_mentions: { parse: ["users"] } }),
    });
    if (!res.ok) {
      const body = await res.text();
      console.error(`Discord fee webhook failed [${res.status}]: ${body}`);
      return { ok: false as const, error: `Discord ${res.status}` };
    }
    return { ok: true as const };
  });
