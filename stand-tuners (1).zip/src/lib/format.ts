export const fmt = (v: number | null | undefined) =>
  new Intl.NumberFormat("pt-PT", { style: "currency", currency: "EUR", maximumFractionDigits: 0 }).format(v ?? 0);

export const OWNERS = new Set(["Pedro Lourenço"]);
