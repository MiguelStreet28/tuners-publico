import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

const SPREADSHEET_ID = "1nK0OU2IqMNDK_aoGyKm3_yDqCJ_OYlx5cSpZ5M4chZc";
const SHEET_NAME = "Los Santos Tuners";

export type VehicleOpKind = "compra" | "venda" | "troca_carros" | "troca_casas";

type RecordPayload = {
  nome: string;
  tipo: VehicleOpKind;
  valor: number;
  vendedorNome: string;
  vendedorId: string;
  compradorNome: string;
  compradorId: string;
  modelo: string;
  matricula: string;
  cont: "Sim" | "Não" | "";
  /** Casas (troca/casas): texto para a coluna N, ex "Casa CP 567". Sem matrícula/modelo. */
  casa?: string;
};


function tipoLabel(t: VehicleOpKind): string {
  return t === "compra" ? "Compra"
    : t === "venda" ? "Venda"
    : t === "troca_carros" ? "Troca/carros"
    : "Troca/casas";
}

function nowStr(): string {
  const parts = new Intl.DateTimeFormat("pt-PT", {
    timeZone: "Europe/Lisbon",
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    hour12: false,
  }).formatToParts(new Date());
  const get = (t: string) => parts.find((p) => p.type === t)?.value ?? "";
  return `${get("day")}/${get("month")}/${get("year")} ${get("hour")}:${get("minute")}`;
}

function buildRow(data: RecordPayload, dateStr: string): (string | number)[] {
  // A Nome | B Data | C Tipo | D Valor | E VendedorNome | F VendedorCC
  // G CompradorNome | H CompradorCC | I Modelo | J Matrícula
  // (K/L NÃO são tocados — pertencem ao script do Discord do utilizador)
  // Casas: o texto vai só para a coluna N (ver writeCasaCells); I/J ficam com o carro.
  return [
    data.nome,
    dateStr,
    tipoLabel(data.tipo),
    data.valor,
    data.vendedorNome,
    data.vendedorId,
    data.compradorNome,
    data.compradorId,
    data.modelo,
    data.matricula,
  ];

}

// Escreve o texto das casas na coluna N (uma célula por linha, sem tocar K/L/M).
async function writeCasaCells(
  headers: Record<string, string>,
  entries: Array<{ row: number; casa: string }>,
) {
  for (const e of entries) {
    const range = `'${SHEET_NAME}'!N${e.row}`;
    const url = `https://connector-gateway.lovable.dev/google_sheets/v4/spreadsheets/${SPREADSHEET_ID}/values/${range}?valueInputOption=USER_ENTERED`;
    const res = await fetchRetry(url, {
      method: "PUT",
      headers,
      body: JSON.stringify({ values: [[e.casa]], range }),
    });
    if (!res.ok) console.error(`Sheets casa (N${e.row}) write failed [${res.status}]: ${await res.text()}`);
  }
}



function gwHeaders() {
  const lovableKey = process.env.LOVABLE_API_KEY;
  const gwKey = process.env.GOOGLE_SHEETS_API_KEY;
  if (!lovableKey || !gwKey) return null;
  return {
    Authorization: `Bearer ${lovableKey}`,
    "X-Connection-Api-Key": gwKey,
    "Content-Type": "application/json",
  };
}

// Retenta pedidos ao Sheets (429/5xx/erros de rede) para os registos não falharem.
async function fetchRetry(url: string, init: RequestInit, attempts = 4): Promise<Response> {
  let last: Response | null = null;
  for (let i = 0; i < attempts; i++) {
    try {
      const res = await fetch(url, init);
      if (res.ok || (res.status < 500 && res.status !== 429)) return res;
      last = res;
    } catch (e) {
      if (i === attempts - 1) throw e;
    }
    await new Promise((r) => setTimeout(r, 400 * Math.pow(2, i)));
  }
  return last as Response;
}

const DEFAULT_START_ROW = 6498; // fallback quando não é passado nada
const DEFAULT_PACK_SIZE = 125;  // fallback do tamanho do pack


const MAX_PACKS_AHEAD = 20; // até quantos packs à frente é que procuramos espaço

// A folha só tem 15 colunas (A–O) e todas estão ocupadas, por isso a "marca
// única" de cada registo é guardada na base de dados (tabela sheet_writes).


/**
 * Procura espaço para `need` linhas seguidas a partir do pack que começa em
 * `startRow`. Se o pack atual estiver cheio (ou não tiver espaço suficiente),
 * avança automaticamente para o pack seguinte — os packs estão separados por
 * uma linha em branco, por isso o pack k começa em startRow + k*(packSize+1).
 * Devolve também o início do pack usado, para o site guardar nas definições.
 */
async function findNextRow(
  headers: Record<string, string>,
  startRow: number,
  packSize: number,
  need = 1,
): Promise<{ row: number; packStart: number } | { error: string }> {
  const span = MAX_PACKS_AHEAD * (packSize + 1);
  const lastRow = startRow + span - 1;
  const range = `'${SHEET_NAME}'!A${startRow}:A${lastRow}`;
  const url = `https://connector-gateway.lovable.dev/google_sheets/v4/spreadsheets/${SPREADSHEET_ID}/values/${range}?majorDimension=ROWS&valueRenderOption=UNFORMATTED_VALUE`;
  const res = await fetchRetry(url, { method: "GET", headers });
  if (!res.ok) {
    const body = await res.text();
    console.error(`Sheets read failed [${res.status}]: ${body}`);
    return { error: `Sheets ${res.status}: ${body.slice(0, 200)}` };
  }
  const json = (await res.json()) as { values?: unknown[][] };
  const rows = json.values ?? [];
  const filled = (idx: number) => {
    const cell = rows[idx]?.[0];
    return cell !== undefined && cell !== null && String(cell).trim() !== "";
  };

  for (let k = 0; k < MAX_PACKS_AHEAD; k++) {
    const packStart = startRow + k * (packSize + 1);
    const base = packStart - startRow;
    let lastFilledOffset = -1;
    for (let i = packSize - 1; i >= 0; i--) {
      if (filled(base + i)) { lastFilledOffset = i; break; }
    }
    const nextOffset = lastFilledOffset + 1;
    if (nextOffset + need <= packSize) {
      return { row: packStart + nextOffset, packStart };
    }
  }
  return { error: `Sem espaço nos próximos ${MAX_PACKS_AHEAD} packs a partir da linha ${startRow}. Atualiza a linha inicial nas configurações.` };
}

/**
 * Lê o Sheets e diz quantas linhas do pack atual já estão preenchidas.
 * Fonte de verdade = a folha (pode ter linhas escritas fora do site).
 */
export const getSheetPackUsage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { startRow?: number; packSize?: number }) => input)
  .handler(async ({ data }) => {
    const headers = gwHeaders();
    if (!headers) return { ok: false as const, error: "Google Sheets connector not configured" };
    const startRow = data.startRow && data.startRow > 0 ? Math.floor(data.startRow) : DEFAULT_START_ROW;
    const packSize = data.packSize && data.packSize > 0 ? Math.floor(data.packSize) : DEFAULT_PACK_SIZE;

    // Lê exatamente o pack configurado (sem saltar para o seguinte), para que
    // um pack cheio mostre packSize/packSize em vez de 0.
    const lastRow = startRow + packSize - 1;
    const range = `'${SHEET_NAME}'!A${startRow}:A${lastRow}`;
    const url = `https://connector-gateway.lovable.dev/google_sheets/v4/spreadsheets/${SPREADSHEET_ID}/values/${range}?majorDimension=ROWS&valueRenderOption=UNFORMATTED_VALUE`;
    const res = await fetchRetry(url, { method: "GET", headers });
    if (!res.ok) {
      const body = await res.text();
      console.error(`Sheets read failed [${res.status}]: ${body}`);
      return { ok: false as const, error: `Sheets ${res.status}: ${body.slice(0, 200)}` };
    }
    const json = (await res.json()) as { values?: unknown[][] };
    const rows = json.values ?? [];
    let lastFilledOffset = -1;
    for (let i = packSize - 1; i >= 0; i--) {
      const cell = rows[i]?.[0];
      if (cell !== undefined && cell !== null && String(cell).trim() !== "") { lastFilledOffset = i; break; }
    }
    const used = Math.min(packSize, lastFilledOffset + 1);
    const full = used >= packSize;
    return {
      ok: true as const,
      packStart: startRow,
      nextRow: full ? null : startRow + used,
      used,
      packSize,
      full,
    };
  });



export const appendVehicleRecordToSheet = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: RecordPayload & { startRow?: number; packSize?: number }) => input)
  .handler(async ({ data }) => {
    const headers = gwHeaders();
    if (!headers) return { ok: false as const, error: "Google Sheets connector not configured" };

    const startRow = data.startRow && data.startRow > 0 ? Math.floor(data.startRow) : DEFAULT_START_ROW;
    const packSize = data.packSize && data.packSize > 0 ? Math.floor(data.packSize) : DEFAULT_PACK_SIZE;
    const found = await findNextRow(headers, startRow, packSize, 1);
    if ("error" in found) return { ok: false as const, error: found.error };
    const next = found.row;


    const row = buildRow(data, nowStr());
    const range = `'${SHEET_NAME}'!A${next}:J${next}`;
    const url = `https://connector-gateway.lovable.dev/google_sheets/v4/spreadsheets/${SPREADSHEET_ID}/values/${range}?valueInputOption=USER_ENTERED`;


    const res = await fetchRetry(url, {
      method: "PUT",
      headers,
      body: JSON.stringify({ values: [row], range }),
    });

    if (!res.ok) {
      const body = await res.text();
      console.error(`Sheets write failed [${res.status}]: ${body}`);
      return { ok: false as const, error: `Sheets ${res.status}: ${body.slice(0, 200)}` };
    }
    if ((data.casa ?? "").trim()) await writeCasaCells(headers, [{ row: next, casa: data.casa!.trim() }]);
    return { ok: true as const, sheetRow: next };
  });

// Escreve N carros (N linhas) de uma só vez, em linhas contíguas.
// Evita releituras entre escritas (o Sheets pode devolver dados em atraso e
// fazer com que dois carros caíssem na mesma linha ou não caíssem de todo).
export const appendVehicleRecordsToSheet = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { rows: RecordPayload[]; startRow?: number; packSize?: number; clientKey?: string }) => input)
  .handler(async ({ data, context }) => {
    const headers = gwHeaders();
    if (!headers) return { ok: false as const, error: "Google Sheets connector not configured" };
    if (!data.rows?.length) return { ok: false as const, error: "Sem linhas para escrever" };

    const startRow = data.startRow && data.startRow > 0 ? Math.floor(data.startRow) : DEFAULT_START_ROW;
    const packSize = data.packSize && data.packSize > 0 ? Math.floor(data.packSize) : DEFAULT_PACK_SIZE;
    const key = (data.clientKey ?? "").trim();

    // Anti-duplicados: cada tentativa traz a mesma marca única. Se essa marca
    // já reservou linhas, reescrevemos exatamente essas linhas em vez de
    // ocupar linhas novas — assim o mesmo registo nunca aparece duas vezes.
    let claimed: number[] | null = null;
    if (key) {
      const { data: existing } = await context.supabase
        .from("sheet_writes")
        .select("rows")
        .eq("client_key", key)
        .maybeSingle();
      const rows = existing?.rows ?? [];
      if (rows.length >= data.rows.length) claimed = rows.slice(0, data.rows.length);
    }

    let next: number;
    let packStart: number;
    if (claimed) {
      next = claimed[0];
      packStart = startRow;
    } else {
      const found = await findNextRow(headers, startRow, packSize, data.rows.length);
      if ("error" in found) return { ok: false as const, error: found.error };
      next = found.row;
      packStart = found.packStart;
      if (key) {
        const reserved = data.rows.map((_, i) => found.row + i);
        const { error: claimErr } = await context.supabase
          .from("sheet_writes")
          .insert({ client_key: key, rows: reserved, created_by: context.userId });
        if (claimErr) {
          // Alguém (ou outra tentativa) já reservou esta marca: usa as linhas dessa reserva.
          const { data: again } = await context.supabase
            .from("sheet_writes")
            .select("rows")
            .eq("client_key", key)
            .maybeSingle();
          const rows = again?.rows ?? [];
          if (rows.length >= data.rows.length) {
            claimed = rows.slice(0, data.rows.length);
            next = claimed[0];
          }
        }
      }
    }

    const last = next + data.rows.length - 1;


    const dateStr = nowStr();
    const values = data.rows.map((r) => buildRow(r, dateStr));
    const range = `'${SHEET_NAME}'!A${next}:J${last}`;
    const url = `https://connector-gateway.lovable.dev/google_sheets/v4/spreadsheets/${SPREADSHEET_ID}/values/${range}?valueInputOption=USER_ENTERED`;

    const res = await fetchRetry(url, {
      method: "PUT",
      headers,
      body: JSON.stringify({ values, range }),
    });
    if (!res.ok) {
      const body = await res.text();
      console.error(`Sheets batch write failed [${res.status}]: ${body}`);
      return { ok: false as const, error: `Sheets ${res.status}: ${body.slice(0, 200)}` };
    }

    // Verificação forte: relê A:J e confirma o conteúdo de todas as linhas.
    // O Sheets pode demorar alguns instantes a refletir a escrita, por isso
    // repetimos a leitura antes de declarar falha.
    const vRange = `'${SHEET_NAME}'!A${next}:J${last}`;
    const vUrl = `https://connector-gateway.lovable.dev/google_sheets/v4/spreadsheets/${SPREADSHEET_ID}/values/${vRange}?majorDimension=ROWS&valueRenderOption=UNFORMATTED_VALUE`;
    let confirmed = false;
    let verifyError = "";
    for (let attempt = 0; attempt < 4; attempt++) {
      if (attempt > 0) await new Promise((resolve) => setTimeout(resolve, 500 * attempt));
      const vRes = await fetchRetry(vUrl, { method: "GET", headers });
      if (!vRes.ok) {
        verifyError = `verificação ${vRes.status}: ${(await vRes.text()).slice(0, 120)}`;
        continue;
      }
      const vJson = (await vRes.json()) as { values?: unknown[][] };
      const actual = vJson.values ?? [];
      // B (data) e D (valor) podem ser convertidas pelo Sheets para valores
      // internos/formatados. Confirmamos as restantes colunas identificadoras.
      const stableColumns = [0, 2, 4, 5, 6, 7, 8, 9];
      confirmed = values.every((expected, rowIndex) =>
        stableColumns.every((colIndex) =>
          String(actual[rowIndex]?.[colIndex] ?? "").trim() === String(expected[colIndex] ?? "").trim()
        )
      );
      if (confirmed) break;
      verifyError = `${actual.length}/${values.length} linhas devolvidas ou conteúdo diferente`;
    }
    if (!confirmed) {
      // A reserva fica guardada: se o utilizador tentar outra vez, o registo
      // volta a ser escrito exatamente nas mesmas linhas, sem duplicar.
      return { ok: false as const, error: `Sheets não confirmou A${next}:J${last} (${verifyError}). O registo não foi criado no site.` };
    }

    const rowsWritten: number[] = data.rows.map((_, i) => next + i);
    await writeCasaCells(
      headers,
      data.rows
        .map((r, i) => ({ row: next + i, casa: (r.casa ?? "").trim() }))
        .filter((e) => e.casa),
    );
    return { ok: true as const, rows: rowsWritten, sheetRow: next, packStart, duplicate: claimed !== null };

  });


export const updateVehicleRecordInSheet = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: RecordPayload & { sheetRow: number; dateStr?: string }) => input)
  .handler(async ({ data }) => {
    const headers = gwHeaders();
    if (!headers) return { ok: false as const, error: "Google Sheets connector not configured" };

    const row = buildRow(data, data.dateStr || nowStr());
    const range = `'${SHEET_NAME}'!A${data.sheetRow}:J${data.sheetRow}`;
    const url = `https://connector-gateway.lovable.dev/google_sheets/v4/spreadsheets/${SPREADSHEET_ID}/values/${range}?valueInputOption=USER_ENTERED`;


    const res = await fetchRetry(url, {
      method: "PUT",
      headers,
      body: JSON.stringify({ values: [row], range }),
    });

    if (!res.ok) {
      const body = await res.text();
      console.error(`Sheets update failed [${res.status}]: ${body}`);
      return { ok: false as const, error: `Sheets ${res.status}: ${body.slice(0, 200)}` };
    }
    await writeCasaCells(headers, [{ row: data.sheetRow, casa: (data.casa ?? "").trim() }]);
    return { ok: true as const };
  });

export const clearVehicleRecordInSheet = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { sheetRow: number }) => input)
  .handler(async ({ data }) => {
    const headers = gwHeaders();
    if (!headers) return { ok: false as const, error: "Google Sheets connector not configured" };
    const range = `'${SHEET_NAME}'!A${data.sheetRow}:J${data.sheetRow}`;
    const url = `https://connector-gateway.lovable.dev/google_sheets/v4/spreadsheets/${SPREADSHEET_ID}/values/${range}:clear`;
    const res = await fetchRetry(url, { method: "POST", headers, body: "{}" });
    if (!res.ok) {
      const body = await res.text();
      console.error(`Sheets clear failed [${res.status}]: ${body}`);
      return { ok: false as const, error: `Sheets ${res.status}: ${body.slice(0, 200)}` };
    }
    await writeCasaCells(headers, [{ row: data.sheetRow, casa: "" }]);
    return { ok: true as const };
  });

export const getDiscordWebhookUrl = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input?: { kind?: "carros" | "motas" }) => input ?? {})
  .handler(async ({ data }) => {
    const isMota = data?.kind === "motas";
    const url = isMota ? process.env.DISCORD_MOTAS_WEBHOOK_URL : process.env.DISCORD_WEBHOOK_URL;
    if (!url) return { ok: false as const, error: `${isMota ? "DISCORD_MOTAS_WEBHOOK_URL" : "DISCORD_WEBHOOK_URL"} not configured` };
    return { ok: true as const, url };
  });

export const markDiscordSentInSheet = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: { sheetRow: number }) => input)
  .handler(async ({ data }) => {
    if (!data.sheetRow) return { ok: false as const, error: "sheetRow missing" };
    const headers = gwHeaders();
    if (!headers) return { ok: false as const, error: "Google Sheets not connected" };
    const range = `'${SHEET_NAME}'!L${data.sheetRow}`;
    const sUrl = `https://connector-gateway.lovable.dev/google_sheets/v4/spreadsheets/${SPREADSHEET_ID}/values/${range}?valueInputOption=USER_ENTERED`;
    const sRes = await fetchRetry(sUrl, {
      method: "PUT",
      headers,
      body: JSON.stringify({ values: [["ENVIADO"]], range }),
    });
    if (!sRes.ok) {
      const body = await sRes.text();
      console.error(`Sheets ENVIADO write failed [${sRes.status}]: ${body}`);
      return { ok: false as const, error: `Sheets ${sRes.status}` };
    }
    return { ok: true as const };
  });

// Retro-compat (não usar do UI): sujeito a Cloudflare 1015 no worker.
export const sendDiscordSaleNotification = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((input: {
    vendedor: string; nome: string; cc: string; marca: string; matricula: string;
    sheetRow?: number;
  }) => input)
  .handler(async ({ data }) => {
    const url = process.env.DISCORD_WEBHOOK_URL;
    if (!url) return { ok: false as const, error: "DISCORD_WEBHOOK_URL not configured" };
    const content =
      `Vendedor: **${data.vendedor}**\n` +
      `Nome: **${data.nome}**\n` +
      `CC: **${data.cc}**\n` +
      `Marca: **${data.marca}**\n` +
      `Matrícula: **${data.matricula}**`;
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content }),
    });
    if (!res.ok) {
      const body = await res.text();
      console.error(`Discord webhook failed [${res.status}]: ${body}`);
      return { ok: false as const, error: `Discord ${res.status}` };
    }
    return { ok: true as const };
  });
