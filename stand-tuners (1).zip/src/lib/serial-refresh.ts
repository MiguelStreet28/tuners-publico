/** Merge overlapping refreshes while keeping a trailing read for changes in flight. */
export function createSerialRefresh(refresh: () => Promise<void>): () => Promise<void> {
  let running: Promise<void> | undefined;
  let requested = false;

  return () => {
    requested = true;
    if (running) return running;
    running = Promise.resolve().then(async () => {
      try {
        while (requested) {
          requested = false;
          await refresh();
        }
      } finally {
        running = undefined;
      }
    });
    return running;
  };
}