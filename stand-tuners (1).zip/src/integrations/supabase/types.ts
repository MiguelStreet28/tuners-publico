export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      app_settings: {
        Row: {
          key: string
          updated_at: string
          updated_by: string | null
          value_int: number | null
        }
        Insert: {
          key: string
          updated_at?: string
          updated_by?: string | null
          value_int?: number | null
        }
        Update: {
          key?: string
          updated_at?: string
          updated_by?: string | null
          value_int?: number | null
        }
        Relationships: []
      }
      audit_logs: {
        Row: {
          action: string
          actor_id: string
          actor_name: string | null
          created_at: string
          details: Json | null
          entity: string
          entity_id: string | null
          id: string
        }
        Insert: {
          action: string
          actor_id: string
          actor_name?: string | null
          created_at?: string
          details?: Json | null
          entity: string
          entity_id?: string | null
          id?: string
        }
        Update: {
          action?: string
          actor_id?: string
          actor_name?: string | null
          created_at?: string
          details?: Json | null
          entity?: string
          entity_id?: string | null
          id?: string
        }
        Relationships: []
      }
      card_stock_movements: {
        Row: {
          created_at: string
          created_by: string
          delta: number
          id: string
          kind: string
          notes: string | null
          reason: string
        }
        Insert: {
          created_at?: string
          created_by: string
          delta: number
          id?: string
          kind?: string
          notes?: string | null
          reason?: string
        }
        Update: {
          created_at?: string
          created_by?: string
          delta?: number
          id?: string
          kind?: string
          notes?: string | null
          reason?: string
        }
        Relationships: []
      }
      contracts: {
        Row: {
          card_paid: boolean
          card_value: number
          created_at: string
          id: string
          notes: string | null
          quantity: number
          record_id: string | null
          seller_id: string
        }
        Insert: {
          card_paid?: boolean
          card_value?: number
          created_at?: string
          id?: string
          notes?: string | null
          quantity?: number
          record_id?: string | null
          seller_id: string
        }
        Update: {
          card_paid?: boolean
          card_value?: number
          created_at?: string
          id?: string
          notes?: string | null
          quantity?: number
          record_id?: string | null
          seller_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "contracts_record_id_fkey"
            columns: ["record_id"]
            isOneToOne: false
            referencedRelation: "vehicle_records"
            referencedColumns: ["id"]
          },
        ]
      }
      fee_manual_costs: {
        Row: {
          cost: number
          cost_override: number | null
          created_at: string
          created_by: string | null
          cycle: number
          id: string
          matricula: string
          record_id: string | null
          sale: number | null
          sale_override: number | null
          seller_id: string
          updated_at: string
        }
        Insert: {
          cost?: number
          cost_override?: number | null
          created_at?: string
          created_by?: string | null
          cycle?: number
          id?: string
          matricula: string
          record_id?: string | null
          sale?: number | null
          sale_override?: number | null
          seller_id: string
          updated_at?: string
        }
        Update: {
          cost?: number
          cost_override?: number | null
          created_at?: string
          created_by?: string | null
          cycle?: number
          id?: string
          matricula?: string
          record_id?: string | null
          sale?: number | null
          sale_override?: number | null
          seller_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      fee_payments: {
        Row: {
          created_at: string
          cycle: number
          fee: number
          id: string
          marked_by: string | null
          matricula: string
          profit: number
          record_id: string | null
          seller_id: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          cycle?: number
          fee?: number
          id?: string
          marked_by?: string | null
          matricula: string
          profit?: number
          record_id?: string | null
          seller_id: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          cycle?: number
          fee?: number
          id?: string
          marked_by?: string | null
          matricula?: string
          profit?: number
          record_id?: string | null
          seller_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      notifications: {
        Row: {
          created_at: string
          id: string
          message: string
          read: boolean
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          message: string
          read?: boolean
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          message?: string
          read?: boolean
          user_id?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          active: boolean
          approved: boolean
          cc: string | null
          created_at: string
          discord_id: string | null
          fee_mode: boolean
          full_name: string
          id: string
          left_at: string | null
        }
        Insert: {
          active?: boolean
          approved?: boolean
          cc?: string | null
          created_at?: string
          discord_id?: string | null
          fee_mode?: boolean
          full_name: string
          id: string
          left_at?: string | null
        }
        Update: {
          active?: boolean
          approved?: boolean
          cc?: string | null
          created_at?: string
          discord_id?: string | null
          fee_mode?: boolean
          full_name?: string
          id?: string
          left_at?: string | null
        }
        Relationships: []
      }
      sheet_writes: {
        Row: {
          client_key: string
          created_at: string
          created_by: string | null
          rows: number[]
          updated_at: string
        }
        Insert: {
          client_key: string
          created_at?: string
          created_by?: string | null
          rows?: number[]
          updated_at?: string
        }
        Update: {
          client_key?: string
          created_at?: string
          created_by?: string | null
          rows?: number[]
          updated_at?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      user_tab_denies: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          tab: string
          user_id: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          tab: string
          user_id: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          tab?: string
          user_id?: string
        }
        Relationships: []
      }
      vehicle_records: {
        Row: {
          casa_in: boolean
          casa_out: boolean
          comprador: string | null
          contraparte: string | null
          contraparte_id: string | null
          contraparte_nome: string | null
          created_at: string
          extra_in: Json
          extra_out: Json
          id: string
          is_mota: boolean
          matricula: string
          matricula_entrada: string | null
          modelo: string | null
          modelo_entrada: string | null
          notes: string | null
          op: Database["public"]["Enums"]["vehicle_op"]
          partner_id: string | null
          seller_id: string
          sheet_extra_rows: number[]
          sheet_row: number | null
          valor: number
        }
        Insert: {
          casa_in?: boolean
          casa_out?: boolean
          comprador?: string | null
          contraparte?: string | null
          contraparte_id?: string | null
          contraparte_nome?: string | null
          created_at?: string
          extra_in?: Json
          extra_out?: Json
          id?: string
          is_mota?: boolean
          matricula: string
          matricula_entrada?: string | null
          modelo?: string | null
          modelo_entrada?: string | null
          notes?: string | null
          op: Database["public"]["Enums"]["vehicle_op"]
          partner_id?: string | null
          seller_id: string
          sheet_extra_rows?: number[]
          sheet_row?: number | null
          valor: number
        }
        Update: {
          casa_in?: boolean
          casa_out?: boolean
          comprador?: string | null
          contraparte?: string | null
          contraparte_id?: string | null
          contraparte_nome?: string | null
          created_at?: string
          extra_in?: Json
          extra_out?: Json
          id?: string
          is_mota?: boolean
          matricula?: string
          matricula_entrada?: string | null
          modelo?: string | null
          modelo_entrada?: string | null
          notes?: string | null
          op?: Database["public"]["Enums"]["vehicle_op"]
          partner_id?: string | null
          seller_id?: string
          sheet_extra_rows?: number[]
          sheet_row?: number | null
          valor?: number
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      can_write_pack_settings: { Args: { _user_id: string }; Returns: boolean }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_approved: { Args: { _user_id: string }; Returns: boolean }
    }
    Enums: {
      app_role: "owner" | "seller"
      vehicle_op: "compra" | "venda" | "troca" | "troca_carros" | "troca_casas"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["owner", "seller"],
      vehicle_op: ["compra", "venda", "troca", "troca_carros", "troca_casas"],
    },
  },
} as const
