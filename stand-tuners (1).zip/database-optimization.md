# Database optimization — 25 October 2026

## Recorded usage baseline

Project recording window: 12 October 2026 00:00 UTC to 25 October 2026 14:02 UTC (last day partial; recording can lag activity).

| Item | Recorded quantity | Requested credits |
| --- | --- | --- |
| Pico database compute | 63.77 instance-hours | 4.937022396 |
| Worker days | 28 worker-days | 0.280000000 |
| Worker requests | 290 requests | 0.000435000 |
| Network egress | 0.21030013 GB | 0.094635160 |
| Build | Quantity unknown | 4.600000000 |

Runtime subtotal: **5.312092556 requested credits**. Total including building: 9.912092556. No database-storage item was returned; this does not establish zero storage usage.

Current Pico quote: 0.0774192 credits per active instance-hour. Continuous-running quotes are not measured usage. Faster SQL does not lower this hourly rate.

## Measured load

- Database and pool healthy; memory 58%, disk 16%, database 16.2 MB, connections 21/60, pool clients 1/200. No recent exhaustion alerts. This snapshot does not establish sustained sizing headroom.
- Statement statistics reset: 27 September 2026 09:52 UTC. These cumulative statistics are a different window from the credit baseline and measure elapsed query execution, not CPU consumption.
- Largest accumulated query times: vehicle records 232.5 seconds / 2,455 calls; audit logs 228.3 seconds / 1,268 calls; contracts 223.7 seconds / 2,513 calls; stock movements 169.4 seconds / 2,507 calls.
- Existing user_roles index supports role lookup, but its 12 million cumulative index scans support reducing repeated viewer-role evaluations.
- Exact counts: 1,365 vehicle records, 1,512 contracts, 1,115 stock movements. Approximate live-row statistics were inaccurate for some tables; they were not used to remove indexes or data.

## Applied changes

1. Four busiest dashboard SELECT policies now evaluate viewer-only role checks via scalar subqueries. Existing owner/self/approved predicates, policy roles, write policies and grants are unchanged.
2. Added descending created-at indexes for audit logs, vehicle records, contracts and stock movements, matching the measured ordering queries. Each adds small write/storage overhead; no existing index was removed.
3. Dashboard full refreshes share one in-flight read, with one trailing read when changes arrive during it. No artificial delay, polling or cache-freshness change. All subscribed events remain supported.
4. The owner email map reuses the already-authorized team-directory response instead of scanning Auth users a second time per refresh.
5. Contract reads select only consumed fields. Paged reads also order by ID to make equal-timestamp page boundaries deterministic; totals still read every existing page.

## Validation

- Authenticated read measurements: five calls per table, identical limit/selection/order before and after database changes. End-to-end medians: audit 278.68 → 260.72 ms; records 287.91 → 233.12 ms; contracts 264.34 → 214.57 ms; stock 233.32 → 185.52 ms. These small samples include network variance, not sustained performance guarantees.
- Audit EXPLAIN ANALYZE: sequential scan + sort (107 shared buffers, 45.487 ms) → indexed scan (26 shared buffers, 1.148 ms). Bounded probes exclude authenticated RLS because the diagnostic role cannot execute the role helper. Authenticated HTTP reads independently succeeded.
- Before/after audit and record ID digests matched. Contract and stock ordering changed among equal timestamps after index creation; explicit ID ordering now prevents unstable pagination boundaries.
- Preview verification under the requesting owner's session: records and profit totals rendered, all 13 database responses returned 200, no browser runtime errors.
- Refresh tests cover synchronous burst coalescing, trailing reads without overlap and recovery after failure.

## Scheduled work and limits

- No pg_cron/pgmq installation or schedule tables found; no recurring polling loop in inspected app, auth, admin or Sheets modules. Managed HTTP-schedule inventory/history tools were unavailable, so externally configured schedules remain unverified; none was disabled.
- Only notifications and tab-denies are currently in the public realtime publication. Other registered listeners were retained rather than enabling new traffic or silently changing behavior.
- No data deletion, retention change, manual pause, resize, new polling, Sheets write change or server aggregate introduced.
- Database compute dominates measured runtime requests. No smaller tier was established from sustained measurements; no resize recommended from one snapshot.
- Reduced billed instance-hours, network usage, requested credits and deductions are **not yet measured**. Compare representative traffic and subsequent recorded usage after publishing. Larger historical reads remain necessary for current cross-record profit/stock calculations; server-side aggregation is a future design change, not silently substituted here.