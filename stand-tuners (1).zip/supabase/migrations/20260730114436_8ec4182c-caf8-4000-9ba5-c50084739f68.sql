-- Contratos: leitura para toda a equipa aprovada (dashboard de cartão em dívida)
DROP POLICY IF EXISTS "owner or self read contract" ON public.contracts;
CREATE POLICY "approved team read contract"
ON public.contracts FOR SELECT TO authenticated
USING (
  auth.uid() = seller_id
  OR public.has_role(auth.uid(), 'owner'::app_role)
  OR EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.approved = true)
);

-- Stock: histórico visível a toda a equipa aprovada (só leitura)
DROP POLICY IF EXISTS "stock readable by owner" ON public.card_stock_movements;
CREATE POLICY "approved team read stock"
ON public.card_stock_movements FOR SELECT TO authenticated
USING (
  public.has_role(auth.uid(), 'owner'::app_role)
  OR EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.approved = true)
);