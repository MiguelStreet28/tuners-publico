
-- Replace broad team-read policy with one that excludes CC by splitting into two policies
DROP POLICY IF EXISTS "profiles team read non sensitive" ON public.profiles;
DROP POLICY IF EXISTS "profiles read own or owner full" ON public.profiles;
DROP POLICY IF EXISTS "profiles read team safe columns" ON public.profiles;

-- Revoke everything and re-grant only safe columns to authenticated
REVOKE ALL ON public.profiles FROM authenticated;
GRANT SELECT (id, full_name, approved, created_at) ON public.profiles TO authenticated;
GRANT INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;

-- Team can read rows (column grants limit which columns they actually see)
CREATE POLICY "profiles read team safe columns"
ON public.profiles FOR SELECT TO authenticated
USING (true);

-- Owner or self can read all columns including cc (column-level SELECT for cc)
GRANT SELECT (cc) ON public.profiles TO authenticated;
-- Note: RLS row filter still applies; combined with app-side query for cc via server fn.
-- To ensure cc column is only accessible when self or owner, drop that grant and rely on server function.
REVOKE SELECT (cc) ON public.profiles FROM authenticated;

-- Card stock movements: allow owner to update
CREATE POLICY "owners update stock movement"
ON public.card_stock_movements FOR UPDATE TO authenticated
USING (public.has_role(auth.uid(), 'owner'::app_role))
WITH CHECK (public.has_role(auth.uid(), 'owner'::app_role));
