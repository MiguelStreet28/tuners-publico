
-- 1. Tighten has_role function grants
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated, service_role;

-- 2. Profiles: hide cc column from other users via column-level grants
DROP POLICY IF EXISTS "profiles readable by authenticated" ON public.profiles;
CREATE POLICY "profiles readable by authenticated" ON public.profiles
  FOR SELECT TO authenticated USING (true);

REVOKE SELECT ON public.profiles FROM authenticated;
GRANT SELECT (id, full_name, created_at, approved) ON public.profiles TO authenticated;
GRANT INSERT, UPDATE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;

-- Helper for self/owner to read their own cc
CREATE OR REPLACE FUNCTION public.get_my_cc()
RETURNS text
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT cc FROM public.profiles WHERE id = auth.uid()
$$;
REVOKE EXECUTE ON FUNCTION public.get_my_cc() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.get_my_cc() TO authenticated;

-- 3. Contracts: restrict SELECT to owner-of-row or site owner
DROP POLICY IF EXISTS "contracts readable by all authenticated" ON public.contracts;
CREATE POLICY "contracts readable by seller or owner" ON public.contracts
  FOR SELECT TO authenticated
  USING (auth.uid() = seller_id OR public.has_role(auth.uid(), 'owner'));

-- 4. Vehicle records: restrict SELECT to seller or site owner
DROP POLICY IF EXISTS "records readable by all authenticated" ON public.vehicle_records;
CREATE POLICY "records readable by seller or owner" ON public.vehicle_records
  FOR SELECT TO authenticated
  USING (auth.uid() = seller_id OR public.has_role(auth.uid(), 'owner'));

-- 5. Card stock movements: restrict SELECT to owners only
DROP POLICY IF EXISTS "stock readable by authenticated" ON public.card_stock_movements;
CREATE POLICY "stock readable by owners" ON public.card_stock_movements
  FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'owner'));

-- 6. User roles: add explicit owner-only write policies (previously fully denied)
CREATE POLICY "owners manage user roles insert" ON public.user_roles
  FOR INSERT TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'owner'));
CREATE POLICY "owners manage user roles update" ON public.user_roles
  FOR UPDATE TO authenticated
  USING (public.has_role(auth.uid(), 'owner'))
  WITH CHECK (public.has_role(auth.uid(), 'owner'));
CREATE POLICY "owners manage user roles delete" ON public.user_roles
  FOR DELETE TO authenticated
  USING (public.has_role(auth.uid(), 'owner'));
