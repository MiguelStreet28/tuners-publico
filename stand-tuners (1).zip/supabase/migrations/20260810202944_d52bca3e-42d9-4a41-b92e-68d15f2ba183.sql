ALTER TABLE public.vehicle_records
  ADD COLUMN IF NOT EXISTS is_mota boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS casa_out boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS casa_in boolean NOT NULL DEFAULT false;