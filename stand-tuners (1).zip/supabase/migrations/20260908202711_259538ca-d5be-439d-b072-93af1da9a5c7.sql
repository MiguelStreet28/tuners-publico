CREATE TABLE public.sheet_writes (
  client_key text PRIMARY KEY,
  rows integer[] NOT NULL DEFAULT '{}',
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE ON public.sheet_writes TO authenticated;
GRANT ALL ON public.sheet_writes TO service_role;
ALTER TABLE public.sheet_writes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "sheet writes read auth" ON public.sheet_writes FOR SELECT TO authenticated USING (true);
CREATE POLICY "sheet writes insert auth" ON public.sheet_writes FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "sheet writes update auth" ON public.sheet_writes FOR UPDATE TO authenticated USING (true) WITH CHECK (true);
CREATE TRIGGER sheet_writes_set_updated_at BEFORE UPDATE ON public.sheet_writes FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();