DO $$ BEGIN
  CREATE POLICY "owner update" ON public.user_tab_denies
    FOR UPDATE TO authenticated
    USING (public.has_role(auth.uid(), 'owner'::app_role))
    WITH CHECK (public.has_role(auth.uid(), 'owner'::app_role));
EXCEPTION WHEN duplicate_object THEN NULL; END $$;

DO $$ BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE public.user_tab_denies;
EXCEPTION WHEN duplicate_object THEN NULL; END $$;