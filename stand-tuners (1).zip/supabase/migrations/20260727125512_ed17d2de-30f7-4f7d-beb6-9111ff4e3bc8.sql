CREATE OR REPLACE FUNCTION public.handle_new_user()
 RETURNS trigger
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  v_name text;
BEGIN
  v_name := COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email);
  INSERT INTO public.profiles (id, full_name, approved)
  VALUES (NEW.id, v_name, v_name = 'Pedro Lourenço');
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, CASE WHEN v_name = 'Pedro Lourenço' THEN 'owner'::app_role ELSE 'seller'::app_role END);
  RETURN NEW;
END; $function$;