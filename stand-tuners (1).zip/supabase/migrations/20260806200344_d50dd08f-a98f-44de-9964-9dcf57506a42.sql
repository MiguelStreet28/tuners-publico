ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS active boolean NOT NULL DEFAULT true,
  ADD COLUMN IF NOT EXISTS left_at timestamptz;
GRANT SELECT (id, full_name, approved, active, left_at) ON public.profiles TO authenticated;