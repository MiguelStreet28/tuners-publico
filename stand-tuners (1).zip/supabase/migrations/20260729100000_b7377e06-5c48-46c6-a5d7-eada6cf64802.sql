ALTER TABLE public.vehicle_records
  ADD COLUMN IF NOT EXISTS extra_out jsonb NOT NULL DEFAULT '[]'::jsonb,
  ADD COLUMN IF NOT EXISTS extra_in  jsonb NOT NULL DEFAULT '[]'::jsonb;