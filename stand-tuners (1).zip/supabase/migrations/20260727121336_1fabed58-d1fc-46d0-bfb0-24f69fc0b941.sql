
-- Roll back the two "security definer view" definitions
DROP VIEW IF EXISTS public.profiles_public;
DROP VIEW IF EXISTS public.stock_totals;

-- Profiles: keep team-wide read on safe columns via column-level grants
DROP POLICY IF EXISTS "profiles select own or owner" ON public.profiles;
CREATE POLICY "profiles select safe columns for team"
  ON public.profiles FOR SELECT
  TO authenticated
  USING (true);

REVOKE SELECT ON public.profiles FROM authenticated;
GRANT SELECT (id, full_name, approved, created_at) ON public.profiles TO authenticated;
GRANT SELECT (cc) ON public.profiles TO service_role;

-- Drop the client-facing SECURITY DEFINER function; own CC is served via server function
DROP FUNCTION IF EXISTS public.get_my_cc();
