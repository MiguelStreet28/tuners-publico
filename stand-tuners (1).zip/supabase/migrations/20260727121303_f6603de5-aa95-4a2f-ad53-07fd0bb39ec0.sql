
-- 1) profiles: restrict base SELECT to own row or owner; expose safe columns via view
DROP POLICY IF EXISTS "profiles readable by authenticated" ON public.profiles;
CREATE POLICY "profiles select own or owner"
  ON public.profiles FOR SELECT
  TO authenticated
  USING (id = auth.uid() OR public.has_role(auth.uid(), 'owner'));

DROP POLICY IF EXISTS "pedro can update any profile" ON public.profiles;
CREATE POLICY "owners can update any profile"
  ON public.profiles FOR UPDATE
  TO authenticated
  USING (public.has_role(auth.uid(), 'owner'))
  WITH CHECK (public.has_role(auth.uid(), 'owner'));

CREATE OR REPLACE VIEW public.profiles_public AS
  SELECT id, full_name, approved FROM public.profiles;
ALTER VIEW public.profiles_public SET (security_invoker = off);
GRANT SELECT ON public.profiles_public TO authenticated;

-- 2) user_roles: only own row via RLS (owners use admin/service role for cross-user reads)
DROP POLICY IF EXISTS "roles readable by authenticated" ON public.user_roles;
CREATE POLICY "roles select own"
  ON public.user_roles FOR SELECT
  TO authenticated
  USING (user_id = auth.uid());

-- 3) card_stock_movements: restrict SELECT to owners; expose aggregate view
DROP POLICY IF EXISTS "stock readable by authenticated" ON public.card_stock_movements;
CREATE POLICY "stock readable by owner"
  ON public.card_stock_movements FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'owner'));

CREATE OR REPLACE VIEW public.stock_totals AS
  SELECT
    COALESCE(SUM(delta) FILTER (WHERE kind = 'card'), 0)::bigint     AS card_total,
    COALESCE(SUM(delta) FILTER (WHERE kind = 'contract'), 0)::bigint AS contract_total
  FROM public.card_stock_movements;
ALTER VIEW public.stock_totals SET (security_invoker = off);
GRANT SELECT ON public.stock_totals TO authenticated;

-- 4) Convert SECURITY DEFINER functions callable by clients to SECURITY INVOKER
CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

CREATE OR REPLACE FUNCTION public.get_my_cc()
RETURNS text
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public
AS $$
  SELECT cc FROM public.profiles WHERE id = auth.uid()
$$;
