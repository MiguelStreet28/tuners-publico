DROP POLICY IF EXISTS "notifications_insert_any" ON public.notifications;

CREATE POLICY "notifications_insert_self_or_owner_target"
ON public.notifications FOR INSERT TO authenticated
WITH CHECK (
  user_id = auth.uid()
  OR public.has_role(user_id, 'owner'::app_role)
);

CREATE POLICY "notifications_delete_own"
ON public.notifications FOR DELETE TO authenticated
USING (user_id = auth.uid());

GRANT SELECT, INSERT, UPDATE, DELETE ON public.notifications TO authenticated;
GRANT ALL ON public.notifications TO service_role;