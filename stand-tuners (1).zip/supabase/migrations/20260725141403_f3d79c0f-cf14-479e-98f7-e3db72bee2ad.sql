
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS cc TEXT;
ALTER TYPE public.vehicle_op ADD VALUE IF NOT EXISTS 'troca_carros';
ALTER TYPE public.vehicle_op ADD VALUE IF NOT EXISTS 'troca_casas';
