ALTER TABLE public.contracts
ADD COLUMN IF NOT EXISTS record_id uuid REFERENCES public.vehicle_records(id) ON DELETE CASCADE;

CREATE INDEX IF NOT EXISTS contracts_record_id_idx ON public.contracts(record_id);

UPDATE public.contracts c
SET record_id = r.id
FROM public.vehicle_records r
WHERE c.record_id IS NULL
  AND c.seller_id = r.seller_id
  AND upper(c.notes) LIKE ('REGISTO ' || upper(r.matricula) || '%')
  AND r.id = (
    SELECT r2.id
    FROM public.vehicle_records r2
    WHERE r2.seller_id = c.seller_id
      AND upper(c.notes) LIKE ('REGISTO ' || upper(r2.matricula) || '%')
    ORDER BY abs(extract(epoch FROM (r2.created_at - c.created_at)))
    LIMIT 1
  );

DELETE FROM public.vehicle_records
WHERE id = 'c0412a57-af0d-47af-ab95-6a348cc22b60';

DELETE FROM public.contracts
WHERE id IN (
  '8abe344c-ba66-4149-a94f-6d63a75cd723',
  'bd5393f1-c80e-41de-a401-bc3eda9f90e4'
);