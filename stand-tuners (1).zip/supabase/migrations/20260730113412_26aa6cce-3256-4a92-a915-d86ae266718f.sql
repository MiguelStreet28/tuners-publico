REVOKE ALL ON FUNCTION public.is_approved(uuid) FROM PUBLIC;
REVOKE ALL ON FUNCTION public.is_approved(uuid) FROM anon;
REVOKE ALL ON FUNCTION public.is_approved(uuid) FROM authenticated;
GRANT EXECUTE ON FUNCTION public.is_approved(uuid) TO service_role;