
-- 1. Stock: adicionar kind
ALTER TABLE public.card_stock_movements
  ADD COLUMN IF NOT EXISTS kind text NOT NULL DEFAULT 'card';
ALTER TABLE public.card_stock_movements
  DROP CONSTRAINT IF EXISTS card_stock_movements_kind_check;
ALTER TABLE public.card_stock_movements
  ADD CONSTRAINT card_stock_movements_kind_check CHECK (kind IN ('card','contract'));

-- Torna leitura pública a todos os autenticados (só owners mexem)
DROP POLICY IF EXISTS "stock readable by owners" ON public.card_stock_movements;
CREATE POLICY "stock readable by authenticated"
  ON public.card_stock_movements FOR SELECT
  TO authenticated
  USING (true);

-- Permitir inserts automáticos por qualquer vendedor (auto_contract) + owners manuais
DROP POLICY IF EXISTS "owners insert manual stock movement" ON public.card_stock_movements;
CREATE POLICY "insert stock movement"
  ON public.card_stock_movements FOR INSERT
  TO authenticated
  WITH CHECK (
    created_by = auth.uid()
    AND (
      public.has_role(auth.uid(), 'owner'::app_role)
      OR reason IN ('auto_contract','auto_card_paid')
    )
  );

-- 2. Audit logs
CREATE TABLE IF NOT EXISTS public.audit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id uuid NOT NULL,
  actor_name text,
  action text NOT NULL,
  entity text NOT NULL,
  entity_id text,
  details jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT ON public.audit_logs TO authenticated;
GRANT ALL ON public.audit_logs TO service_role;

ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "authenticated insert own audit"
  ON public.audit_logs FOR INSERT
  TO authenticated
  WITH CHECK (actor_id = auth.uid());

CREATE POLICY "owners read all audit"
  ON public.audit_logs FOR SELECT
  TO authenticated
  USING (public.has_role(auth.uid(), 'owner'::app_role));
