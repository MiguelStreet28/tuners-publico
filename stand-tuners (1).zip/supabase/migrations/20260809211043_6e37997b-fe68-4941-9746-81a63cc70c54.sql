ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS discord_id text;
GRANT SELECT (discord_id), UPDATE (discord_id) ON public.profiles TO authenticated;