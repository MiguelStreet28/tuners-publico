
DROP POLICY IF EXISTS "contracts readable by team" ON public.contracts;
CREATE POLICY "owner or self read contract" ON public.contracts
  FOR SELECT TO authenticated
  USING ((auth.uid() = seller_id) OR public.has_role(auth.uid(), 'owner'::app_role));

DROP POLICY IF EXISTS "records readable by team" ON public.vehicle_records;
CREATE POLICY "owner or self read record" ON public.vehicle_records
  FOR SELECT TO authenticated
  USING ((auth.uid() = seller_id) OR public.has_role(auth.uid(), 'owner'::app_role));
