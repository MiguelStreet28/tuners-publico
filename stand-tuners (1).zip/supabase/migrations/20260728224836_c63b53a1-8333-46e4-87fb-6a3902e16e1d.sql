DROP POLICY IF EXISTS "insert stock movement" ON public.card_stock_movements;
CREATE POLICY "insert stock movement" ON public.card_stock_movements
FOR INSERT TO authenticated
WITH CHECK (created_by = auth.uid());