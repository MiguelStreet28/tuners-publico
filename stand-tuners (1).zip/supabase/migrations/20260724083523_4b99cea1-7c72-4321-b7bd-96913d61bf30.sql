
-- Roles
CREATE TYPE public.app_role AS ENUM ('owner', 'seller');

-- Profiles
CREATE TABLE public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "profiles readable by authenticated" ON public.profiles FOR SELECT TO authenticated USING (true);
CREATE POLICY "user can update own profile" ON public.profiles FOR UPDATE TO authenticated USING (auth.uid() = id);
CREATE POLICY "user can insert own profile" ON public.profiles FOR INSERT TO authenticated WITH CHECK (auth.uid() = id);

-- User roles
CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role app_role NOT NULL,
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "roles readable by authenticated" ON public.user_roles FOR SELECT TO authenticated USING (true);

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public
AS $$ SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role) $$;

-- Auto-create profile on signup
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO public.profiles (id, full_name)
  VALUES (NEW.id, COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email));
  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'seller');
  RETURN NEW;
END; $$;
CREATE TRIGGER on_auth_user_created AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Contratos levantados
CREATE TABLE public.contracts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  card_paid BOOLEAN NOT NULL DEFAULT false,
  card_value NUMERIC NOT NULL DEFAULT 50,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.contracts TO authenticated;
GRANT ALL ON public.contracts TO service_role;
ALTER TABLE public.contracts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "contracts readable by all authenticated" ON public.contracts FOR SELECT TO authenticated USING (true);
CREATE POLICY "sellers insert own contracts" ON public.contracts FOR INSERT TO authenticated WITH CHECK (auth.uid() = seller_id);
CREATE POLICY "owner or self update contract" ON public.contracts FOR UPDATE TO authenticated USING (auth.uid() = seller_id OR public.has_role(auth.uid(), 'owner'));
CREATE POLICY "owner or self delete contract" ON public.contracts FOR DELETE TO authenticated USING (auth.uid() = seller_id OR public.has_role(auth.uid(), 'owner'));

-- Registos de veículos (compra/venda/troca por matrícula)
CREATE TYPE public.vehicle_op AS ENUM ('compra', 'venda', 'troca');

CREATE TABLE public.vehicle_records (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  matricula TEXT NOT NULL,
  op public.vehicle_op NOT NULL,
  valor NUMERIC NOT NULL,
  seller_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  contraparte TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_vehicle_records_matricula ON public.vehicle_records (matricula);
CREATE INDEX idx_vehicle_records_seller ON public.vehicle_records (seller_id);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.vehicle_records TO authenticated;
GRANT ALL ON public.vehicle_records TO service_role;
ALTER TABLE public.vehicle_records ENABLE ROW LEVEL SECURITY;
CREATE POLICY "records readable by all authenticated" ON public.vehicle_records FOR SELECT TO authenticated USING (true);
CREATE POLICY "sellers insert own record" ON public.vehicle_records FOR INSERT TO authenticated WITH CHECK (auth.uid() = seller_id);
CREATE POLICY "owner or self update record" ON public.vehicle_records FOR UPDATE TO authenticated USING (auth.uid() = seller_id OR public.has_role(auth.uid(), 'owner'));
CREATE POLICY "owner or self delete record" ON public.vehicle_records FOR DELETE TO authenticated USING (auth.uid() = seller_id OR public.has_role(auth.uid(), 'owner'));
