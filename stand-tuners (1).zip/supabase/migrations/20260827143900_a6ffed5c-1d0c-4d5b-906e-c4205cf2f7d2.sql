ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS fee_mode boolean NOT NULL DEFAULT false;

CREATE TABLE public.fee_payments (
  id uuid NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  seller_id uuid NOT NULL,
  matricula text NOT NULL,
  cycle integer NOT NULL DEFAULT 1,
  record_id uuid,
  profit numeric NOT NULL DEFAULT 0,
  fee numeric NOT NULL DEFAULT 0,
  marked_by uuid,
  created_at timestamp with time zone NOT NULL DEFAULT now(),
  updated_at timestamp with time zone NOT NULL DEFAULT now(),
  UNIQUE (seller_id, matricula, cycle, record_id)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.fee_payments TO authenticated;
GRANT ALL ON public.fee_payments TO service_role;

ALTER TABLE public.fee_payments ENABLE ROW LEVEL SECURITY;

CREATE POLICY "fee read own or owner" ON public.fee_payments
  FOR SELECT TO authenticated
  USING (seller_id = auth.uid() OR public.has_role(auth.uid(), 'owner'::app_role));

CREATE POLICY "fee insert own or owner" ON public.fee_payments
  FOR INSERT TO authenticated
  WITH CHECK ((seller_id = auth.uid() OR public.has_role(auth.uid(), 'owner'::app_role)) AND marked_by = auth.uid());

CREATE POLICY "fee update own or owner" ON public.fee_payments
  FOR UPDATE TO authenticated
  USING (seller_id = auth.uid() OR public.has_role(auth.uid(), 'owner'::app_role))
  WITH CHECK (seller_id = auth.uid() OR public.has_role(auth.uid(), 'owner'::app_role));

CREATE POLICY "fee delete owner" ON public.fee_payments
  FOR DELETE TO authenticated
  USING (public.has_role(auth.uid(), 'owner'::app_role));

CREATE OR REPLACE FUNCTION public.set_updated_at()
RETURNS trigger
LANGUAGE plpgsql
SET search_path = public
AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

CREATE TRIGGER update_fee_payments_updated_at
  BEFORE UPDATE ON public.fee_payments
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

INSERT INTO public.app_settings (key, value_int) VALUES ('fee_percent', 10)
  ON CONFLICT (key) DO NOTHING;