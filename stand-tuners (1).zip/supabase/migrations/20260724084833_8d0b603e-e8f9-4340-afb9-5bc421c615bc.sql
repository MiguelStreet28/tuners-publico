
ALTER TABLE public.contracts ADD COLUMN IF NOT EXISTS quantity integer NOT NULL DEFAULT 1 CHECK (quantity >= 1);
ALTER TABLE public.vehicle_records ADD COLUMN IF NOT EXISTS modelo text;
ALTER TABLE public.vehicle_records ADD COLUMN IF NOT EXISTS comprador text;
