ALTER TABLE public.vehicle_records
  ADD COLUMN IF NOT EXISTS matricula_entrada text,
  ADD COLUMN IF NOT EXISTS modelo_entrada text;