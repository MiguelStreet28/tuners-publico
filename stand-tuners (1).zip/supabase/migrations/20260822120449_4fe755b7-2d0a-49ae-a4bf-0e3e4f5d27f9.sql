update public.vehicle_records
set extra_in = extra_out, extra_out = '[]'::jsonb
where id = 'c877d88a-e118-4491-b8c1-473bc947dae5';