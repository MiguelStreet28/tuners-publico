
-- Ensure column-level protection on profiles.cc: revoke all, then re-grant only safe columns to authenticated
REVOKE ALL ON public.profiles FROM authenticated;
GRANT SELECT (id, full_name, approved, created_at) ON public.profiles TO authenticated;
GRANT INSERT (id, full_name, approved, cc) ON public.profiles TO authenticated;
GRANT UPDATE (full_name, approved, cc) ON public.profiles TO authenticated;

-- Replace the broad SELECT policy with split policies: team sees non-sensitive fields (enforced via column grants),
-- while cc is additionally protected by restricting row access when selecting the cc column is not applicable at RLS level.
-- Keep row visibility to authenticated team members for name/approval lookups (needed for rankings & UI).
DROP POLICY IF EXISTS "profiles select safe columns for team" ON public.profiles;

CREATE POLICY "profiles team read non sensitive"
ON public.profiles
FOR SELECT
TO authenticated
USING (true);

-- Note: RLS cannot filter columns; sensitive column 'cc' is protected by the column-level GRANT above
-- (authenticated role has no SELECT privilege on cc). Owners can read cc via service-role server functions.
