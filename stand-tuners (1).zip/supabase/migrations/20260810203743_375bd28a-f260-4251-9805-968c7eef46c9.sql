CREATE POLICY "owners insert records for others"
ON public.vehicle_records FOR INSERT TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'owner'::app_role));

CREATE POLICY "owners insert contracts for others"
ON public.contracts FOR INSERT TO authenticated
WITH CHECK (public.has_role(auth.uid(), 'owner'::app_role));