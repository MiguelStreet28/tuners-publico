
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS approved boolean NOT NULL DEFAULT false;

-- Approve Pedro Lourenço by name (existing rows)
UPDATE public.profiles SET approved = true WHERE full_name = 'Pedro Lourenço';

-- Update signup trigger: auto-approve Pedro Lourenço only
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  v_name text;
BEGIN
  v_name := COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email);
  INSERT INTO public.profiles (id, full_name, approved)
  VALUES (NEW.id, v_name, v_name = 'Pedro Lourenço');
  INSERT INTO public.user_roles (user_id, role)
  VALUES (NEW.id, CASE WHEN v_name IN ('Pedro Lourenço', 'Cristiano Ronaldo') THEN 'owner'::app_role ELSE 'seller'::app_role END);
  RETURN NEW;
END; $$;

-- Ensure trigger exists on auth.users
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Policy: only Pedro Lourenço can update the approved column (through profiles UPDATE).
-- Existing "user can update own profile" policy still lets users edit their own row (cc). We add an override for Pedro.
DROP POLICY IF EXISTS "pedro can update any profile" ON public.profiles;
CREATE POLICY "pedro can update any profile" ON public.profiles
  FOR UPDATE TO authenticated
  USING (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.full_name = 'Pedro Lourenço'))
  WITH CHECK (EXISTS (SELECT 1 FROM public.profiles p WHERE p.id = auth.uid() AND p.full_name = 'Pedro Lourenço'));

-- Card stock movements
CREATE TABLE IF NOT EXISTS public.card_stock_movements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  delta integer NOT NULL,
  reason text NOT NULL DEFAULT 'manual',
  notes text,
  created_by uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, DELETE ON public.card_stock_movements TO authenticated;
GRANT ALL ON public.card_stock_movements TO service_role;

ALTER TABLE public.card_stock_movements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "stock readable by authenticated"
  ON public.card_stock_movements FOR SELECT TO authenticated USING (true);

-- Owners can add manual movements; automatic (reason='auto_contract') insert allowed for any authenticated user (own row)
CREATE POLICY "owners insert manual stock movement"
  ON public.card_stock_movements FOR INSERT TO authenticated
  WITH CHECK (
    created_by = auth.uid() AND (
      public.has_role(auth.uid(), 'owner') OR reason = 'auto_contract'
    )
  );

CREATE POLICY "owners delete stock movement"
  ON public.card_stock_movements FOR DELETE TO authenticated
  USING (public.has_role(auth.uid(), 'owner'));
