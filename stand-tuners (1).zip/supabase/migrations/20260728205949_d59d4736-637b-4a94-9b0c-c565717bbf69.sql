DROP POLICY IF EXISTS "owner or self read record" ON public.vehicle_records;
CREATE POLICY "team read record" ON public.vehicle_records FOR SELECT TO authenticated USING (true);