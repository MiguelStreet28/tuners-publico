-- 1) profiles: hide the `cc` (national ID) column from the Data API for normal users
REVOKE SELECT ON public.profiles FROM authenticated;
REVOKE SELECT ON public.profiles FROM anon;
GRANT SELECT (id, full_name, approved, created_at) ON public.profiles TO authenticated;
GRANT ALL ON public.profiles TO service_role;

-- 2) vehicle_records: restrict team-wide read to approved team members / owner
CREATE OR REPLACE FUNCTION public.is_approved(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.profiles
    WHERE id = _user_id AND approved = true
  )
$$;

DROP POLICY IF EXISTS "team read record" ON public.vehicle_records;
CREATE POLICY "approved team read record"
ON public.vehicle_records
FOR SELECT
TO authenticated
USING (
  auth.uid() = seller_id
  OR public.has_role(auth.uid(), 'owner'::app_role)
  OR public.is_approved(auth.uid())
);