ALTER TABLE public.vehicle_records ADD COLUMN IF NOT EXISTS partner_id uuid REFERENCES auth.users(id);
CREATE INDEX IF NOT EXISTS vehicle_records_partner_id_idx ON public.vehicle_records (partner_id);