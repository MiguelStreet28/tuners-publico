CREATE TABLE public.user_tab_denies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  tab text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  created_by uuid,
  UNIQUE (user_id, tab)
);
GRANT SELECT, INSERT, DELETE ON public.user_tab_denies TO authenticated;
GRANT ALL ON public.user_tab_denies TO service_role;
ALTER TABLE public.user_tab_denies ENABLE ROW LEVEL SECURITY;
CREATE POLICY "read own or owner" ON public.user_tab_denies FOR SELECT TO authenticated
  USING (user_id = auth.uid() OR public.has_role(auth.uid(), 'owner'::app_role));
CREATE POLICY "owner insert" ON public.user_tab_denies FOR INSERT TO authenticated
  WITH CHECK (public.has_role(auth.uid(), 'owner'::app_role));
CREATE POLICY "owner delete" ON public.user_tab_denies FOR DELETE TO authenticated
  USING (public.has_role(auth.uid(), 'owner'::app_role));
ALTER PUBLICATION supabase_realtime ADD TABLE public.user_tab_denies;