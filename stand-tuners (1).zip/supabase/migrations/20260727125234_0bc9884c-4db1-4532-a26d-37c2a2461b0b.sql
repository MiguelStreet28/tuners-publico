INSERT INTO public.user_roles (user_id, role)
SELECT p.id, 'owner'::app_role
FROM public.profiles p
WHERE p.full_name IN ('Pedro Lourenço', 'Cristiano Ronaldo')
ON CONFLICT (user_id, role) DO NOTHING;

DELETE FROM public.user_roles ur
USING public.profiles p
WHERE ur.user_id = p.id
  AND ur.role = 'seller'
  AND p.full_name IN ('Pedro Lourenço', 'Cristiano Ronaldo');