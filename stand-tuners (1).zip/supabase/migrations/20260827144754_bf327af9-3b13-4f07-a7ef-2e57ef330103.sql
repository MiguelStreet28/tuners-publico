GRANT SELECT (fee_mode), UPDATE (fee_mode) ON public.profiles TO authenticated;
GRANT SELECT (fee_mode) ON public.profiles TO service_role;