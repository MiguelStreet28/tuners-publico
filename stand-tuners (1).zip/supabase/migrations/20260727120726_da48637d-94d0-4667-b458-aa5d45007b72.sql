
DROP POLICY IF EXISTS "contracts readable by seller or owner" ON public.contracts;
CREATE POLICY "contracts readable by team"
  ON public.contracts FOR SELECT
  TO authenticated
  USING (true);

DROP POLICY IF EXISTS "records readable by seller or owner" ON public.vehicle_records;
CREATE POLICY "records readable by team"
  ON public.vehicle_records FOR SELECT
  TO authenticated
  USING (true);
