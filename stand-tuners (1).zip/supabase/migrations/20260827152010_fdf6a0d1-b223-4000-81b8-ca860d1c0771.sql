CREATE TABLE public.fee_manual_costs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_id uuid NOT NULL,
  matricula text NOT NULL,
  cycle integer NOT NULL DEFAULT 1,
  record_id uuid,
  cost numeric NOT NULL DEFAULT 0,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (seller_id, matricula, cycle)
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.fee_manual_costs TO authenticated;
GRANT ALL ON public.fee_manual_costs TO service_role;

ALTER TABLE public.fee_manual_costs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "manual cost read own or owner" ON public.fee_manual_costs
FOR SELECT TO authenticated
USING (seller_id = auth.uid() OR has_role(auth.uid(), 'owner'::app_role));

CREATE POLICY "manual cost insert own or owner" ON public.fee_manual_costs
FOR INSERT TO authenticated
WITH CHECK (seller_id = auth.uid() OR has_role(auth.uid(), 'owner'::app_role));

CREATE POLICY "manual cost update own or owner" ON public.fee_manual_costs
FOR UPDATE TO authenticated
USING (seller_id = auth.uid() OR has_role(auth.uid(), 'owner'::app_role))
WITH CHECK (seller_id = auth.uid() OR has_role(auth.uid(), 'owner'::app_role));

CREATE POLICY "manual cost delete own or owner" ON public.fee_manual_costs
FOR DELETE TO authenticated
USING (seller_id = auth.uid() OR has_role(auth.uid(), 'owner'::app_role));

CREATE TRIGGER update_fee_manual_costs_updated_at
BEFORE UPDATE ON public.fee_manual_costs
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();