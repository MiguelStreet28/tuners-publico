ALTER TABLE public.vehicle_records
  ADD COLUMN IF NOT EXISTS contraparte_nome text,
  ADD COLUMN IF NOT EXISTS sheet_row integer;