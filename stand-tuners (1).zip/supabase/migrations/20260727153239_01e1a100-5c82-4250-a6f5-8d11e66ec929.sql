
CREATE TABLE public.app_settings (
  key TEXT PRIMARY KEY,
  value_int INTEGER,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_by UUID
);
GRANT SELECT ON public.app_settings TO authenticated;
GRANT ALL ON public.app_settings TO service_role;
ALTER TABLE public.app_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "settings read all auth" ON public.app_settings
  FOR SELECT TO authenticated USING (true);
CREATE POLICY "settings owner write" ON public.app_settings
  FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'owner'));
CREATE POLICY "settings owner update" ON public.app_settings
  FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'owner')) WITH CHECK (public.has_role(auth.uid(), 'owner'));

INSERT INTO public.app_settings (key, value_int) VALUES
  ('sheet_next_row', 6498),
  ('cards_per_contract', 50)
ON CONFLICT (key) DO NOTHING;
