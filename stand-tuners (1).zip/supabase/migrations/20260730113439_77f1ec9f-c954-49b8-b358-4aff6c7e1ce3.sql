DROP POLICY IF EXISTS "approved team read record" ON public.vehicle_records;
CREATE POLICY "approved team read record"
ON public.vehicle_records
FOR SELECT
TO authenticated
USING (
  auth.uid() = seller_id
  OR public.has_role(auth.uid(), 'owner'::app_role)
  OR EXISTS (
    SELECT 1 FROM public.profiles p
    WHERE p.id = auth.uid() AND p.approved = true
  )
);
DROP FUNCTION IF EXISTS public.is_approved(uuid);